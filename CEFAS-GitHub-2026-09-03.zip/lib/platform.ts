import { env } from 'cloudflare:workers';

type Bindings = { DB: D1Database; FILES: R2Bucket };
export const bindings = env as unknown as Bindings;

const coreStatements = [
  `CREATE TABLE IF NOT EXISTS tenants (id TEXT PRIMARY KEY, name TEXT NOT NULL, slug TEXT NOT NULL UNIQUE, status TEXT NOT NULL DEFAULT 'active', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, deleted_at TEXT)`,
  `CREATE TABLE IF NOT EXISTS clients (id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, company TEXT NOT NULL, document TEXT, contact_name TEXT, email TEXT, phone TEXT, plan TEXT, sla_profile TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, deleted_at TEXT)`,
  `CREATE TABLE IF NOT EXISTS projects (id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, client_id TEXT, code TEXT NOT NULL, name TEXT NOT NULL, type TEXT NOT NULL, description TEXT, url TEXT, api_url TEXT, technology TEXT, framework TEXT, current_version TEXT, technical_owner TEXT, status TEXT NOT NULL DEFAULT 'online', heartbeat_interval_seconds INTEGER NOT NULL DEFAULT 60, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, deleted_at TEXT)`,
  `CREATE UNIQUE INDEX IF NOT EXISTS uq_projects_tenant_code ON projects(tenant_id, code)`,
  `CREATE TABLE IF NOT EXISTS api_keys (id TEXT PRIMARY KEY, project_id TEXT NOT NULL, name TEXT NOT NULL, key_prefix TEXT NOT NULL, key_hash TEXT NOT NULL UNIQUE, last_used_at TEXT, expires_at TEXT, revoked_at TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
  `CREATE TABLE IF NOT EXISTS tickets (id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, number INTEGER NOT NULL, project_id TEXT NOT NULL, client_id TEXT, requester_id TEXT, title TEXT NOT NULL, description TEXT NOT NULL, category TEXT NOT NULL, priority TEXT NOT NULL DEFAULT 'medium', status TEXT NOT NULL DEFAULT 'new', owner_id TEXT, source TEXT NOT NULL DEFAULT 'user', environment TEXT NOT NULL, affected_version TEXT, fix_version TEXT, module TEXT, route TEXT, browser TEXT, os TEXT, device TEXT, fingerprint TEXT, occurrence_count INTEGER NOT NULL DEFAULT 1, first_occurrence_at TEXT, last_occurrence_at TEXT, sla_response_due_at TEXT, sla_resolution_due_at TEXT, resolved_at TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, deleted_at TEXT)`,
  `CREATE UNIQUE INDEX IF NOT EXISTS uq_ticket_number ON tickets(tenant_id, number)`,
  `CREATE INDEX IF NOT EXISTS idx_tickets_open_fingerprint ON tickets(project_id, fingerprint, status)`,
  `CREATE TABLE IF NOT EXISTS ticket_occurrences (id TEXT PRIMARY KEY, ticket_id TEXT NOT NULL, user_id TEXT, session_id TEXT, version TEXT, environment TEXT NOT NULL, metadata TEXT, occurred_at TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS ticket_comments (id TEXT PRIMARY KEY, ticket_id TEXT NOT NULL, author_id TEXT NOT NULL, author_type TEXT NOT NULL, body TEXT NOT NULL, internal INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, deleted_at TEXT)`,
  `CREATE TABLE IF NOT EXISTS ticket_status_history (id TEXT PRIMARY KEY, ticket_id TEXT NOT NULL, actor_id TEXT NOT NULL, from_status TEXT, to_status TEXT NOT NULL, note TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
  `CREATE TABLE IF NOT EXISTS incidents (id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, project_id TEXT NOT NULL, ticket_id TEXT, number INTEGER NOT NULL, title TEXT NOT NULL, severity TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open', started_at TEXT NOT NULL, recovered_at TEXT, duration_seconds INTEGER, fingerprint TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, deleted_at TEXT)`,
  `CREATE TABLE IF NOT EXISTS heartbeats (id TEXT PRIMARY KEY, project_id TEXT NOT NULL, environment TEXT NOT NULL, version TEXT, status TEXT NOT NULL, payload TEXT, received_at TEXT NOT NULL)`,
  `CREATE INDEX IF NOT EXISTS idx_heartbeats_project_time ON heartbeats(project_id, received_at)`,
  `CREATE TABLE IF NOT EXISTS health_checks (id TEXT PRIMARY KEY, project_id TEXT NOT NULL, environment TEXT NOT NULL, status TEXT NOT NULL, response_time_ms INTEGER, database_status TEXT, cpu_percent INTEGER, memory_percent INTEGER, disk_percent INTEGER, checked_at TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS monitoring_events (id TEXT PRIMARY KEY, project_id TEXT NOT NULL, type TEXT NOT NULL, severity TEXT NOT NULL, fingerprint TEXT, message TEXT NOT NULL, sanitized_payload TEXT, occurred_at TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS tenant_counters (tenant_id TEXT NOT NULL, name TEXT NOT NULL, value INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(tenant_id, name))`,
];

let initialized = false;
export async function ensureCoreSchema() {
  if (initialized) return;
  await bindings.DB.batch(coreStatements.map((statement) => bindings.DB.prepare(statement)));
  initialized = true;
}

export function json(data: unknown, status = 200) {
  return Response.json(data, { status, headers: { 'cache-control': 'no-store' } });
}

export function sanitize(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(sanitize);
  if (!value || typeof value !== 'object') return value;
  const blocked = /password|passwd|token|secret|authorization|cookie|private.?key|card|cvv|bank/i;
  return Object.fromEntries(Object.entries(value as Record<string, unknown>).map(([key, child]) => [key, blocked.test(key) ? '[REDACTED]' : sanitize(child)]));
}

export async function sha256(value: string) {
  const bytes = new TextEncoder().encode(value);
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, '0')).join('');
}

export async function integrationProject(request: Request) {
  const projectId = request.headers.get('x-project-id');
  const projectKey = request.headers.get('x-project-key');
  if (!projectId || !projectKey) return null;
  await ensureCoreSchema();
  const keyHash = await sha256(projectKey);
  const record = await bindings.DB.prepare(`SELECT p.id, p.tenant_id, p.name FROM projects p JOIN api_keys k ON k.project_id = p.id WHERE p.id = ? AND k.key_hash = ? AND k.revoked_at IS NULL AND (k.expires_at IS NULL OR k.expires_at > CURRENT_TIMESTAMP)`).bind(projectId, keyHash).first<{ id: string; tenant_id: string; name: string }>();
  if (record) await bindings.DB.prepare(`UPDATE api_keys SET last_used_at = CURRENT_TIMESTAMP WHERE project_id = ? AND key_hash = ?`).bind(projectId, keyHash).run();
  return record;
}

export async function fingerprint(parts: unknown[]) {
  return sha256(parts.map((part) => String(part ?? '').trim().toLowerCase()).join('|'));
}

export function uid(prefix: string) {
  return `${prefix}_${crypto.randomUUID()}`;
}

export async function nextNumber(tenantId: string, name: string) {
  const row = await bindings.DB.prepare(`INSERT INTO tenant_counters (tenant_id, name, value) VALUES (?, ?, 1) ON CONFLICT(tenant_id, name) DO UPDATE SET value = value + 1 RETURNING value`).bind(tenantId, name).first<{ value: number }>();
  return row?.value ?? 1;
}
