export type QuoteItemInput = {
  description: string;
  quantity: number;
  unit: string;
  unitPriceCents: number;
  discountType: 'percent' | 'fixed';
  discountValue: number;
};

export type QuotePayload = {
  status: string;
  issueDate: string;
  validUntil: string;
  projectId?: string;
  projectName?: string;
  internalNotes?: string;
  clientId?: string;
  clientName: string;
  clientDocument?: string;
  clientPhone?: string;
  clientEmail?: string;
  clientAddress?: string;
  contactName?: string;
  discountCents: number;
  surchargeCents: number;
  taxCents: number;
  paymentMethod?: string;
  paymentTerms?: string;
  deliveryTerms?: string;
  items: QuoteItemInput[];
};

const statuses = ['Rascunho', 'Enviado', 'Aprovado', 'Recusado', 'Vencido'];

function text(value: unknown, max = 500) {
  return String(value ?? '').trim().slice(0, max);
}

function nonNegative(value: unknown) {
  const number = Number(value ?? 0);
  return Number.isFinite(number) && number >= 0 ? number : 0;
}

export function parseQuotePayload(input: unknown): QuotePayload {
  const body = (input && typeof input === 'object' ? input : {}) as Record<string, unknown>;
  const rawItems = Array.isArray(body.items) ? body.items : [];
  const items = rawItems.map((raw) => {
    const item = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>;
    return {
      description: text(item.description, 300),
      quantity: nonNegative(item.quantity),
      unit: text(item.unit, 30) || 'un.',
      unitPriceCents: Math.round(nonNegative(item.unitPriceCents)),
      discountType: item.discountType === 'fixed' ? 'fixed' as const : 'percent' as const,
      discountValue: nonNegative(item.discountValue),
    };
  }).filter((item) => item.description && item.quantity > 0);

  const clientName = text(body.clientName, 180);
  const issueDate = text(body.issueDate, 10);
  const validUntil = text(body.validUntil, 10);
  if (!clientName || !issueDate || !validUntil || items.length === 0) {
    throw new Error('validation_error');
  }

  return {
    status: statuses.includes(String(body.status)) ? String(body.status) : 'Rascunho',
    issueDate,
    validUntil,
    projectId: text(body.projectId, 100) || undefined,
    projectName: text(body.projectName, 180) || undefined,
    internalNotes: text(body.internalNotes, 3000) || undefined,
    clientId: text(body.clientId, 100) || undefined,
    clientName,
    clientDocument: text(body.clientDocument, 40) || undefined,
    clientPhone: text(body.clientPhone, 40) || undefined,
    clientEmail: text(body.clientEmail, 180) || undefined,
    clientAddress: text(body.clientAddress, 500) || undefined,
    contactName: text(body.contactName, 180) || undefined,
    discountCents: Math.round(nonNegative(body.discountCents)),
    surchargeCents: Math.round(nonNegative(body.surchargeCents)),
    taxCents: Math.round(nonNegative(body.taxCents)),
    paymentMethod: text(body.paymentMethod, 100) || undefined,
    paymentTerms: text(body.paymentTerms, 500) || undefined,
    deliveryTerms: text(body.deliveryTerms, 500) || undefined,
    items,
  };
}

export function calculateQuote(payload: QuotePayload) {
  let subtotalCents = 0;
  let itemDiscountCents = 0;
  const items = payload.items.map((item, position) => {
    const gross = Math.round(item.quantity * item.unitPriceCents);
    const discount = item.discountType === 'percent'
      ? Math.round(gross * Math.min(item.discountValue, 100) / 100)
      : Math.min(Math.round(item.discountValue), gross);
    subtotalCents += gross;
    itemDiscountCents += discount;
    return { ...item, position, totalCents: Math.max(0, gross - discount) };
  });
  const afterItems = subtotalCents - itemDiscountCents;
  const discountCents = Math.min(payload.discountCents, afterItems);
  const totalCents = Math.max(0, afterItems - discountCents + payload.surchargeCents + payload.taxCents);
  return { items, subtotalCents, itemDiscountCents, discountCents, totalCents };
}
