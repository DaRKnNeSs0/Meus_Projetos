import { bindings } from './platform';

const statements = [
  `CREATE TABLE IF NOT EXISTS personal_clients (id TEXT PRIMARY KEY, owner_id TEXT NOT NULL, code TEXT, person_type TEXT NOT NULL DEFAULT 'Pessoa jurídica', name TEXT NOT NULL, trade_name TEXT, document TEXT, state_registration TEXT, contact_name TEXT, email TEXT, phone TEXT, whatsapp TEXT, postal_code TEXT, address TEXT, address_number TEXT, address_complement TEXT, neighborhood TEXT, city TEXT, state TEXT, notes TEXT, status TEXT NOT NULL DEFAULT 'Ativo', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, deleted_at TEXT)`,
  `CREATE INDEX IF NOT EXISTS idx_personal_clients_owner_name ON personal_clients(owner_id, name)`,
  `CREATE UNIQUE INDEX IF NOT EXISTS uq_personal_clients_owner_code ON personal_clients(owner_id, code)`,
  `CREATE UNIQUE INDEX IF NOT EXISTS uq_personal_clients_owner_document ON personal_clients(owner_id, document)`,
  `CREATE TABLE IF NOT EXISTS personal_projects (id TEXT PRIMARY KEY, owner_id TEXT NOT NULL, client_id TEXT, code TEXT NOT NULL, name TEXT NOT NULL, type TEXT NOT NULL DEFAULT 'Sistema', description TEXT, environment TEXT NOT NULL DEFAULT 'Desenvolvimento', version TEXT, start_date TEXT, due_date TEXT, progress INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'Em desenvolvimento', notes TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, deleted_at TEXT)`,
  `CREATE UNIQUE INDEX IF NOT EXISTS uq_personal_projects_owner_code ON personal_projects(owner_id, code)`,
  `CREATE INDEX IF NOT EXISTS idx_personal_projects_owner_status ON personal_projects(owner_id, status)`,
  `CREATE TABLE IF NOT EXISTS catalog_categories (id TEXT PRIMARY KEY, owner_id TEXT NOT NULL, name TEXT NOT NULL, entity_type TEXT NOT NULL, description TEXT, color TEXT NOT NULL DEFAULT '#287cec', status TEXT NOT NULL DEFAULT 'Ativo', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, deleted_at TEXT)`,
  `CREATE UNIQUE INDEX IF NOT EXISTS uq_catalog_categories_owner_name_type ON catalog_categories(owner_id, name, entity_type)`,
  `CREATE INDEX IF NOT EXISTS idx_catalog_categories_owner_status ON catalog_categories(owner_id, status)`,
  `CREATE TABLE IF NOT EXISTS catalog_units (id TEXT PRIMARY KEY, owner_id TEXT NOT NULL, name TEXT NOT NULL, abbreviation TEXT NOT NULL, allows_decimal INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'Ativo', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, deleted_at TEXT)`,
  `CREATE UNIQUE INDEX IF NOT EXISTS uq_catalog_units_owner_abbreviation ON catalog_units(owner_id, abbreviation)`,
  `CREATE TABLE IF NOT EXISTS catalog_payment_methods (id TEXT PRIMARY KEY, owner_id TEXT NOT NULL, name TEXT NOT NULL, type TEXT NOT NULL, installments INTEGER NOT NULL DEFAULT 1, interval_days INTEGER NOT NULL DEFAULT 0, default_terms TEXT, notes TEXT, status TEXT NOT NULL DEFAULT 'Ativo', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, deleted_at TEXT)`,
  `CREATE UNIQUE INDEX IF NOT EXISTS uq_catalog_payment_owner_name ON catalog_payment_methods(owner_id, name)`,
  `CREATE TABLE IF NOT EXISTS catalog_items (id TEXT PRIMARY KEY, owner_id TEXT NOT NULL, code TEXT NOT NULL, item_type TEXT NOT NULL, name TEXT NOT NULL, description TEXT, category_id TEXT, unit_id TEXT, sale_price_cents INTEGER NOT NULL DEFAULT 0, cost_cents INTEGER, tax_percent REAL, max_discount_percent REAL, delivery_terms TEXT, notes TEXT, status TEXT NOT NULL DEFAULT 'Ativo', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, deleted_at TEXT)`,
  `CREATE UNIQUE INDEX IF NOT EXISTS uq_catalog_items_owner_code ON catalog_items(owner_id, code)`,
  `CREATE INDEX IF NOT EXISTS idx_catalog_items_owner_type_status ON catalog_items(owner_id, item_type, status)`,
  `CREATE TABLE IF NOT EXISTS company_profiles (owner_id TEXT PRIMARY KEY, company_name TEXT, document TEXT, phone TEXT, whatsapp TEXT, email TEXT, site TEXT, address TEXT, footer_text TEXT, commercial_notes TEXT, signature_text TEXT, logo_url TEXT, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
  `CREATE TABLE IF NOT EXISTS catalog_history (id TEXT PRIMARY KEY, owner_id TEXT NOT NULL, entity_type TEXT NOT NULL, entity_id TEXT NOT NULL, action TEXT NOT NULL, details TEXT, actor_name TEXT NOT NULL DEFAULT 'Administrador Master', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
  `CREATE INDEX IF NOT EXISTS idx_catalog_history_owner_time ON catalog_history(owner_id, created_at)`,
  `CREATE INDEX IF NOT EXISTS idx_catalog_history_entity ON catalog_history(entity_type, entity_id)`,
  `CREATE TABLE IF NOT EXISTS quotes (id TEXT PRIMARY KEY, owner_id TEXT NOT NULL, number INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'Rascunho', issue_date TEXT NOT NULL, valid_until TEXT NOT NULL, project_id TEXT, project_name TEXT, internal_notes TEXT, client_id TEXT, client_name TEXT NOT NULL, client_document TEXT, client_phone TEXT, client_email TEXT, client_address TEXT, contact_name TEXT, subtotal_cents INTEGER NOT NULL DEFAULT 0, item_discount_cents INTEGER NOT NULL DEFAULT 0, discount_cents INTEGER NOT NULL DEFAULT 0, surcharge_cents INTEGER NOT NULL DEFAULT 0, tax_cents INTEGER NOT NULL DEFAULT 0, total_cents INTEGER NOT NULL DEFAULT 0, payment_method TEXT, payment_terms TEXT, delivery_terms TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, deleted_at TEXT)`,
  `CREATE UNIQUE INDEX IF NOT EXISTS uq_quotes_owner_number ON quotes(owner_id, number)`,
  `CREATE INDEX IF NOT EXISTS idx_quotes_owner_status ON quotes(owner_id, status)`,
  `CREATE INDEX IF NOT EXISTS idx_quotes_owner_updated ON quotes(owner_id, updated_at)`,
  `CREATE TABLE IF NOT EXISTS quote_items (id TEXT PRIMARY KEY, quote_id TEXT NOT NULL, description TEXT NOT NULL, quantity REAL NOT NULL, unit TEXT NOT NULL, unit_price_cents INTEGER NOT NULL, discount_type TEXT NOT NULL DEFAULT 'percent', discount_value REAL NOT NULL DEFAULT 0, total_cents INTEGER NOT NULL, position INTEGER NOT NULL DEFAULT 0)`,
  `CREATE INDEX IF NOT EXISTS idx_quote_items_quote_position ON quote_items(quote_id, position)`,
  `CREATE TABLE IF NOT EXISTS quote_history (id TEXT PRIMARY KEY, quote_id TEXT NOT NULL, actor_id TEXT NOT NULL, action TEXT NOT NULL, from_status TEXT, to_status TEXT, details TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
  `CREATE INDEX IF NOT EXISTS idx_quote_history_quote_time ON quote_history(quote_id, created_at)`,
];

let initialized = false;
export async function ensurePersonalSchema() {
  if (initialized) return;
  await bindings.DB.batch(statements.map((statement) => bindings.DB.prepare(statement)));
  await bindings.DB.prepare('PRAGMA optimize').run();
  initialized = true;
}
