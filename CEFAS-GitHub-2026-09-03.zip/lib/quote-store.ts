import { bindings, nextNumber, uid } from './platform';
import { calculateQuote, QuotePayload } from './quotes';

export async function validateQuoteReferences(ownerId: string, payload: QuotePayload) {
  if (payload.clientId) {
    const client = await bindings.DB.prepare('SELECT id FROM personal_clients WHERE id = ? AND owner_id = ? AND deleted_at IS NULL').bind(payload.clientId, ownerId).first();
    if (!client) throw new Error('invalid_client');
  }
  if (payload.projectId) {
    const project = await bindings.DB.prepare('SELECT id FROM personal_projects WHERE id = ? AND owner_id = ? AND deleted_at IS NULL').bind(payload.projectId, ownerId).first();
    if (!project) throw new Error('invalid_project');
  }
}

export async function createQuote(ownerId: string, actorId: string, payload: QuotePayload, details = 'Orçamento criado') {
  await validateQuoteReferences(ownerId, payload);
  const number = await nextNumber(ownerId, 'quote');
  const id = uid('orc');
  const totals = calculateQuote(payload);
  const statements = [
    bindings.DB.prepare(`INSERT INTO quotes (id, owner_id, number, status, issue_date, valid_until, project_id, project_name, internal_notes, client_id, client_name, client_document, client_phone, client_email, client_address, contact_name, subtotal_cents, item_discount_cents, discount_cents, surcharge_cents, tax_cents, total_cents, payment_method, payment_terms, delivery_terms) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).bind(id, ownerId, number, payload.status, payload.issueDate, payload.validUntil, payload.projectId ?? null, payload.projectName ?? null, payload.internalNotes ?? null, payload.clientId ?? null, payload.clientName, payload.clientDocument ?? null, payload.clientPhone ?? null, payload.clientEmail ?? null, payload.clientAddress ?? null, payload.contactName ?? null, totals.subtotalCents, totals.itemDiscountCents, totals.discountCents, payload.surchargeCents, payload.taxCents, totals.totalCents, payload.paymentMethod ?? null, payload.paymentTerms ?? null, payload.deliveryTerms ?? null),
    ...totals.items.map((item) => bindings.DB.prepare(`INSERT INTO quote_items (id, quote_id, description, quantity, unit, unit_price_cents, discount_type, discount_value, total_cents, position) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).bind(uid('ori'), id, item.description, item.quantity, item.unit, item.unitPriceCents, item.discountType, item.discountValue, item.totalCents, item.position)),
    bindings.DB.prepare(`INSERT INTO quote_history (id, quote_id, actor_id, action, from_status, to_status, details) VALUES (?, ?, ?, 'created', NULL, ?, ?)`).bind(uid('orh'), id, actorId, payload.status, details),
  ];
  await bindings.DB.batch(statements);
  return { id, number, status: payload.status, totalCents: totals.totalCents };
}

export async function getOwnedQuote(ownerId: string, id: string) {
  return bindings.DB.prepare('SELECT * FROM quotes WHERE id = ? AND owner_id = ? AND deleted_at IS NULL').bind(id, ownerId).first<Record<string, unknown>>();
}

export async function getQuoteItems(id: string) {
  const rows = await bindings.DB.prepare('SELECT * FROM quote_items WHERE quote_id = ? ORDER BY position').bind(id).all();
  return rows.results;
}
