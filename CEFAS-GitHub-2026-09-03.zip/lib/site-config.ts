export const siteConfig = {
  name: 'CEFAS',
  email: 'cefasdevofc@gmail.com',
  whatsappUrl: 'https://wa.me/5585996624849',
  social: {
    instagram: '',
    linkedin: '',
  },
} as const;
