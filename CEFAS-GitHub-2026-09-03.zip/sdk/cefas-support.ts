export type CefasSupportConfig = {
  endpoint: string;
  projectId: string;
  projectKey?: string;
  environment: 'development' | 'staging' | 'production';
  version: string;
  maxQueueSize?: number;
};

type SupportEvent = { path: string; body: Record<string, unknown>; attempts: number; nextAttemptAt: number };

const sensitive = /password|passwd|token|secret|authorization|cookie|private.?key|card|cvv|bank/i;
const sanitize = (value: unknown): unknown => {
  if (Array.isArray(value)) return value.map(sanitize);
  if (!value || typeof value !== 'object') return value;
  return Object.fromEntries(Object.entries(value as Record<string, unknown>).map(([key, child]) => [key, sensitive.test(key) ? '[REDACTED]' : sanitize(child)]));
};

export class CefasSupportClient {
  private queue: SupportEvent[] = [];
  private failures = 0;
  private circuitOpenUntil = 0;
  private flushing = false;

  constructor(private config: CefasSupportConfig) {}

  createTicket(payload: Record<string, unknown>) { return this.enqueue('/api/tickets', payload); }
  reportError(error: Error, context: Record<string, unknown> = {}) { return this.enqueue('/api/errors', { message: error.message, stack: error.stack, ...context }); }
  reportIncident(payload: Record<string, unknown>) { return this.enqueue('/api/incidents', payload); }
  sendLog(payload: Record<string, unknown>) { return this.enqueue('/api/logs', payload); }
  healthCheck(payload: Record<string, unknown>) { return this.enqueue('/api/health', payload); }
  sendPerformance(payload: Record<string, unknown>) { return this.enqueue('/api/performance', payload); }
  heartbeat(status = 'online') { return this.enqueue('/api/heartbeat', { status }); }

  private enqueue(path: string, payload: Record<string, unknown>) {
    const event: SupportEvent = { path, body: sanitize({ ...payload, environment: this.config.environment, version: this.config.version, timestamp: new Date().toISOString() }) as Record<string, unknown>, attempts: 0, nextAttemptAt: Date.now() };
    const max = this.config.maxQueueSize ?? 500;
    if (this.queue.length >= max) this.queue.shift();
    this.queue.push(event);
    queueMicrotask(() => void this.flush());
    return { queued: true };
  }

  async flush() {
    if (this.flushing || Date.now() < this.circuitOpenUntil) return;
    this.flushing = true;
    try {
      while (this.queue.length) {
        const event = this.queue[0];
        if (event.nextAttemptAt > Date.now()) break;
        try {
          const response = await fetch(`${this.config.endpoint}${event.path}`, {
            method: 'POST', keepalive: true, headers: { 'content-type': 'application/json', 'x-project-id': this.config.projectId, ...(this.config.projectKey ? { 'x-project-key': this.config.projectKey } : {}) }, body: JSON.stringify(event.body),
          });
          if (!response.ok) throw new Error(`Support API ${response.status}`);
          this.queue.shift();
          this.failures = 0;
        } catch {
          event.attempts += 1;
          event.nextAttemptAt = Date.now() + Math.min(60_000, 1_000 * 2 ** event.attempts) + Math.random() * 500;
          this.failures += 1;
          if (this.failures >= 5) this.circuitOpenUntil = Date.now() + 30_000;
          break;
        }
      }
    } finally { this.flushing = false; }
  }
}

export const CefasSupport = { initialize: (config: CefasSupportConfig) => new CefasSupportClient(config) };
