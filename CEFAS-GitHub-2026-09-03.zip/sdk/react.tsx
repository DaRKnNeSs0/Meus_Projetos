'use client';
import { createContext, useContext, useMemo } from 'react';
import { CefasSupport, CefasSupportClient, type CefasSupportConfig } from './cefas-support';

const SupportContext = createContext<CefasSupportClient | null>(null);
export function CefasSupportProvider({ config, children }: { config: CefasSupportConfig; children: React.ReactNode }) {
  const client = useMemo(() => CefasSupport.initialize(config), [config]);
  return <SupportContext.Provider value={client}>{children}</SupportContext.Provider>;
}
export function useCefasSupport() {
  const client = useContext(SupportContext);
  if (!client) throw new Error('useCefasSupport deve ser usado dentro de CefasSupportProvider');
  return client;
}

export function SupportCenter({ label = 'Reportar problema' }: { label?: string }) {
  const support = useCefasSupport();
  return <button type="button" onClick={() => support.createTicket({ title: label, route: location.pathname, browser: navigator.userAgent })}>{label}</button>;
}
