import { sql } from 'drizzle-orm';
import { index, integer, real, sqliteTable, text, uniqueIndex } from 'drizzle-orm/sqlite-core';

const timestamps = {
  createdAt: text('created_at').notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text('updated_at').notNull().default(sql`CURRENT_TIMESTAMP`),
  deletedAt: text('deleted_at'),
};

export const tenants = sqliteTable('tenants', {
  id: text('id').primaryKey(), name: text('name').notNull(), slug: text('slug').notNull(), status: text('status').notNull().default('active'), ...timestamps,
}, (t) => [uniqueIndex('uq_tenants_slug').on(t.slug)]);

export const users = sqliteTable('users', {
  id: text('id').primaryKey(), tenantId: text('tenant_id').notNull().references(() => tenants.id), email: text('email').notNull(), name: text('name').notNull(), role: text('role').notNull().default('viewer'), status: text('status').notNull().default('active'), ...timestamps,
}, (t) => [uniqueIndex('uq_users_tenant_email').on(t.tenantId, t.email), index('idx_users_tenant').on(t.tenantId)]);

export const clients = sqliteTable('clients', {
  id: text('id').primaryKey(), tenantId: text('tenant_id').notNull().references(() => tenants.id), company: text('company').notNull(), document: text('document'), contactName: text('contact_name'), email: text('email'), phone: text('phone'), plan: text('plan'), slaProfile: text('sla_profile'), ...timestamps,
}, (t) => [index('idx_clients_tenant').on(t.tenantId)]);

export const projects = sqliteTable('projects', {
  id: text('id').primaryKey(), tenantId: text('tenant_id').notNull().references(() => tenants.id), clientId: text('client_id').references(() => clients.id), code: text('code').notNull(), name: text('name').notNull(), type: text('type').notNull(), description: text('description'), url: text('url'), apiUrl: text('api_url'), technology: text('technology'), framework: text('framework'), currentVersion: text('current_version'), technicalOwner: text('technical_owner'), status: text('status').notNull().default('online'), heartbeatIntervalSeconds: integer('heartbeat_interval_seconds').notNull().default(60), ...timestamps,
}, (t) => [uniqueIndex('uq_projects_tenant_code').on(t.tenantId, t.code), index('idx_projects_tenant_status').on(t.tenantId, t.status)]);

export const projectEnvironments = sqliteTable('project_environments', {
  id: text('id').primaryKey(), projectId: text('project_id').notNull().references(() => projects.id), environment: text('environment').notNull(), baseUrl: text('base_url'), status: text('status').notNull().default('unknown'), lastHeartbeatAt: text('last_heartbeat_at'), lastBackupAt: text('last_backup_at'), ...timestamps,
}, (t) => [uniqueIndex('uq_project_environment').on(t.projectId, t.environment)]);

export const projectVersions = sqliteTable('project_versions', {
  id: text('id').primaryKey(), projectId: text('project_id').notNull().references(() => projects.id), version: text('version').notNull(), status: text('status').notNull().default('development'), changelog: text('changelog'), publishedAt: text('published_at'), ...timestamps,
}, (t) => [uniqueIndex('uq_project_version').on(t.projectId, t.version)]);

export const ticketCategories = sqliteTable('ticket_categories', {
  id: text('id').primaryKey(), tenantId: text('tenant_id').notNull().references(() => tenants.id), name: text('name').notNull(), active: integer('active', { mode: 'boolean' }).notNull().default(true), ...timestamps,
}, (t) => [uniqueIndex('uq_ticket_category').on(t.tenantId, t.name)]);

export const slaRules = sqliteTable('sla_rules', {
  id: text('id').primaryKey(), tenantId: text('tenant_id').notNull().references(() => tenants.id), priority: text('priority').notNull(), responseMinutes: integer('response_minutes').notNull(), resolutionMinutes: integer('resolution_minutes').notNull(), active: integer('active', { mode: 'boolean' }).notNull().default(true), ...timestamps,
}, (t) => [uniqueIndex('uq_sla_priority').on(t.tenantId, t.priority)]);

export const tickets = sqliteTable('tickets', {
  id: text('id').primaryKey(), tenantId: text('tenant_id').notNull().references(() => tenants.id), number: integer('number').notNull(), projectId: text('project_id').notNull().references(() => projects.id), clientId: text('client_id').references(() => clients.id), requesterId: text('requester_id'), title: text('title').notNull(), description: text('description').notNull(), category: text('category').notNull(), priority: text('priority').notNull().default('medium'), status: text('status').notNull().default('new'), ownerId: text('owner_id'), source: text('source').notNull().default('user'), environment: text('environment').notNull(), affectedVersion: text('affected_version'), fixVersion: text('fix_version'), module: text('module'), route: text('route'), browser: text('browser'), os: text('os'), device: text('device'), fingerprint: text('fingerprint'), occurrenceCount: integer('occurrence_count').notNull().default(1), firstOccurrenceAt: text('first_occurrence_at'), lastOccurrenceAt: text('last_occurrence_at'), slaResponseDueAt: text('sla_response_due_at'), slaResolutionDueAt: text('sla_resolution_due_at'), resolvedAt: text('resolved_at'), ...timestamps,
}, (t) => [uniqueIndex('uq_ticket_number').on(t.tenantId, t.number), index('idx_tickets_tenant_status').on(t.tenantId, t.status), index('idx_tickets_project_priority').on(t.projectId, t.priority), index('idx_tickets_open_fingerprint').on(t.projectId, t.fingerprint, t.status)]);

export const ticketComments = sqliteTable('ticket_comments', {
  id: text('id').primaryKey(), ticketId: text('ticket_id').notNull().references(() => tickets.id), authorId: text('author_id').notNull(), authorType: text('author_type').notNull(), body: text('body').notNull(), internal: integer('internal', { mode: 'boolean' }).notNull().default(false), createdAt: text('created_at').notNull().default(sql`CURRENT_TIMESTAMP`), deletedAt: text('deleted_at'),
}, (t) => [index('idx_ticket_comments_ticket').on(t.ticketId)]);

export const ticketStatusHistory = sqliteTable('ticket_status_history', {
  id: text('id').primaryKey(), ticketId: text('ticket_id').notNull().references(() => tickets.id), actorId: text('actor_id').notNull(), fromStatus: text('from_status'), toStatus: text('to_status').notNull(), note: text('note'), createdAt: text('created_at').notNull().default(sql`CURRENT_TIMESTAMP`),
}, (t) => [index('idx_ticket_history_ticket').on(t.ticketId)]);

export const ticketOccurrences = sqliteTable('ticket_occurrences', {
  id: text('id').primaryKey(), ticketId: text('ticket_id').notNull().references(() => tickets.id), userId: text('user_id'), sessionId: text('session_id'), version: text('version'), environment: text('environment').notNull(), metadata: text('metadata'), occurredAt: text('occurred_at').notNull(),
}, (t) => [index('idx_ticket_occurrences_ticket_time').on(t.ticketId, t.occurredAt)]);

export const incidents = sqliteTable('incidents', {
  id: text('id').primaryKey(), tenantId: text('tenant_id').notNull().references(() => tenants.id), projectId: text('project_id').notNull().references(() => projects.id), ticketId: text('ticket_id').references(() => tickets.id), number: integer('number').notNull(), title: text('title').notNull(), severity: text('severity').notNull(), status: text('status').notNull().default('open'), startedAt: text('started_at').notNull(), recoveredAt: text('recovered_at'), durationSeconds: integer('duration_seconds'), fingerprint: text('fingerprint'), ...timestamps,
}, (t) => [index('idx_incidents_project_status').on(t.projectId, t.status)]);

export const heartbeats = sqliteTable('heartbeats', {
  id: text('id').primaryKey(), projectId: text('project_id').notNull().references(() => projects.id), environment: text('environment').notNull(), version: text('version'), status: text('status').notNull(), payload: text('payload'), receivedAt: text('received_at').notNull(),
}, (t) => [index('idx_heartbeats_project_time').on(t.projectId, t.receivedAt)]);

export const healthChecks = sqliteTable('health_checks', {
  id: text('id').primaryKey(), projectId: text('project_id').notNull().references(() => projects.id), environment: text('environment').notNull(), status: text('status').notNull(), responseTimeMs: integer('response_time_ms'), databaseStatus: text('database_status'), cpuPercent: integer('cpu_percent'), memoryPercent: integer('memory_percent'), diskPercent: integer('disk_percent'), checkedAt: text('checked_at').notNull(),
}, (t) => [index('idx_health_project_time').on(t.projectId, t.checkedAt)]);

export const monitoringEvents = sqliteTable('monitoring_events', {
  id: text('id').primaryKey(), projectId: text('project_id').notNull().references(() => projects.id), type: text('type').notNull(), severity: text('severity').notNull(), fingerprint: text('fingerprint'), message: text('message').notNull(), sanitizedPayload: text('sanitized_payload'), occurredAt: text('occurred_at').notNull(),
}, (t) => [index('idx_monitoring_project_type_time').on(t.projectId, t.type, t.occurredAt)]);

export const notifications = sqliteTable('notifications', {
  id: text('id').primaryKey(), tenantId: text('tenant_id').notNull().references(() => tenants.id), userId: text('user_id').notNull(), type: text('type').notNull(), title: text('title').notNull(), body: text('body').notNull(), entityType: text('entity_type'), entityId: text('entity_id'), readAt: text('read_at'), createdAt: text('created_at').notNull().default(sql`CURRENT_TIMESTAMP`),
}, (t) => [index('idx_notifications_user_read').on(t.userId, t.readAt)]);

export const maintenanceWindows = sqliteTable('maintenance_windows', {
  id: text('id').primaryKey(), tenantId: text('tenant_id').notNull().references(() => tenants.id), projectId: text('project_id').notNull().references(() => projects.id), title: text('title').notNull(), description: text('description'), startsAt: text('starts_at').notNull(), endsAt: text('ends_at').notNull(), status: text('status').notNull().default('scheduled'), communicateToUsers: integer('communicate_to_users', { mode: 'boolean' }).notNull().default(true), ...timestamps,
}, (t) => [index('idx_maintenance_project_start').on(t.projectId, t.startsAt)]);

export const apiKeys = sqliteTable('api_keys', {
  id: text('id').primaryKey(), projectId: text('project_id').notNull().references(() => projects.id), name: text('name').notNull(), keyPrefix: text('key_prefix').notNull(), keyHash: text('key_hash').notNull(), lastUsedAt: text('last_used_at'), expiresAt: text('expires_at'), revokedAt: text('revoked_at'), createdAt: text('created_at').notNull().default(sql`CURRENT_TIMESTAMP`),
}, (t) => [index('idx_api_keys_project').on(t.projectId), uniqueIndex('uq_api_key_hash').on(t.keyHash)]);

export const auditLogs = sqliteTable('audit_logs', {
  id: text('id').primaryKey(), tenantId: text('tenant_id').notNull().references(() => tenants.id), actorId: text('actor_id').notNull(), action: text('action').notNull(), entityType: text('entity_type').notNull(), entityId: text('entity_id'), previousValue: text('previous_value'), newValue: text('new_value'), ipHash: text('ip_hash'), createdAt: text('created_at').notNull().default(sql`CURRENT_TIMESTAMP`),
}, (t) => [index('idx_audit_tenant_time').on(t.tenantId, t.createdAt)]);

export const personalClients = sqliteTable('personal_clients', {
  id: text('id').primaryKey(), ownerId: text('owner_id').notNull(), code: text('code'), personType: text('person_type').notNull().default('Pessoa jurídica'), name: text('name').notNull(), tradeName: text('trade_name'), document: text('document'), stateRegistration: text('state_registration'), contactName: text('contact_name'), email: text('email'), phone: text('phone'), whatsapp: text('whatsapp'), postalCode: text('postal_code'), address: text('address'), addressNumber: text('address_number'), addressComplement: text('address_complement'), neighborhood: text('neighborhood'), city: text('city'), state: text('state'), notes: text('notes'), status: text('status').notNull().default('Ativo'), ...timestamps,
}, (t) => [index('idx_personal_clients_owner_name').on(t.ownerId, t.name), uniqueIndex('uq_personal_clients_owner_code').on(t.ownerId, t.code), uniqueIndex('uq_personal_clients_owner_document').on(t.ownerId, t.document)]);

export const personalProjects = sqliteTable('personal_projects', {
  id: text('id').primaryKey(), ownerId: text('owner_id').notNull(), clientId: text('client_id').references(() => personalClients.id), code: text('code').notNull(), name: text('name').notNull(), type: text('type').notNull().default('Sistema'), description: text('description'), environment: text('environment').notNull().default('Desenvolvimento'), version: text('version'), startDate: text('start_date'), dueDate: text('due_date'), progress: integer('progress').notNull().default(0), status: text('status').notNull().default('Em desenvolvimento'), notes: text('notes'), ...timestamps,
}, (t) => [uniqueIndex('uq_personal_projects_owner_code').on(t.ownerId, t.code), index('idx_personal_projects_owner_status').on(t.ownerId, t.status)]);

export const catalogCategories = sqliteTable('catalog_categories', {
  id: text('id').primaryKey(), ownerId: text('owner_id').notNull(), name: text('name').notNull(), entityType: text('entity_type').notNull(), description: text('description'), color: text('color').notNull().default('#287cec'), status: text('status').notNull().default('Ativo'), ...timestamps,
}, (t) => [uniqueIndex('uq_catalog_categories_owner_name_type').on(t.ownerId, t.name, t.entityType), index('idx_catalog_categories_owner_status').on(t.ownerId, t.status)]);

export const catalogUnits = sqliteTable('catalog_units', {
  id: text('id').primaryKey(), ownerId: text('owner_id').notNull(), name: text('name').notNull(), abbreviation: text('abbreviation').notNull(), allowsDecimal: integer('allows_decimal', { mode: 'boolean' }).notNull().default(false), status: text('status').notNull().default('Ativo'), ...timestamps,
}, (t) => [uniqueIndex('uq_catalog_units_owner_abbreviation').on(t.ownerId, t.abbreviation)]);

export const catalogPaymentMethods = sqliteTable('catalog_payment_methods', {
  id: text('id').primaryKey(), ownerId: text('owner_id').notNull(), name: text('name').notNull(), type: text('type').notNull(), installments: integer('installments').notNull().default(1), intervalDays: integer('interval_days').notNull().default(0), defaultTerms: text('default_terms'), notes: text('notes'), status: text('status').notNull().default('Ativo'), ...timestamps,
}, (t) => [uniqueIndex('uq_catalog_payment_owner_name').on(t.ownerId, t.name)]);

export const catalogItems = sqliteTable('catalog_items', {
  id: text('id').primaryKey(), ownerId: text('owner_id').notNull(), code: text('code').notNull(), itemType: text('item_type').notNull(), name: text('name').notNull(), description: text('description'), categoryId: text('category_id').references(() => catalogCategories.id), unitId: text('unit_id').references(() => catalogUnits.id), salePriceCents: integer('sale_price_cents').notNull().default(0), costCents: integer('cost_cents'), taxPercent: real('tax_percent'), maxDiscountPercent: real('max_discount_percent'), deliveryTerms: text('delivery_terms'), notes: text('notes'), status: text('status').notNull().default('Ativo'), ...timestamps,
}, (t) => [uniqueIndex('uq_catalog_items_owner_code').on(t.ownerId, t.code), index('idx_catalog_items_owner_type_status').on(t.ownerId, t.itemType, t.status)]);

export const companyProfiles = sqliteTable('company_profiles', {
  ownerId: text('owner_id').primaryKey(), companyName: text('company_name'), document: text('document'), phone: text('phone'), whatsapp: text('whatsapp'), email: text('email'), site: text('site'), address: text('address'), footerText: text('footer_text'), commercialNotes: text('commercial_notes'), signatureText: text('signature_text'), logoUrl: text('logo_url'), updatedAt: text('updated_at').notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const catalogHistory = sqliteTable('catalog_history', {
  id: text('id').primaryKey(), ownerId: text('owner_id').notNull(), entityType: text('entity_type').notNull(), entityId: text('entity_id').notNull(), action: text('action').notNull(), details: text('details'), actorName: text('actor_name').notNull().default('Administrador Master'), createdAt: text('created_at').notNull().default(sql`CURRENT_TIMESTAMP`),
}, (t) => [index('idx_catalog_history_owner_time').on(t.ownerId, t.createdAt), index('idx_catalog_history_entity').on(t.entityType, t.entityId)]);

export const quotes = sqliteTable('quotes', {
  id: text('id').primaryKey(), ownerId: text('owner_id').notNull(), number: integer('number').notNull(), status: text('status').notNull().default('Rascunho'), issueDate: text('issue_date').notNull(), validUntil: text('valid_until').notNull(), projectId: text('project_id').references(() => personalProjects.id), projectName: text('project_name'), internalNotes: text('internal_notes'), clientId: text('client_id').references(() => personalClients.id), clientName: text('client_name').notNull(), clientDocument: text('client_document'), clientPhone: text('client_phone'), clientEmail: text('client_email'), clientAddress: text('client_address'), contactName: text('contact_name'), subtotalCents: integer('subtotal_cents').notNull().default(0), itemDiscountCents: integer('item_discount_cents').notNull().default(0), discountCents: integer('discount_cents').notNull().default(0), surchargeCents: integer('surcharge_cents').notNull().default(0), taxCents: integer('tax_cents').notNull().default(0), totalCents: integer('total_cents').notNull().default(0), paymentMethod: text('payment_method'), paymentTerms: text('payment_terms'), deliveryTerms: text('delivery_terms'), ...timestamps,
}, (t) => [uniqueIndex('uq_quotes_owner_number').on(t.ownerId, t.number), index('idx_quotes_owner_status').on(t.ownerId, t.status), index('idx_quotes_owner_updated').on(t.ownerId, t.updatedAt)]);

export const quoteItems = sqliteTable('quote_items', {
  id: text('id').primaryKey(), quoteId: text('quote_id').notNull().references(() => quotes.id), description: text('description').notNull(), quantity: real('quantity').notNull(), unit: text('unit').notNull(), unitPriceCents: integer('unit_price_cents').notNull(), discountType: text('discount_type').notNull().default('percent'), discountValue: real('discount_value').notNull().default(0), totalCents: integer('total_cents').notNull(), position: integer('position').notNull().default(0),
}, (t) => [index('idx_quote_items_quote_position').on(t.quoteId, t.position)]);

export const quoteHistory = sqliteTable('quote_history', {
  id: text('id').primaryKey(), quoteId: text('quote_id').notNull().references(() => quotes.id), actorId: text('actor_id').notNull(), action: text('action').notNull(), fromStatus: text('from_status'), toStatus: text('to_status'), details: text('details'), createdAt: text('created_at').notNull().default(sql`CURRENT_TIMESTAMP`),
}, (t) => [index('idx_quote_history_quote_time').on(t.quoteId, t.createdAt)]);

