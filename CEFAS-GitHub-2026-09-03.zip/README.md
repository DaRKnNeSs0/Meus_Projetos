# CEFAS

Site institucional da CEFAS para apresentação de serviços de desenvolvimento de aplicativos, sites institucionais, landing pages e sistemas administrativos.

O projeto também possui modelos conceituais interativos para demonstrar aos clientes como diferentes soluções digitais podem funcionar.

## Tecnologias

- Next.js e React
- TypeScript
- Vinext e Vite
- Cloudflare Workers, D1 e R2
- CSS responsivo

## Requisitos

- Node.js 22.13 ou superior
- pnpm

## Instalação

```bash
pnpm install
```

## Executar localmente

```bash
pnpm dev -- --port 3001
```

Acesse `http://localhost:3001`.

## Gerar a versão de produção

```bash
pnpm build
```

## Modelos funcionais

- `/projetos/sistemas-administrativos`
- `/projetos/landing-pages`
- `/projetos/sites-institucionais`
- `/projetos/aplicativos`

Todos os modelos são conceituais e utilizam dados ilustrativos.

## Contato

- E-mail: cefasdevofc@gmail.com
- WhatsApp: +55 85 99662-4849
