# Cefas Central — Arquitetura

## Produto

- Painel responsivo e mobile-first para suporte, incidentes e monitoramento.
- API REST no mesmo worker, com autenticação administrativa por ChatGPT e credenciais por projeto para ingestão técnica.
- D1/SQLite multi-tenant para dados relacionais e R2 para anexos.
- SDK fail-safe: envio assíncrono, sanitização, fila limitada, retry com backoff e circuit breaker.

## Fluxos implementados

1. Projeto é cadastrado em `POST /api/projects`; a chave é exibida uma única vez e persistida apenas como SHA-256.
2. O SDK envia erros a `POST /api/errors` com `x-project-id` e `x-project-key`.
3. A Central sanitiza o payload, calcula fingerprint e procura ticket ainda aberto.
4. Se já existir, incrementa ocorrências e preserva a nova evidência. Se não, cria ticket e evento de monitoramento.
5. Heartbeat e health check atualizam a observabilidade sem bloquear o sistema de origem.

## Endpoints

- `GET|POST /api/tickets`
- `POST /api/tickets/:id/comments`
- `GET|POST /api/projects`
- `GET|POST /api/incidents`
- `POST /api/errors`
- `POST /api/heartbeat`
- `POST /api/health`

## Segurança

- Isolamento por `tenant_id`, soft delete, trilha imutável de status e auditoria.
- Chaves de integração ficam no backend do projeto; somente hash é persistido.
- Sanitização recursiva remove senhas, tokens, cookies, chaves privadas e dados bancários.
- Rotas administrativas exigem identidade autenticada; ingestão técnica exige credencial do projeto.
- O SDK nunca lança falha de suporte na operação principal.

## Integração

```ts
const support = CefasSupport.initialize({
  endpoint: 'https://central.exemplo.com',
  projectId: process.env.CEFAS_PROJECT_ID!,
  projectKey: process.env.CEFAS_PROJECT_KEY!,
  environment: 'production',
  version: '2.1.4',
});

support.reportError(error, { module: 'Estoque', route: '/estoque/consulta' });
```

O `PROJECT_KEY` deve ser usado somente no backend. Frontends enviam tickets manuais por sessão autenticada ou por um proxy seguro do próprio projeto.
