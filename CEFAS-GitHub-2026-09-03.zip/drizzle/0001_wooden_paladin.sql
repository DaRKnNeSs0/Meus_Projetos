CREATE TABLE `personal_clients` (
	`id` text PRIMARY KEY NOT NULL,
	`owner_id` text NOT NULL,
	`name` text NOT NULL,
	`document` text,
	`contact_name` text,
	`email` text,
	`phone` text,
	`address` text,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`deleted_at` text
);
--> statement-breakpoint
CREATE INDEX `idx_personal_clients_owner_name` ON `personal_clients` (`owner_id`,`name`);--> statement-breakpoint
CREATE TABLE `personal_projects` (
	`id` text PRIMARY KEY NOT NULL,
	`owner_id` text NOT NULL,
	`client_id` text,
	`code` text NOT NULL,
	`name` text NOT NULL,
	`type` text DEFAULT 'Sistema' NOT NULL,
	`description` text,
	`environment` text DEFAULT 'Desenvolvimento' NOT NULL,
	`version` text,
	`progress` integer DEFAULT 0 NOT NULL,
	`status` text DEFAULT 'Em desenvolvimento' NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`deleted_at` text,
	FOREIGN KEY (`client_id`) REFERENCES `personal_clients`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `uq_personal_projects_owner_code` ON `personal_projects` (`owner_id`,`code`);--> statement-breakpoint
CREATE INDEX `idx_personal_projects_owner_status` ON `personal_projects` (`owner_id`,`status`);--> statement-breakpoint
CREATE TABLE `quote_history` (
	`id` text PRIMARY KEY NOT NULL,
	`quote_id` text NOT NULL,
	`actor_id` text NOT NULL,
	`action` text NOT NULL,
	`from_status` text,
	`to_status` text,
	`details` text,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	FOREIGN KEY (`quote_id`) REFERENCES `quotes`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `idx_quote_history_quote_time` ON `quote_history` (`quote_id`,`created_at`);--> statement-breakpoint
CREATE TABLE `quote_items` (
	`id` text PRIMARY KEY NOT NULL,
	`quote_id` text NOT NULL,
	`description` text NOT NULL,
	`quantity` real NOT NULL,
	`unit` text NOT NULL,
	`unit_price_cents` integer NOT NULL,
	`discount_type` text DEFAULT 'percent' NOT NULL,
	`discount_value` real DEFAULT 0 NOT NULL,
	`total_cents` integer NOT NULL,
	`position` integer DEFAULT 0 NOT NULL,
	FOREIGN KEY (`quote_id`) REFERENCES `quotes`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `idx_quote_items_quote_position` ON `quote_items` (`quote_id`,`position`);--> statement-breakpoint
CREATE TABLE `quotes` (
	`id` text PRIMARY KEY NOT NULL,
	`owner_id` text NOT NULL,
	`number` integer NOT NULL,
	`status` text DEFAULT 'Rascunho' NOT NULL,
	`issue_date` text NOT NULL,
	`valid_until` text NOT NULL,
	`project_id` text,
	`project_name` text,
	`internal_notes` text,
	`client_id` text,
	`client_name` text NOT NULL,
	`client_document` text,
	`client_phone` text,
	`client_email` text,
	`client_address` text,
	`contact_name` text,
	`subtotal_cents` integer DEFAULT 0 NOT NULL,
	`item_discount_cents` integer DEFAULT 0 NOT NULL,
	`discount_cents` integer DEFAULT 0 NOT NULL,
	`surcharge_cents` integer DEFAULT 0 NOT NULL,
	`tax_cents` integer DEFAULT 0 NOT NULL,
	`total_cents` integer DEFAULT 0 NOT NULL,
	`payment_method` text,
	`payment_terms` text,
	`delivery_terms` text,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`deleted_at` text,
	FOREIGN KEY (`project_id`) REFERENCES `personal_projects`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`client_id`) REFERENCES `personal_clients`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `uq_quotes_owner_number` ON `quotes` (`owner_id`,`number`);--> statement-breakpoint
CREATE INDEX `idx_quotes_owner_status` ON `quotes` (`owner_id`,`status`);--> statement-breakpoint
CREATE INDEX `idx_quotes_owner_updated` ON `quotes` (`owner_id`,`updated_at`);