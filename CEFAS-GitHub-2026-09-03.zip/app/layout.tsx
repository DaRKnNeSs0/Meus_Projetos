import type { Metadata } from 'next';
import { Geist, Geist_Mono } from 'next/font/google';
import './globals.css';
import './marketing.css';
import './project-demos.css';

const geistSans = Geist({ variable: '--font-geist-sans', subsets: ['latin'] });
const geistMono = Geist_Mono({ variable: '--font-geist-mono', subsets: ['latin'] });

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL ?? 'http://localhost:3001'),
  title: 'CEFAS | Desenvolvimento de Aplicativos, Sites e Sistemas',
  description: 'Desenvolvimento de aplicativos, sites e sistemas sob medida. A CEFAS transforma ideias em soluções digitais modernas, seguras e preparadas para crescer.',
  keywords: ['desenvolvimento de aplicativos', 'criação de sites', 'desenvolvimento de sistemas', 'sistemas web', 'aplicativos sob medida', 'integrações e APIs', 'suporte de software'],
  openGraph: {
    type: 'website',
    locale: 'pt_BR',
    title: 'CEFAS | Desenvolvimento de Aplicativos, Sites e Sistemas',
    description: 'Aplicativos e sites que transformam ideias em resultados.',
    images: [{ url: '/og.png', width: 1733, height: 907, alt: 'CEFAS — aplicativos e sites que transformam ideias em resultados' }],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'CEFAS | Desenvolvimento de Aplicativos, Sites e Sistemas',
    description: 'Aplicativos e sites que transformam ideias em resultados.',
    images: ['/og.png'],
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="pt-BR"><body className={`${geistSans.variable} ${geistMono.variable}`}>{children}</body></html>;
}
