'use client';

import { FormEvent, useEffect, useMemo, useState } from 'react';

type Client = { id: string; name: string; document?: string; contact_name?: string; email?: string; phone?: string; address?: string; status?: string };
type Project = { id: string; client_id?: string; client_name?: string; code: string; name: string; type: string; description?: string; environment: string; version?: string; start_date?: string; due_date?: string; progress: number; status: string; notes?: string; quote_count?: number };
type Props = { searchQuery: string; onNotify: (message: string, error?: boolean) => void };

const emptyClient = { name: '', document: '', contactName: '', email: '', phone: '', address: '' };
const emptyProject = { clientId: '', code: '', name: '', type: 'Sistema', description: '', environment: 'Desenvolvimento', version: '1.0.0', startDate: '', dueDate: '', progress: 0, status: 'Planejado', notes: '' };

export default function PersonalProjectsModule({ searchQuery, onNotify }: Props) {
  const [clients, setClients] = useState<Client[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('Todos');
  const [clientManagerOpen, setClientManagerOpen] = useState(false);
  const [clientFormOpen, setClientFormOpen] = useState(false);
  const [projectFormOpen, setProjectFormOpen] = useState(false);
  const [editingClient, setEditingClient] = useState<Client | null>(null);
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [clientDraft, setClientDraft] = useState(emptyClient);
  const [projectDraft, setProjectDraft] = useState(emptyProject);
  const [saving, setSaving] = useState(false);

  async function loadData() {
    setLoading(true);
    try {
      const [clientsResponse, projectsResponse] = await Promise.all([fetch('/api/personal-clients', { cache: 'no-store' }), fetch('/api/personal-projects', { cache: 'no-store' })]);
      if (!clientsResponse.ok || !projectsResponse.ok) throw new Error('Não foi possível carregar seus cadastros.');
      const [clientsPayload, projectsPayload] = await Promise.all([clientsResponse.json(), projectsResponse.json()]) as [{ data?: Client[] }, { data?: Project[] }];
      setClients((clientsPayload.data ?? []).filter((client) => client.status !== 'Inativo'));
      setProjects(projectsPayload.data ?? []);
    } catch (error) {
      onNotify(error instanceof Error ? error.message : 'Erro ao carregar projetos.', true);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { void loadData(); }, []);

  const filtered = useMemo(() => projects.filter((project) => {
    const matchesFilter = filter === 'Todos' || project.environment === filter;
    const haystack = `${project.name} ${project.code} ${project.client_name ?? ''} ${project.status}`.toLowerCase();
    return matchesFilter && haystack.includes(searchQuery.toLowerCase());
  }), [projects, filter, searchQuery]);

  function openNewClient() {
    setEditingClient(null);
    setClientDraft(emptyClient);
    setClientFormOpen(true);
  }

  function openEditClient(client: Client) {
    setEditingClient(client);
    setClientDraft({ name: client.name, document: client.document ?? '', contactName: client.contact_name ?? '', email: client.email ?? '', phone: client.phone ?? '', address: client.address ?? '' });
    setClientFormOpen(true);
  }

  function openNewProject() {
    setEditingProject(null);
    setProjectDraft({ ...emptyProject, clientId: clients[0]?.id ?? '' });
    setProjectFormOpen(true);
  }

  function openEditProject(project: Project) {
    setEditingProject(project);
    setProjectDraft({ clientId: project.client_id ?? '', code: project.code, name: project.name, type: project.type, description: project.description ?? '', environment: project.environment, version: project.version ?? '1.0.0', startDate: project.start_date ?? '', dueDate: project.due_date ?? '', progress: project.progress, status: project.status, notes: project.notes ?? '' });
    setProjectFormOpen(true);
  }

  async function saveClient(event: FormEvent) {
    event.preventDefault();
    setSaving(true);
    try {
      const response = await fetch(editingClient ? `/api/personal-clients/${editingClient.id}` : '/api/personal-clients', { method: editingClient ? 'PATCH' : 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(clientDraft) });
      if (!response.ok) throw new Error('Revise os dados do cliente.');
      setClientFormOpen(false);
      await loadData();
      onNotify(editingClient ? 'Cliente atualizado com sucesso.' : 'Cliente cadastrado com sucesso.');
    } catch (error) { onNotify(error instanceof Error ? error.message : 'Erro ao salvar cliente.', true); }
    finally { setSaving(false); }
  }

  async function saveProject(event: FormEvent) {
    event.preventDefault();
    if (!projectDraft.clientId) { onNotify('Cadastre e selecione um cliente antes de salvar o projeto.', true); return; }
    setSaving(true);
    try {
      const response = await fetch(editingProject ? `/api/personal-projects/${editingProject.id}` : '/api/personal-projects', { method: editingProject ? 'PATCH' : 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(projectDraft) });
      if (!response.ok) throw new Error('Revise o código e os dados do projeto.');
      setProjectFormOpen(false);
      await loadData();
      onNotify(editingProject ? 'Projeto atualizado com sucesso.' : 'Projeto cadastrado com sucesso.');
    } catch (error) { onNotify(error instanceof Error ? error.message : 'Erro ao salvar projeto.', true); }
    finally { setSaving(false); }
  }

  const productionCount = projects.filter((project) => project.environment === 'Produção').length;
  const averageProgress = projects.length ? Math.round(projects.reduce((sum, project) => sum + Number(project.progress), 0) / projects.length) : 0;

  return <section className="module-page personal-projects-module">
    <div className="module-toolbar">
      <div className="filter-tabs">
        {['Todos', 'Produção', 'Homologação', 'Desenvolvimento'].map((item) => <button key={item} className={filter === item ? 'active' : ''} onClick={() => setFilter(item)}>{item}{item === 'Todos' && <b>{projects.length}</b>}</button>)}
      </div>
      <div className="project-actions"><button className="module-secondary" onClick={() => setClientManagerOpen(true)}>◎ Meus clientes</button><button className="module-primary" onClick={openNewProject}>＋ Novo projeto</button></div>
    </div>
    <div className="project-summary">
      <article><span>Meus projetos</span><strong>{projects.length}</strong><small>todos cadastrados por você</small></article>
      <article><span>Meus clientes</span><strong>{clients.length}</strong><small>base pessoal exclusiva</small></article>
      <article><span>Em produção</span><strong>{productionCount}</strong><small>projetos ativos</small></article>
      <article><span>Progresso médio</span><strong>{averageProgress}%</strong><small>responsável: você</small></article>
    </div>
    <section className="panel project-panel">
      <div className="panel-heading"><div><h2>Portfólio pessoal de projetos</h2><p>Somente clientes criados por você • responsável fixo: Administrador Master</p></div><button onClick={openNewProject}>Cadastrar projeto</button></div>
      <div className="project-table personal-project-table">
        <div className="project-row project-head"><span>Projeto</span><span>Cliente</span><span>Responsável</span><span>Ambiente</span><span>Progresso</span><span>Status</span><span>Ações</span></div>
        {loading && <div className="module-empty">Carregando seus projetos…</div>}
        {!loading && filtered.length === 0 && <div className="module-empty"><strong>Nenhum projeto encontrado.</strong><span>Cadastre primeiro um cliente e depois crie seu projeto.</span><button onClick={() => setClientManagerOpen(true)}>Cadastrar cliente</button></div>}
        {filtered.map((project, index) => <div className="project-row" key={project.id}><span className="project-name"><i className={`project-icon logo-${index % 4}`}>{project.name.split(' ').map((word) => word[0]).join('').slice(0, 2)}</i><span><strong>{project.name}</strong><small>{project.code} • v{project.version || '1.0.0'}</small></span></span><span>{project.client_name || 'Sem cliente'}</span><span><b className="owner-chip">AM</b> Administrador Master</span><span><em>{project.environment}</em></span><span className="project-progress"><i><b style={{ width: `${project.progress}%` }} /></i><small>{project.progress}%</small></span><span className="project-status online"><i />{project.status}</span><span className="row-actions"><button onClick={() => openEditProject(project)}>Editar</button></span></div>)}
      </div>
    </section>

    {clientManagerOpen && <div className="overlay" onMouseDown={() => setClientManagerOpen(false)}><section className="dialog client-manager" onMouseDown={(event) => event.stopPropagation()}><div className="dialog-head"><div><p>BASE PESSOAL</p><h2>Meus clientes</h2><span>Somente estes clientes aparecerão nos projetos e orçamentos.</span></div><button onClick={() => setClientManagerOpen(false)}>×</button></div><div className="client-manager-body"><button className="module-primary" onClick={openNewClient}>＋ Cadastrar cliente</button>{clients.length === 0 ? <div className="module-empty"><strong>Nenhum cliente cadastrado.</strong><span>Crie o primeiro para começar.</span></div> : <div className="personal-client-list">{clients.map((client) => <article key={client.id}><div><strong>{client.name}</strong><span>{client.document || 'Documento não informado'} • {client.contact_name || 'Sem responsável informado'}</span><small>{client.email || 'E-mail não informado'} · {client.phone || 'Telefone não informado'}</small></div><button onClick={() => openEditClient(client)}>Editar</button></article>)}</div>}</div></section></div>}

    {clientFormOpen && <div className="overlay" onMouseDown={() => setClientFormOpen(false)}><section className="dialog" onMouseDown={(event) => event.stopPropagation()}><div className="dialog-head"><div><p>CLIENTE PESSOAL</p><h2>{editingClient ? 'Editar cliente' : 'Cadastrar cliente'}</h2><span>Os dados ficarão disponíveis apenas no seu aplicativo.</span></div><button onClick={() => setClientFormOpen(false)}>×</button></div><form onSubmit={saveClient}><label>Nome ou razão social<input required value={clientDraft.name} onChange={(event) => setClientDraft({ ...clientDraft, name: event.target.value })} /></label><div className="form-row"><label>CPF ou CNPJ<input value={clientDraft.document} onChange={(event) => setClientDraft({ ...clientDraft, document: event.target.value })} /></label><label>Responsável no cliente<input value={clientDraft.contactName} onChange={(event) => setClientDraft({ ...clientDraft, contactName: event.target.value })} /></label></div><div className="form-row"><label>E-mail<input type="email" value={clientDraft.email} onChange={(event) => setClientDraft({ ...clientDraft, email: event.target.value })} /></label><label>Telefone<input value={clientDraft.phone} onChange={(event) => setClientDraft({ ...clientDraft, phone: event.target.value })} /></label></div><label>Endereço completo<textarea rows={3} value={clientDraft.address} onChange={(event) => setClientDraft({ ...clientDraft, address: event.target.value })} /></label><div className="dialog-actions"><button type="button" onClick={() => setClientFormOpen(false)}>Cancelar</button><button type="submit" disabled={saving}>{saving ? 'Salvando…' : 'Salvar cliente'}</button></div></form></section></div>}

    {projectFormOpen && <div className="overlay" onMouseDown={() => setProjectFormOpen(false)}><section className="dialog wide-dialog" onMouseDown={(event) => event.stopPropagation()}><div className="dialog-head"><div><p>PROJETO PESSOAL</p><h2>{editingProject ? 'Editar projeto' : 'Cadastrar projeto'}</h2><span>Responsável definido automaticamente como Administrador Master.</span></div><button onClick={() => setProjectFormOpen(false)}>×</button></div><form onSubmit={saveProject}><div className="form-row"><label>Cliente<select required value={projectDraft.clientId} onChange={(event) => setProjectDraft({ ...projectDraft, clientId: event.target.value })}><option value="">Selecione um cliente</option>{clients.map((client) => <option value={client.id} key={client.id}>{client.name}</option>)}</select></label><label>Responsável<input value="Administrador Master" disabled /></label></div><div className="form-row"><label>Nome do projeto<input required value={projectDraft.name} onChange={(event) => setProjectDraft({ ...projectDraft, name: event.target.value })} /></label><label>Código<input required placeholder="Ex.: PRJ-001" value={projectDraft.code} onChange={(event) => setProjectDraft({ ...projectDraft, code: event.target.value.toUpperCase() })} /></label></div><div className="form-row"><label>Tipo<input value={projectDraft.type} onChange={(event) => setProjectDraft({ ...projectDraft, type: event.target.value })} /></label><label>Versão<input value={projectDraft.version} onChange={(event) => setProjectDraft({ ...projectDraft, version: event.target.value })} /></label></div><div className="form-row"><label>Data de início<input type="date" value={projectDraft.startDate} onChange={(event) => setProjectDraft({ ...projectDraft, startDate: event.target.value })} /></label><label>Previsão de conclusão<input type="date" min={projectDraft.startDate} value={projectDraft.dueDate} onChange={(event) => setProjectDraft({ ...projectDraft, dueDate: event.target.value })} /></label></div><div className="form-row"><label>Ambiente<select value={projectDraft.environment} onChange={(event) => setProjectDraft({ ...projectDraft, environment: event.target.value })}><option>Desenvolvimento</option><option>Homologação</option><option>Produção</option></select></label><label>Status<select value={projectDraft.status} onChange={(event) => setProjectDraft({ ...projectDraft, status: event.target.value })}><option>Planejado</option><option>Em desenvolvimento</option><option>Em homologação</option><option>Em produção</option><option>Concluído</option><option>Pausado</option><option>Cancelado</option></select></label></div><label>Progresso: {projectDraft.progress}%<input type="range" min="0" max="100" value={projectDraft.progress} onChange={(event) => setProjectDraft({ ...projectDraft, progress: Number(event.target.value) })} /></label><label>Descrição<textarea rows={3} value={projectDraft.description} onChange={(event) => setProjectDraft({ ...projectDraft, description: event.target.value })} /></label><label>Observações<textarea rows={2} value={projectDraft.notes} onChange={(event) => setProjectDraft({ ...projectDraft, notes: event.target.value })} /></label><div className="dialog-actions"><button type="button" onClick={() => setProjectFormOpen(false)}>Cancelar</button><button type="submit" disabled={saving}>{saving ? 'Salvando…' : 'Salvar projeto'}</button></div></form></section></div>}
  </section>;
}
