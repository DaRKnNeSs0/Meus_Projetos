'use client';

import { useEffect, useRef, useState } from 'react';

type Category = 'Aplicativos' | 'Sites institucionais' | 'E-commerces' | 'Sistemas web' | 'Landing pages';
type ProjectModel = {
  id: string;
  category: Category;
  filters?: Category[];
  title: string;
  description: string;
  screens: string[];
  features: string[];
};

const filters: Array<'Todos' | Category> = ['Todos', 'Aplicativos', 'Sites institucionais', 'E-commerces', 'Sistemas web', 'Landing pages'];

const models: ProjectModel[] = [
  { id: 'delivery', category: 'Aplicativos', title: 'Delivery e pedidos', description: 'Aplicativo para apresentação de produtos, pedidos, pagamento e acompanhamento da entrega.', screens: ['Página inicial', 'Categorias', 'Detalhes do produto', 'Carrinho', 'Acompanhamento'], features: ['Catálogo', 'Pagamento', 'Notificações', 'Rastreamento'] },
  { id: 'services', category: 'Aplicativos', title: 'Agendamento de serviços', description: 'Aplicativo para encontrar profissionais, escolher horários e acompanhar atendimentos.', screens: ['Serviços', 'Perfil profissional', 'Agenda', 'Confirmação', 'Histórico'], features: ['Agendamento', 'Avaliações', 'Calendário', 'WhatsApp'] },
  { id: 'management-app', category: 'Aplicativos', title: 'Gestão na palma da mão', description: 'Indicadores, tarefas e informações importantes para acompanhar a empresa de qualquer lugar.', screens: ['Visão geral', 'Indicadores', 'Tarefas', 'Relatórios', 'Notificações'], features: ['Dashboard', 'Relatórios', 'Equipe', 'Alertas'] },
  { id: 'business-site', category: 'Sites institucionais', title: 'Presença digital profissional', description: 'Site institucional para apresentar a empresa, serviços, diferenciais e canais de contato.', screens: ['Página inicial', 'Sobre', 'Serviços', 'Projetos', 'Contato'], features: ['Design responsivo', 'SEO', 'WhatsApp', 'Formulário'] },
  { id: 'portfolio-site', category: 'Sites institucionais', filters: ['Sites institucionais', 'Landing pages'], title: 'Portfólio profissional', description: 'Site para profissionais apresentarem trabalhos, especialidades e formas de contratação.', screens: ['Apresentação', 'Especialidades', 'Portfólio', 'Espaços ilustrativos', 'Contato'], features: ['Portfólio', 'Agendamento', 'Redes sociais', 'Contato'] },
  { id: 'clinic-site', category: 'Sites institucionais', title: 'Clínica e atendimento', description: 'Site informativo para apresentar especialidades, profissionais e facilitar o agendamento.', screens: ['Clínica', 'Especialidades', 'Equipe', 'Dúvidas', 'Agendamento'], features: ['Agendamento', 'Equipe', 'Localização', 'WhatsApp'] },
  { id: 'complete-store', category: 'E-commerces', title: 'E-commerce completo', description: 'Loja virtual preparada para apresentar produtos e oferecer uma experiência de compra simples e segura.', screens: ['Página inicial', 'Categorias', 'Produto', 'Carrinho', 'Checkout'], features: ['Catálogo', 'Estoque', 'Cupons', 'Pagamento', 'Frete'] },
  { id: 'fashion-store', category: 'E-commerces', title: 'Coleção e estilo', description: 'E-commerce visual para marcas de roupas, acessórios e produtos de moda.', screens: ['Coleções', 'Vitrine', 'Produto', 'Favoritos', 'Checkout'], features: ['Variações', 'Favoritos', 'Filtros', 'Carrinho', 'Checkout'] },
  { id: 'admin-system', category: 'Sistemas web', title: 'Central de gestão', description: 'Painel para centralizar clientes, projetos, documentos, tarefas e indicadores.', screens: ['Dashboard', 'Clientes', 'Projetos', 'Financeiro', 'Relatórios'], features: ['Gestão', 'Indicadores', 'Permissões', 'Relatórios'] },
  { id: 'client-portal', category: 'Sistemas web', title: 'Área exclusiva do cliente', description: 'Portal para compartilhar documentos, acompanhar solicitações e manter a comunicação organizada.', screens: ['Acesso', 'Visão geral', 'Documentos', 'Chamados', 'Mensagens'], features: ['Login', 'Documentos', 'Chamados', 'Mensagens', 'Histórico'] },
  { id: 'launch-landing', category: 'Landing pages', title: 'Landing page de lançamento', description: 'Página focada em apresentar uma oferta, destacar benefícios e conduzir visitantes ao contato ou à compra.', screens: ['Apresentação', 'Benefícios', 'Como funciona', 'Dúvidas frequentes', 'Conversão'], features: ['Design responsivo', 'SEO', 'Formulário', 'WhatsApp', 'Métricas'] },
];

function ModelMockup({ model, screen, expanded = false }: { model: ProjectModel; screen: string; expanded?: boolean }) {
  const type = model.category === 'Aplicativos' ? 'app' : model.category === 'E-commerces' ? 'commerce' : model.category === 'Sistemas web' ? 'system' : 'site';
  return (
    <div className={`model-mockup ${type} ${expanded ? 'expanded' : ''}`} aria-label={`Prévia ilustrativa: ${screen}`}>
      {type === 'app' ? <div className="model-phone"><div className="model-phone-notch" /><div className="model-ui-top"><span>CEFAS</span><i>•••</i></div><small>{screen}</small><strong>{model.title}</strong><div className="model-app-hero"><i /><i /><i /></div><div className="model-app-lines"><span /><span /><span /></div><div className="model-app-nav"><i /><i /><i /><i /></div></div> :
      <div className="model-browser"><div className="model-browser-top"><i /><i /><i /><span>modelo-conceitual</span></div><div className="model-browser-body"><aside><b>{model.category === 'E-commerces' ? 'LOJA' : model.category === 'Sistemas web' ? 'PAINEL' : 'MARCA'}</b><span>Início</span><span>Seções</span><span>Contato</span></aside><section><small>{screen.toUpperCase()}</small><strong>{model.title}</strong>{type === 'commerce' ? <div className="model-products"><i /><i /><i /></div> : type === 'system' ? <div className="model-dashboard"><i /><i /><i /><span /></div> : <div className="model-site-layout"><span /><b /><i /><i /></div>}</section></div></div>}
    </div>
  );
}

function ModelCard({ model, onView, onRequest }: { model: ProjectModel; onView: () => void; onRequest: () => void }) {
  return (
    <article className="model-card">
      <div className="model-card-preview"><span className="concept-pill">Modelo conceitual</span><ModelMockup model={model} screen={model.screens[0]} /></div>
      <div className="model-card-copy"><span className="model-category">{model.category}</span><h3>{model.title}</h3><p>{model.description}</p><div className="model-features">{model.features.map((feature)=><span key={feature}>{feature}</span>)}</div><div className="model-actions"><button type="button" onClick={onView}>Visualizar modelo</button><button className="model-request" type="button" onClick={onRequest}>Quero um projeto assim <b>→</b></button></div></div>
    </article>
  );
}

export default function ModelsGallery({ onRequestProject }: { onRequestProject: (type: string) => void }) {
  const [activeFilter, setActiveFilter] = useState<(typeof filters)[number]>('Todos');
  const [selected, setSelected] = useState<ProjectModel | null>(null);
  const [screenIndex, setScreenIndex] = useState(0);
  const closeButtonRef = useRef<HTMLButtonElement>(null);
  const previousFocus = useRef<HTMLElement | null>(null);
  const visible = activeFilter === 'Todos' ? models : models.filter((model)=>model.category === activeFilter || model.filters?.includes(activeFilter as Category));

  function openModel(model: ProjectModel) {
    previousFocus.current = document.activeElement as HTMLElement;
    setScreenIndex(0);
    setSelected(model);
  }
  function closeModel() {
    setSelected(null);
    window.setTimeout(()=>previousFocus.current?.focus(), 0);
  }
  function request(model: ProjectModel) {
    const formType = model.category === 'Aplicativos' ? 'Aplicativo' : model.category === 'E-commerces' ? 'E-commerce' : model.category === 'Sistemas web' ? 'Sistema web' : 'Site';
    onRequestProject(formType);
    setSelected(null);
  }

  useEffect(()=>{
    if (!selected) return;
    closeButtonRef.current?.focus();
    const onKeyDown = (event: KeyboardEvent) => { if (event.key === 'Escape') closeModel(); };
    document.addEventListener('keydown', onKeyDown);
    return ()=>document.removeEventListener('keydown', onKeyDown);
  }, [selected]);

  return (
    <section className="section models-section" id="modelos">
      <div className="section-heading centered"><p className="section-kicker">MODELOS ILUSTRATIVOS</p><h2>Veja o que podemos criar<br />para o seu negócio.</h2><p>Explore exemplos conceituais de aplicativos, sites, lojas virtuais e sistemas. Cada solução pode ser personalizada de acordo com a identidade e as necessidades do seu projeto.</p></div>
      <div className="models-filters" role="group" aria-label="Filtrar modelos">{filters.map((filter)=><button type="button" key={filter} className={activeFilter===filter?'active':''} aria-pressed={activeFilter===filter} onClick={()=>setActiveFilter(filter)}>{filter}<span>{filter==='Todos'?models.length:models.filter((model)=>model.category===filter||model.filters?.includes(filter as Category)).length}</span></button>)}</div>
      <div className="models-grid" aria-live="polite">{visible.map((model)=><ModelCard key={model.id} model={model} onView={()=>openModel(model)} onRequest={()=>request(model)} />)}</div>
      <div className="models-cta"><div><p className="section-kicker">SEU PROJETO, DO SEU JEITO</p><h3>Gostou de algum modelo?</h3><span>Use estes exemplos como ponto de partida. A CEFAS adapta o visual, as funcionalidades e a tecnologia às necessidades do seu negócio.</span></div><div><button className="button" type="button" onClick={()=>onRequestProject('Ainda não sei')}>Quero um projeto assim <b>→</b></button><a className="button button-ghost" href="#contato">Solicitar orçamento</a></div></div>

      {selected&&<div className="model-modal-overlay" onMouseDown={closeModel}><section className="model-modal" role="dialog" aria-modal="true" aria-labelledby="model-modal-title" onMouseDown={(event)=>event.stopPropagation()}><div className="model-modal-head"><div><span>MODELO CONCEITUAL • {selected.category}</span><h2 id="model-modal-title">{selected.title}</h2></div><button ref={closeButtonRef} type="button" onClick={closeModel} aria-label="Fechar visualização">×</button></div><div className="model-modal-body"><div className="model-modal-preview"><ModelMockup model={selected} screen={selected.screens[screenIndex]} expanded /><div className="screen-switcher" role="group" aria-label="Telas do modelo">{selected.screens.map((screen,index)=><button type="button" key={screen} className={screenIndex===index?'active':''} aria-pressed={screenIndex===index} onClick={()=>setScreenIndex(index)}><span>{String(index+1).padStart(2,'0')}</span>{screen}</button>)}</div></div><div className="model-modal-info"><span className="model-category">PROPOSTA ILUSTRATIVA</span><h3>Uma base para imaginar o seu projeto.</h3><p>{selected.description}</p><h4>Funcionalidades possíveis</h4><div className="model-modal-features">{selected.features.map((feature)=><span key={feature}>✓ {feature}</span>)}</div><div className="concept-warning"><i>i</i><span>Este é um modelo ilustrativo e pode ser totalmente personalizado.</span></div><button className="button" type="button" onClick={()=>request(selected)}>Solicitar um projeto semelhante <b>→</b></button></div></div></section></div>}
    </section>
  );
}
