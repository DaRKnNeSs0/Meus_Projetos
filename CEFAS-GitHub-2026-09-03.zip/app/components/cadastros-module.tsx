'use client';

import { useEffect, useMemo, useState } from 'react';
import type { FormEvent } from 'react';
import PersonalProjectsModule from './personal-projects-module';

type Props = { searchQuery: string; onNotify: (message: string, error?: boolean) => void };
type Tab = 'Clientes' | 'Projetos' | 'Itens' | 'Categorias' | 'Unidades' | 'Pagamentos' | 'Minha empresa';
type Client = Record<string, unknown> & { id: string; code?: string; name: string; trade_name?: string; document?: string; contact_name?: string; email?: string; phone?: string; status?: string; project_count?: number; quote_count?: number };
type CatalogRecord = Record<string, unknown> & { id: string; name: string; status?: string; updated_at?: string };
type History = { id: string; entity_type: string; action: string; details?: string; actor_name: string; created_at: string };

const tabs: Array<{ id: Tab; icon: string; label: string }> = [
  { id: 'Clientes', icon: '◎', label: 'Clientes' }, { id: 'Projetos', icon: '▰', label: 'Projetos' }, { id: 'Itens', icon: '▦', label: 'Produtos e serviços' }, { id: 'Categorias', icon: '◇', label: 'Categorias' }, { id: 'Unidades', icon: '⌗', label: 'Unidades' }, { id: 'Pagamentos', icon: '◉', label: 'Formas de pagamento' }, { id: 'Minha empresa', icon: '◆', label: 'Dados da empresa' },
];
const emptyClient = { code: '', personType: 'Pessoa jurídica', name: '', tradeName: '', document: '', stateRegistration: '', contactName: '', phone: '', whatsapp: '', email: '', postalCode: '', address: '', addressNumber: '', addressComplement: '', neighborhood: '', city: '', state: '', notes: '', status: 'Ativo' };
const emptyItem = { code: '', itemType: 'Serviço', name: '', description: '', categoryId: '', unitId: '', salePrice: 0, cost: 0, taxPercent: 0, maxDiscountPercent: 0, deliveryTerms: '', notes: '', status: 'Ativo' };
const emptyCategory = { name: '', entityType: 'Produto ou serviço', description: '', color: '#287cec', status: 'Ativo' };
const emptyUnit = { name: '', abbreviation: '', allowsDecimal: false, status: 'Ativo' };
const emptyPayment = { name: '', type: 'À vista', installments: 1, intervalDays: 0, defaultTerms: '', notes: '', status: 'Ativo' };
const emptyCompany = { companyName: '', document: '', phone: '', whatsapp: '', email: '', site: '', address: '', footerText: '', commercialNotes: '', signatureText: '', logoUrl: '/cefas-logo-clean.png' };
const money = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
const formatMoney = (cents: unknown) => money.format((Number(cents) || 0) / 100);
const formatDateTime = (value?: string) => value ? new Intl.DateTimeFormat('pt-BR', { dateStyle: 'short', timeStyle: 'short' }).format(new Date(value.replace(' ', 'T') + (value.includes('Z') ? '' : 'Z'))) : '—';

function labelFor(tab: Tab) {
  return tab === 'Itens' ? 'item' : tab === 'Categorias' ? 'categoria' : tab === 'Unidades' ? 'unidade' : tab === 'Pagamentos' ? 'forma de pagamento' : tab === 'Clientes' ? 'cliente' : 'cadastro';
}

export default function CadastrosModule({ searchQuery, onNotify }: Props) {
  const [activeTab, setActiveTab] = useState<Tab>('Clientes');
  const [clients, setClients] = useState<Client[]>([]);
  const [items, setItems] = useState<CatalogRecord[]>([]);
  const [categories, setCategories] = useState<CatalogRecord[]>([]);
  const [units, setUnits] = useState<CatalogRecord[]>([]);
  const [payments, setPayments] = useState<CatalogRecord[]>([]);
  const [projectsCount, setProjectsCount] = useState(0);
  const [history, setHistory] = useState<History[]>([]);
  const [company, setCompany] = useState(emptyCompany);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState<Record<string, unknown>>(emptyClient);
  const [sortAsc, setSortAsc] = useState(true);
  const [page, setPage] = useState(1);

  async function loadAll() {
    setLoading(true);
    try {
      const responses = await Promise.all(['/api/personal-clients', '/api/personal-projects', '/api/catalog/items', '/api/catalog/categories', '/api/catalog/units', '/api/catalog/payments', '/api/company-profile', '/api/catalog-history'].map((url) => fetch(url, { cache: 'no-store' })));
      if (responses.some((response) => !response.ok)) throw new Error('Não foi possível carregar a central de cadastros.');
      const payloads = await Promise.all(responses.map((response) => response.json())) as Array<{ data?: unknown }>;
      setClients((payloads[0].data as Client[]) ?? []);
      setProjectsCount(((payloads[1].data as unknown[]) ?? []).length);
      setItems((payloads[2].data as CatalogRecord[]) ?? []);
      setCategories((payloads[3].data as CatalogRecord[]) ?? []);
      setUnits((payloads[4].data as CatalogRecord[]) ?? []);
      setPayments((payloads[5].data as CatalogRecord[]) ?? []);
      const profile = payloads[6].data as Record<string, unknown> | null;
      if (profile) setCompany({ companyName: String(profile.company_name ?? ''), document: String(profile.document ?? ''), phone: String(profile.phone ?? ''), whatsapp: String(profile.whatsapp ?? ''), email: String(profile.email ?? ''), site: String(profile.site ?? ''), address: String(profile.address ?? ''), footerText: String(profile.footer_text ?? ''), commercialNotes: String(profile.commercial_notes ?? ''), signatureText: String(profile.signature_text ?? ''), logoUrl: String(profile.logo_url ?? '/cefas-logo-clean.png') });
      setHistory((payloads[7].data as History[]) ?? []);
    } catch (error) { onNotify(error instanceof Error ? error.message : 'Erro ao carregar cadastros.', true); }
    finally { setLoading(false); }
  }

  useEffect(() => { void loadAll(); }, []);
  useEffect(() => { setPage(1); }, [activeTab, searchQuery]);

  const activeRecords = activeTab === 'Clientes' ? clients : activeTab === 'Itens' ? items : activeTab === 'Categorias' ? categories : activeTab === 'Unidades' ? units : activeTab === 'Pagamentos' ? payments : [];
  const filteredRecords = useMemo(() => activeRecords.filter((record) => Object.values(record).some((value) => String(value ?? '').toLowerCase().includes(searchQuery.toLowerCase()))).sort((a, b) => (sortAsc ? 1 : -1) * String(a.name ?? '').localeCompare(String(b.name ?? ''), 'pt-BR')), [activeRecords, searchQuery, sortAsc]);
  const pageSize = 10;
  const pageCount = Math.max(1, Math.ceil(filteredRecords.length / pageSize));
  const paginated = filteredRecords.slice((page - 1) * pageSize, page * pageSize);
  const inactive = [...clients, ...items, ...categories, ...units, ...payments].filter((record) => record.status === 'Inativo').length;

  function openNew() {
    if (activeTab === 'Projetos' || activeTab === 'Minha empresa') return;
    setEditingId(null);
    setDraft(activeTab === 'Clientes' ? emptyClient : activeTab === 'Itens' ? emptyItem : activeTab === 'Categorias' ? emptyCategory : activeTab === 'Unidades' ? emptyUnit : emptyPayment);
    setModalOpen(true);
  }

  function openEdit(record: CatalogRecord | Client) {
    setEditingId(record.id);
    if (activeTab === 'Clientes') setDraft({ code: record.code ?? '', personType: record.person_type ?? 'Pessoa jurídica', name: record.name ?? '', tradeName: record.trade_name ?? '', document: record.document ?? '', stateRegistration: record.state_registration ?? '', contactName: record.contact_name ?? '', phone: record.phone ?? '', whatsapp: record.whatsapp ?? '', email: record.email ?? '', postalCode: record.postal_code ?? '', address: record.address ?? '', addressNumber: record.address_number ?? '', addressComplement: record.address_complement ?? '', neighborhood: record.neighborhood ?? '', city: record.city ?? '', state: record.state ?? '', notes: record.notes ?? '', status: record.status ?? 'Ativo' });
    else if (activeTab === 'Itens') setDraft({ code: record.code ?? '', itemType: record.item_type ?? 'Serviço', name: record.name ?? '', description: record.description ?? '', categoryId: record.category_id ?? '', unitId: record.unit_id ?? '', salePrice: Number(record.sale_price_cents ?? 0) / 100, cost: Number(record.cost_cents ?? 0) / 100, taxPercent: record.tax_percent ?? 0, maxDiscountPercent: record.max_discount_percent ?? 0, deliveryTerms: record.delivery_terms ?? '', notes: record.notes ?? '', status: record.status ?? 'Ativo' });
    else if (activeTab === 'Categorias') setDraft({ name: record.name ?? '', entityType: record.entity_type ?? 'Produto ou serviço', description: record.description ?? '', color: record.color ?? '#287cec', status: record.status ?? 'Ativo' });
    else if (activeTab === 'Unidades') setDraft({ name: record.name ?? '', abbreviation: record.abbreviation ?? '', allowsDecimal: Boolean(record.allows_decimal), status: record.status ?? 'Ativo' });
    else setDraft({ name: record.name ?? '', type: record.type ?? 'À vista', installments: record.installments ?? 1, intervalDays: record.interval_days ?? 0, defaultTerms: record.default_terms ?? '', notes: record.notes ?? '', status: record.status ?? 'Ativo' });
    setModalOpen(true);
  }

  function change(field: string, value: unknown) { setDraft((current) => ({ ...current, [field]: value })); }

  async function save(event: FormEvent) {
    event.preventDefault();
    setSaving(true);
    try {
      const entity = activeTab === 'Clientes' ? 'personal-clients' : activeTab === 'Itens' ? 'catalog/items' : activeTab === 'Categorias' ? 'catalog/categories' : activeTab === 'Unidades' ? 'catalog/units' : 'catalog/payments';
      const url = editingId ? `/api/${entity}/${editingId}` : `/api/${entity}`;
      const body = activeTab === 'Itens' ? { ...draft, salePriceCents: Math.round(Number(draft.salePrice || 0) * 100), costCents: Math.round(Number(draft.cost || 0) * 100) } : draft;
      const response = await fetch(url, { method: editingId ? 'PATCH' : 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
      if (!response.ok) { const payload = await response.json() as { error?: string }; throw new Error(payload.error === 'duplicate_document' ? 'CPF ou CNPJ já cadastrado.' : payload.error === 'duplicate_record' ? 'Já existe um cadastro com esse nome ou código.' : 'Revise os campos obrigatórios.'); }
      setModalOpen(false);
      await loadAll();
      onNotify(`${labelFor(activeTab)} ${editingId ? 'atualizado' : 'cadastrado'} com sucesso.`);
    } catch (error) { onNotify(error instanceof Error ? error.message : 'Erro ao salvar cadastro.', true); }
    finally { setSaving(false); }
  }

  async function deactivate(record: CatalogRecord | Client) {
    if (!window.confirm(`Inativar ${record.name}? O histórico será preservado.`)) return;
    const entity = activeTab === 'Clientes' ? 'personal-clients' : activeTab === 'Itens' ? 'catalog/items' : activeTab === 'Categorias' ? 'catalog/categories' : activeTab === 'Unidades' ? 'catalog/units' : 'catalog/payments';
    const response = await fetch(`/api/${entity}/${record.id}`, { method: 'DELETE' });
    if (!response.ok) { onNotify('Não foi possível inativar o cadastro.', true); return; }
    await loadAll();
    onNotify(`${record.name} foi inativado.`);
  }

  async function duplicateItem(record: CatalogRecord) {
    const response = await fetch(`/api/catalog/items/${record.id}`, { method: 'POST' });
    if (!response.ok) { onNotify('Não foi possível duplicar o item.', true); return; }
    await loadAll();
    onNotify('Item duplicado com sucesso.');
  }

  async function saveCompany(event: FormEvent) {
    event.preventDefault(); setSaving(true);
    try { const response = await fetch('/api/company-profile', { method: 'PUT', headers: { 'content-type': 'application/json' }, body: JSON.stringify(company) }); if (!response.ok) throw new Error(); await loadAll(); onNotify('Dados da empresa atualizados.'); }
    catch { onNotify('Não foi possível salvar os dados da empresa.', true); }
    finally { setSaving(false); }
  }

  return <section className="module-page registrations-module">
    <div className="registration-hero"><div><span>BASE MESTRA PESSOAL</span><h2>Central de Cadastros</h2><p>Uma única fonte para clientes, projetos, itens, pagamentos e documentos.</p></div><div>{activeTab !== 'Projetos' && activeTab !== 'Minha empresa' && <button className="module-primary" onClick={openNew}>＋ Novo cadastro</button>}</div></div>
    <div className="registration-metrics"><article><span>Clientes</span><strong>{clients.length}</strong><small>somente seus cadastros</small></article><article><span>Projetos</span><strong>{projectsCount}</strong><small>responsável: Administrador Master</small></article><article><span>Produtos e serviços</span><strong>{items.length}</strong><small>catálogo comercial</small></article><article><span>Categorias</span><strong>{categories.length}</strong><small>organização central</small></article><article><span>Cadastros inativos</span><strong>{inactive}</strong><small>histórico preservado</small></article></div>
    <div className="registration-layout"><aside className="registration-tabs">{tabs.map((tab) => <button key={tab.id} className={activeTab === tab.id ? 'active' : ''} onClick={() => setActiveTab(tab.id)}><i>{tab.icon}</i><span>{tab.label}</span><b>›</b></button>)}</aside><div className="registration-content">
      {activeTab === 'Projetos' ? <PersonalProjectsModule searchQuery={searchQuery} onNotify={onNotify} /> : activeTab === 'Minha empresa' ? <CompanyForm company={company} setCompany={setCompany} onSubmit={saveCompany} saving={saving} /> : <>
        <div className="registration-toolbar"><div><h3>{tabs.find((tab) => tab.id === activeTab)?.label}</h3><p>{filteredRecords.length} registro(s) • dados privados da sua conta</p></div><button onClick={() => setSortAsc((current) => !current)}>Ordenar {sortAsc ? 'A–Z' : 'Z–A'} ↕</button></div>
        <div className="master-table"><div className={`master-row master-head master-${activeTab.toLowerCase()}`}>{activeTab === 'Clientes' ? <><span>Código / Cliente</span><span>Documento</span><span>Contato</span><span>Relacionamentos</span><span>Status</span><span>Ações</span></> : activeTab === 'Itens' ? <><span>Código / Item</span><span>Tipo</span><span>Categoria</span><span>Unidade</span><span>Valor</span><span>Status</span><span>Ações</span></> : <><span>Nome</span><span>Detalhes</span><span>Status</span><span>Ações</span></>}</div>
          {loading && <div className="module-empty">Carregando seus cadastros…</div>}
          {!loading && paginated.length === 0 && <div className="module-empty"><strong>Nenhum cadastro encontrado.</strong><span>Use “Novo cadastro” para adicionar o primeiro registro.</span><button onClick={openNew}>Novo cadastro</button></div>}
          {paginated.map((record) => activeTab === 'Clientes' ? <div className="master-row master-clientes" key={record.id}><span><strong>{String(record.code || 'Código automático')}</strong><small>{record.name}{record.trade_name ? ` • ${String(record.trade_name)}` : ''}</small></span><span>{String(record.document || 'Não informado')}</span><span><strong>{String(record.contact_name || 'Não informado')}</strong><small>{String(record.email || record.phone || '')}</small></span><span><b>{Number(record.project_count || 0)} projetos</b><small>{Number(record.quote_count || 0)} orçamentos</small></span><span><em className={record.status === 'Inativo' ? 'record-status inactive' : 'record-status'}>{String(record.status || 'Ativo')}</em></span><span className="row-actions"><button onClick={() => openEdit(record)}>Editar</button><button className="danger-action" onClick={() => deactivate(record)}>Inativar</button></span></div> : activeTab === 'Itens' ? <div className="master-row master-itens" key={record.id}><span><strong>{String(record.code)}</strong><small>{record.name}</small></span><span>{String(record.item_type)}</span><span>{String(record.category_name || 'Sem categoria')}</span><span>{String(record.unit_abbreviation || '—')}</span><span><strong>{formatMoney(record.sale_price_cents)}</strong></span><span><em className={record.status === 'Inativo' ? 'record-status inactive' : 'record-status'}>{String(record.status || 'Ativo')}</em></span><span className="row-actions"><button onClick={() => openEdit(record)}>Editar</button><button onClick={() => duplicateItem(record)}>Duplicar</button><button className="danger-action" onClick={() => deactivate(record)}>Inativar</button></span></div> : <div className="master-row master-generic" key={record.id}><span><strong>{record.name}</strong><small>{activeTab === 'Categorias' ? String(record.entity_type || '') : activeTab === 'Unidades' ? String(record.abbreviation || '') : String(record.type || '')}</small></span><span>{activeTab === 'Categorias' ? <><i className="category-color" style={{ background: String(record.color || '#287cec') }} />{String(record.description || 'Sem descrição')}</> : activeTab === 'Unidades' ? `${record.allows_decimal ? 'Permite' : 'Não permite'} quantidade decimal` : `${Number(record.installments || 1)} parcela(s) • intervalo de ${Number(record.interval_days || 0)} dias`}</span><span><em className={record.status === 'Inativo' ? 'record-status inactive' : 'record-status'}>{String(record.status || 'Ativo')}</em></span><span className="row-actions"><button onClick={() => openEdit(record)}>Editar</button><button className="danger-action" onClick={() => deactivate(record)}>Inativar</button></span></div>)}
        </div>{pageCount > 1 && <div className="pagination"><button disabled={page === 1} onClick={() => setPage((value) => value - 1)}>← Anterior</button><span>Página {page} de {pageCount}</span><button disabled={page === pageCount} onClick={() => setPage((value) => value + 1)}>Próxima →</button></div>}
      </>}
    </div></div>
    <section className="panel recent-history"><div className="panel-heading"><div><h2>Alterações recentes</h2><p>Registradas como Administrador Master</p></div><span>{history.length} eventos</span></div><div>{history.length === 0 ? <div className="module-empty"><span>As alterações aparecerão aqui.</span></div> : history.slice(0, 6).map((event) => <article key={event.id}><i>✓</i><div><strong>{event.details || event.action}</strong><span>{event.entity_type} • {event.actor_name}</span></div><time>{formatDateTime(event.created_at)}</time></article>)}</div></section>
    {modalOpen && <div className="overlay" onMouseDown={() => setModalOpen(false)}><section className="dialog wide-dialog registration-dialog" onMouseDown={(event) => event.stopPropagation()}><div className="dialog-head"><div><p>CADASTRO PESSOAL</p><h2>{editingId ? 'Editar' : 'Cadastrar'} {labelFor(activeTab)}</h2><span>Responsável: Administrador Master</span></div><button onClick={() => setModalOpen(false)}>×</button></div><form onSubmit={save}>{activeTab === 'Clientes' ? <ClientFields draft={draft} change={change} /> : activeTab === 'Itens' ? <ItemFields draft={draft} change={change} categories={categories} units={units} /> : activeTab === 'Categorias' ? <CategoryFields draft={draft} change={change} /> : activeTab === 'Unidades' ? <UnitFields draft={draft} change={change} /> : <PaymentFields draft={draft} change={change} />}<div className="dialog-actions"><button type="button" onClick={() => setModalOpen(false)}>Cancelar</button><button type="submit" disabled={saving}>{saving ? 'Salvando…' : 'Salvar cadastro'}</button></div></form></section></div>}
  </section>;
}

type FieldProps = { draft: Record<string, unknown>; change: (field: string, value: unknown) => void };
const value = (draft: Record<string, unknown>, field: string) => String(draft[field] ?? '');

function ClientFields({ draft, change }: FieldProps) { return <><div className="form-section-title"><span>01</span><div><h3>Identificação</h3><p>Dados fiscais e comerciais do cliente.</p></div></div><div className="form-grid three"><label>Código<input placeholder="Automático" value={value(draft, 'code')} onChange={(e) => change('code', e.target.value.toUpperCase())} /></label><label>Tipo<select value={value(draft, 'personType')} onChange={(e) => change('personType', e.target.value)}><option>Pessoa jurídica</option><option>Pessoa física</option></select></label><label>Status<select value={value(draft, 'status')} onChange={(e) => change('status', e.target.value)}><option>Ativo</option><option>Inativo</option></select></label><label>Nome ou razão social<input required value={value(draft, 'name')} onChange={(e) => change('name', e.target.value)} /></label><label>Nome fantasia<input value={value(draft, 'tradeName')} onChange={(e) => change('tradeName', e.target.value)} /></label><label>CPF ou CNPJ<input value={value(draft, 'document')} onChange={(e) => change('document', e.target.value)} /></label><label>Inscrição estadual<input value={value(draft, 'stateRegistration')} onChange={(e) => change('stateRegistration', e.target.value)} /></label><label>Responsável no cliente<input value={value(draft, 'contactName')} onChange={(e) => change('contactName', e.target.value)} /></label></div><div className="form-section-title section-gap"><span>02</span><div><h3>Contato e endereço</h3><p>Informações utilizadas nos projetos e orçamentos.</p></div></div><div className="form-grid three"><label>Telefone<input value={value(draft, 'phone')} onChange={(e) => change('phone', e.target.value)} /></label><label>WhatsApp<input value={value(draft, 'whatsapp')} onChange={(e) => change('whatsapp', e.target.value)} /></label><label>E-mail<input type="email" value={value(draft, 'email')} onChange={(e) => change('email', e.target.value)} /></label><label>CEP<input value={value(draft, 'postalCode')} onChange={(e) => change('postalCode', e.target.value)} /></label><label>Endereço<input value={value(draft, 'address')} onChange={(e) => change('address', e.target.value)} /></label><label>Número<input value={value(draft, 'addressNumber')} onChange={(e) => change('addressNumber', e.target.value)} /></label><label>Complemento<input value={value(draft, 'addressComplement')} onChange={(e) => change('addressComplement', e.target.value)} /></label><label>Bairro<input value={value(draft, 'neighborhood')} onChange={(e) => change('neighborhood', e.target.value)} /></label><label>Cidade<input value={value(draft, 'city')} onChange={(e) => change('city', e.target.value)} /></label><label>Estado<input maxLength={2} value={value(draft, 'state')} onChange={(e) => change('state', e.target.value.toUpperCase())} /></label></div><label>Observações<textarea rows={3} value={value(draft, 'notes')} onChange={(e) => change('notes', e.target.value)} /></label></>; }

function ItemFields({ draft, change, categories, units }: FieldProps & { categories: CatalogRecord[]; units: CatalogRecord[] }) { return <><div className="form-grid three"><label>Código ou SKU<input required value={value(draft, 'code')} onChange={(e) => change('code', e.target.value.toUpperCase())} /></label><label>Tipo<select value={value(draft, 'itemType')} onChange={(e) => change('itemType', e.target.value)}><option>Produto</option><option>Serviço</option></select></label><label>Status<select value={value(draft, 'status')} onChange={(e) => change('status', e.target.value)}><option>Ativo</option><option>Inativo</option></select></label><label>Nome<input required value={value(draft, 'name')} onChange={(e) => change('name', e.target.value)} /></label><label>Categoria<select value={value(draft, 'categoryId')} onChange={(e) => change('categoryId', e.target.value)}><option value="">Sem categoria</option>{categories.filter((item) => item.status !== 'Inativo').map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label><label>Unidade<select value={value(draft, 'unitId')} onChange={(e) => change('unitId', e.target.value)}><option value="">Sem unidade</option>{units.filter((item) => item.status !== 'Inativo').map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label><label>Valor padrão (R$)<input type="number" min="0" step="0.01" value={Number(draft.salePrice || 0)} onChange={(e) => change('salePrice', Math.max(0, Number(e.target.value)))} /></label><label>Custo opcional (R$)<input type="number" min="0" step="0.01" value={Number(draft.cost || 0)} onChange={(e) => change('cost', Math.max(0, Number(e.target.value)))} /></label><label>Imposto padrão (%)<input type="number" min="0" step="0.01" value={Number(draft.taxPercent || 0)} onChange={(e) => change('taxPercent', Math.max(0, Number(e.target.value)))} /></label><label>Desconto máximo (%)<input type="number" min="0" max="100" step="0.01" value={Number(draft.maxDiscountPercent || 0)} onChange={(e) => change('maxDiscountPercent', Math.max(0, Number(e.target.value)))} /></label><label>Prazo padrão<input value={value(draft, 'deliveryTerms')} onChange={(e) => change('deliveryTerms', e.target.value)} /></label></div><label>Descrição detalhada<textarea required rows={3} value={value(draft, 'description')} onChange={(e) => change('description', e.target.value)} /></label><label>Observações<textarea rows={2} value={value(draft, 'notes')} onChange={(e) => change('notes', e.target.value)} /></label></>; }

function CategoryFields({ draft, change }: FieldProps) { return <div className="form-grid two"><label>Nome<input required value={value(draft, 'name')} onChange={(e) => change('name', e.target.value)} /></label><label>Tipo relacionado<select value={value(draft, 'entityType')} onChange={(e) => change('entityType', e.target.value)}><option>Cliente</option><option>Projeto</option><option>Produto</option><option>Serviço</option><option>Produto ou serviço</option></select></label><label>Cor<input type="color" value={value(draft, 'color')} onChange={(e) => change('color', e.target.value)} /></label><label>Status<select value={value(draft, 'status')} onChange={(e) => change('status', e.target.value)}><option>Ativo</option><option>Inativo</option></select></label><label className="full-field">Descrição<textarea rows={3} value={value(draft, 'description')} onChange={(e) => change('description', e.target.value)} /></label></div>; }
function UnitFields({ draft, change }: FieldProps) { return <div className="form-grid two"><label>Nome<input required placeholder="Ex.: Hora" value={value(draft, 'name')} onChange={(e) => change('name', e.target.value)} /></label><label>Abreviação<input required placeholder="Ex.: h" value={value(draft, 'abbreviation')} onChange={(e) => change('abbreviation', e.target.value)} /></label><label>Status<select value={value(draft, 'status')} onChange={(e) => change('status', e.target.value)}><option>Ativo</option><option>Inativo</option></select></label><label className="check-label"><input type="checkbox" checked={Boolean(draft.allowsDecimal)} onChange={(e) => change('allowsDecimal', e.target.checked)} /> Permitir quantidade decimal</label></div>; }
function PaymentFields({ draft, change }: FieldProps) { return <><div className="form-grid three"><label>Nome<input required placeholder="Ex.: Pix" value={value(draft, 'name')} onChange={(e) => change('name', e.target.value)} /></label><label>Tipo<select value={value(draft, 'type')} onChange={(e) => change('type', e.target.value)}><option>À vista</option><option>Parcelado</option><option>Entrada + parcelas</option><option>A combinar</option></select></label><label>Status<select value={value(draft, 'status')} onChange={(e) => change('status', e.target.value)}><option>Ativo</option><option>Inativo</option></select></label><label>Número de parcelas<input type="number" min="1" value={Number(draft.installments || 1)} onChange={(e) => change('installments', Math.max(1, Number(e.target.value)))} /></label><label>Intervalo em dias<input type="number" min="0" value={Number(draft.intervalDays || 0)} onChange={(e) => change('intervalDays', Math.max(0, Number(e.target.value)))} /></label></div><label>Condição padrão<textarea rows={3} value={value(draft, 'defaultTerms')} onChange={(e) => change('defaultTerms', e.target.value)} /></label><label>Observações<textarea rows={2} value={value(draft, 'notes')} onChange={(e) => change('notes', e.target.value)} /></label></>; }

function CompanyForm({ company, setCompany, onSubmit, saving }: { company: typeof emptyCompany; setCompany: (value: typeof emptyCompany) => void; onSubmit: (event: FormEvent) => void; saving: boolean }) { const change = (field: keyof typeof emptyCompany, next: string) => setCompany({ ...company, [field]: next }); return <form className="company-form" onSubmit={onSubmit}><div className="company-preview"><div><img src={company.logoUrl || '/cefas-logo-clean.png'} alt="Logo Cefas" /><span>Identidade usada nos PDFs</span></div><strong>{company.companyName || 'Sua empresa'}</strong><small>{company.document || 'Documento não informado'}</small></div><div className="company-fields"><div className="form-section-title"><span>01</span><div><h3>Identificação da empresa</h3><p>Dados exibidos nos orçamentos e documentos.</p></div></div><div className="form-grid three"><label>Logo<input value={company.logoUrl} onChange={(e) => change('logoUrl', e.target.value)} /></label><label>Nome ou razão social<input value={company.companyName} onChange={(e) => change('companyName', e.target.value)} /></label><label>CPF ou CNPJ<input value={company.document} onChange={(e) => change('document', e.target.value)} /></label><label>Telefone<input value={company.phone} onChange={(e) => change('phone', e.target.value)} /></label><label>WhatsApp<input value={company.whatsapp} onChange={(e) => change('whatsapp', e.target.value)} /></label><label>E-mail<input type="email" value={company.email} onChange={(e) => change('email', e.target.value)} /></label><label>Site<input value={company.site} onChange={(e) => change('site', e.target.value)} /></label><label className="full-field">Endereço completo<input value={company.address} onChange={(e) => change('address', e.target.value)} /></label></div><label>Texto padrão do rodapé<textarea rows={2} value={company.footerText} onChange={(e) => change('footerText', e.target.value)} /></label><label>Observações comerciais<textarea rows={3} value={company.commercialNotes} onChange={(e) => change('commercialNotes', e.target.value)} /></label><label>Assinatura opcional<textarea rows={2} value={company.signatureText} onChange={(e) => change('signatureText', e.target.value)} /></label><div className="dialog-actions"><button type="submit" disabled={saving}>{saving ? 'Salvando…' : 'Salvar dados da empresa'}</button></div></div></form>; }
