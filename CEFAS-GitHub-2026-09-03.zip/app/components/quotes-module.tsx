'use client';

import { useEffect, useMemo, useState } from 'react';
import type { FormEvent } from 'react';

type QuoteStatus = 'Rascunho' | 'Enviado' | 'Aprovado' | 'Recusado' | 'Vencido';
type Client = { id: string; name: string; document?: string; contact_name?: string; email?: string; phone?: string; address?: string; status?: string };
type Project = { id: string; name: string; code: string; client_id?: string };
type CatalogItem = { id: string; name: string; description?: string; unit_abbreviation?: string; sale_price_cents: number; status?: string };
type PaymentMethod = { id: string; name: string; default_terms?: string; status?: string };
type CompanyProfile = { company_name?: string; document?: string; phone?: string; whatsapp?: string; email?: string; site?: string; address?: string; footer_text?: string; commercial_notes?: string; signature_text?: string; logo_url?: string };
type QuoteList = { id: string; number: number; status: QuoteStatus; issue_date: string; valid_until: string; project_name?: string; client_name: string; total_cents: number; created_at: string; updated_at: string };
type QuoteItem = { id?: string; description: string; quantity: number; unit: string; unit_price_cents: number; discount_type: 'percent' | 'fixed'; discount_value: number; total_cents: number };
type QuoteDetail = QuoteList & { project_id?: string; internal_notes?: string; client_id?: string; client_document?: string; client_phone?: string; client_email?: string; client_address?: string; contact_name?: string; subtotal_cents: number; item_discount_cents: number; discount_cents: number; surcharge_cents: number; tax_cents: number; payment_method?: string; payment_terms?: string; delivery_terms?: string; items: QuoteItem[]; history?: Array<{ id: string; action: string; details?: string; from_status?: string; to_status?: string; created_at: string }> };
type DraftItem = { key: string; description: string; quantity: number; unit: string; unitPrice: number; discountType: 'percent' | 'fixed'; discountValue: number };
type Draft = { status: QuoteStatus; issueDate: string; validUntil: string; projectId: string; projectName: string; internalNotes: string; clientId: string; clientName: string; clientDocument: string; clientPhone: string; clientEmail: string; clientAddress: string; contactName: string; discount: number; surcharge: number; tax: number; paymentMethod: string; paymentTerms: string; deliveryTerms: string; items: DraftItem[] };
type Props = { searchQuery: string; onNotify: (message: string, error?: boolean) => void };

const statuses: QuoteStatus[] = ['Rascunho', 'Enviado', 'Aprovado', 'Recusado', 'Vencido'];
const currency = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
const formatMoney = (cents: number) => currency.format((Number(cents) || 0) / 100);
const formatDate = (value?: string) => value ? new Intl.DateTimeFormat('pt-BR').format(new Date(`${value.slice(0, 10)}T12:00:00`)) : '—';
const quoteNumber = (number: number) => `ORC-${String(number).padStart(6, '0')}`;
const today = () => new Date().toISOString().slice(0, 10);
const futureDate = (days: number) => { const date = new Date(); date.setDate(date.getDate() + days); return date.toISOString().slice(0, 10); };
const newItem = (): DraftItem => ({ key: crypto.randomUUID(), description: '', quantity: 1, unit: 'un.', unitPrice: 0, discountType: 'percent', discountValue: 0 });
const blankDraft = (): Draft => ({ status: 'Rascunho', issueDate: today(), validUntil: futureDate(15), projectId: '', projectName: '', internalNotes: '', clientId: '', clientName: '', clientDocument: '', clientPhone: '', clientEmail: '', clientAddress: '', contactName: '', discount: 0, surcharge: 0, tax: 0, paymentMethod: 'Pix', paymentTerms: 'Pagamento conforme condições acordadas.', deliveryTerms: 'Prazo a combinar após aprovação.', items: [newItem()] });

function itemTotals(item: DraftItem) {
  const gross = Math.round(Math.max(0, item.quantity) * Math.max(0, item.unitPrice) * 100);
  const discount = item.discountType === 'percent' ? Math.round(gross * Math.min(100, Math.max(0, item.discountValue)) / 100) : Math.min(gross, Math.round(Math.max(0, item.discountValue) * 100));
  return { gross, discount, total: Math.max(0, gross - discount) };
}

export default function QuotesModule({ searchQuery, onNotify }: Props) {
  const [quotes, setQuotes] = useState<QuoteList[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [catalogItems, setCatalogItems] = useState<CatalogItem[]>([]);
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([]);
  const [company, setCompany] = useState<CompanyProfile | null>(null);
  const [filter, setFilter] = useState<'Todos' | QuoteStatus>('Todos');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [formOpen, setFormOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState<Draft>(blankDraft);
  const [preview, setPreview] = useState<QuoteDetail | null>(null);

  async function loadData() {
    setLoading(true);
    try {
      const [quotesResponse, clientsResponse, projectsResponse, itemsResponse, paymentsResponse, companyResponse] = await Promise.all([fetch('/api/quotes', { cache: 'no-store' }), fetch('/api/personal-clients', { cache: 'no-store' }), fetch('/api/personal-projects', { cache: 'no-store' }), fetch('/api/catalog/items', { cache: 'no-store' }), fetch('/api/catalog/payments', { cache: 'no-store' }), fetch('/api/company-profile', { cache: 'no-store' })]);
      if ([quotesResponse, clientsResponse, projectsResponse, itemsResponse, paymentsResponse, companyResponse].some((response) => !response.ok)) throw new Error('Não foi possível carregar seus orçamentos.');
      const [quotesPayload, clientsPayload, projectsPayload, itemsPayload, paymentsPayload, companyPayload] = await Promise.all([quotesResponse.json(), clientsResponse.json(), projectsResponse.json(), itemsResponse.json(), paymentsResponse.json(), companyResponse.json()]) as [{ data?: QuoteList[] }, { data?: Client[] }, { data?: Project[] }, { data?: CatalogItem[] }, { data?: PaymentMethod[] }, { data?: CompanyProfile | null }];
      setQuotes(quotesPayload.data ?? []);
      setClients((clientsPayload.data ?? []).filter((client) => client.status !== 'Inativo'));
      setProjects(projectsPayload.data ?? []);
      setCatalogItems((itemsPayload.data ?? []).filter((item) => item.status !== 'Inativo'));
      setPaymentMethods((paymentsPayload.data ?? []).filter((item) => item.status !== 'Inativo'));
      setCompany(companyPayload.data ?? null);
    } catch (error) { onNotify(error instanceof Error ? error.message : 'Erro ao carregar orçamentos.', true); }
    finally { setLoading(false); }
  }

  useEffect(() => { void loadData(); }, []);

  const totals = useMemo(() => {
    const itemData = draft.items.map(itemTotals);
    const subtotal = itemData.reduce((sum, item) => sum + item.gross, 0);
    const itemDiscount = itemData.reduce((sum, item) => sum + item.discount, 0);
    const final = Math.max(0, subtotal - itemDiscount - Math.round(draft.discount * 100) + Math.round(draft.surcharge * 100) + Math.round(draft.tax * 100));
    return { subtotal, itemDiscount, total: final };
  }, [draft]);

  const filtered = useMemo(() => quotes.filter((quote) => {
    const statusMatch = filter === 'Todos' || quote.status === filter;
    const haystack = `${quoteNumber(quote.number)} ${quote.client_name} ${quote.project_name ?? ''}`.toLowerCase();
    return statusMatch && haystack.includes(searchQuery.toLowerCase());
  }), [quotes, filter, searchQuery]);

  const counts = useMemo(() => Object.fromEntries(statuses.map((status) => [status, quotes.filter((quote) => quote.status === status).length])) as Record<QuoteStatus, number>, [quotes]);

  function openNew() {
    if (!clients.length) { onNotify('Cadastre um cliente no módulo Projetos antes de criar o orçamento.', true); return; }
    const next = blankDraft();
    const client = clients[0];
    setDraft({ ...next, clientId: client.id, clientName: client.name, clientDocument: client.document ?? '', clientPhone: client.phone ?? '', clientEmail: client.email ?? '', clientAddress: client.address ?? '', contactName: client.contact_name ?? '' });
    setEditingId(null);
    setFormOpen(true);
  }

  async function getDetail(id: string) {
    const response = await fetch(`/api/quotes/${id}`, { cache: 'no-store' });
    if (!response.ok) throw new Error('Não foi possível abrir este orçamento.');
    const payload = await response.json() as { data: QuoteDetail };
    return payload.data as QuoteDetail;
  }

  async function openPreview(id: string) {
    try { setPreview(await getDetail(id)); }
    catch (error) { onNotify(error instanceof Error ? error.message : 'Erro ao abrir orçamento.', true); }
  }

  async function openEdit(id: string) {
    try {
      const quote = await getDetail(id);
      setDraft({ status: quote.status, issueDate: quote.issue_date, validUntil: quote.valid_until, projectId: quote.project_id ?? '', projectName: quote.project_name ?? '', internalNotes: quote.internal_notes ?? '', clientId: quote.client_id ?? '', clientName: quote.client_name, clientDocument: quote.client_document ?? '', clientPhone: quote.client_phone ?? '', clientEmail: quote.client_email ?? '', clientAddress: quote.client_address ?? '', contactName: quote.contact_name ?? '', discount: quote.discount_cents / 100, surcharge: quote.surcharge_cents / 100, tax: quote.tax_cents / 100, paymentMethod: quote.payment_method ?? '', paymentTerms: quote.payment_terms ?? '', deliveryTerms: quote.delivery_terms ?? '', items: quote.items.map((item) => ({ key: item.id ?? crypto.randomUUID(), description: item.description, quantity: item.quantity, unit: item.unit, unitPrice: item.unit_price_cents / 100, discountType: item.discount_type, discountValue: item.discount_type === 'fixed' ? item.discount_value / 100 : item.discount_value })) });
      setEditingId(id);
      setPreview(null);
      setFormOpen(true);
    } catch (error) { onNotify(error instanceof Error ? error.message : 'Erro ao editar orçamento.', true); }
  }

  function chooseClient(id: string) {
    const client = clients.find((item) => item.id === id);
    if (!client) return;
    setDraft((current) => ({ ...current, clientId: client.id, clientName: client.name, clientDocument: client.document ?? '', clientPhone: client.phone ?? '', clientEmail: client.email ?? '', clientAddress: client.address ?? '', contactName: client.contact_name ?? '' }));
  }

  function chooseProject(id: string) {
    const project = projects.find((item) => item.id === id);
    setDraft((current) => ({ ...current, projectId: project?.id ?? '', projectName: project?.name ?? '' }));
  }

  function updateItem(key: string, field: keyof DraftItem, value: string | number) {
    setDraft((current) => ({ ...current, items: current.items.map((item) => item.key === key ? { ...item, [field]: value } : item) }));
  }

  function chooseCatalogItem(key: string, id: string) {
    const catalog = catalogItems.find((item) => item.id === id);
    if (!catalog) return;
    setDraft((current) => ({ ...current, items: current.items.map((item) => item.key === key ? { ...item, description: catalog.description || catalog.name, unit: catalog.unit_abbreviation || item.unit, unitPrice: Number(catalog.sale_price_cents || 0) / 100 } : item) }));
  }

  function choosePayment(name: string) {
    const payment = paymentMethods.find((item) => item.name === name);
    setDraft((current) => ({ ...current, paymentMethod: name, paymentTerms: payment?.default_terms || current.paymentTerms }));
  }

  function payload() {
    return { ...draft, discountCents: Math.round(draft.discount * 100), surchargeCents: Math.round(draft.surcharge * 100), taxCents: Math.round(draft.tax * 100), items: draft.items.map((item) => ({ description: item.description, quantity: item.quantity, unit: item.unit, unitPriceCents: Math.round(item.unitPrice * 100), discountType: item.discountType, discountValue: item.discountType === 'fixed' ? Math.round(item.discountValue * 100) : item.discountValue })) };
  }

  async function saveQuote(event: FormEvent) {
    event.preventDefault();
    if (!draft.clientId || !draft.clientName || draft.items.every((item) => !item.description.trim())) { onNotify('Selecione o cliente e informe ao menos um item.', true); return; }
    setSaving(true);
    try {
      const response = await fetch(editingId ? `/api/quotes/${editingId}` : '/api/quotes', { method: editingId ? 'PATCH' : 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(payload()) });
      if (!response.ok) throw new Error('Revise os campos obrigatórios e os valores informados.');
      setFormOpen(false);
      await loadData();
      onNotify(editingId ? 'Orçamento atualizado com sucesso.' : 'Orçamento criado com sucesso.');
    } catch (error) { onNotify(error instanceof Error ? error.message : 'Erro ao salvar orçamento.', true); }
    finally { setSaving(false); }
  }

  async function updateStatus(id: string, status: QuoteStatus) {
    try {
      const response = await fetch(`/api/quotes/${id}`, { method: 'PATCH', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ status }) });
      if (!response.ok) throw new Error('Não foi possível atualizar o status.');
      setQuotes((current) => current.map((quote) => quote.id === id ? { ...quote, status } : quote));
      setPreview((current) => current?.id === id ? { ...current, status } : current);
      onNotify(`Status alterado para ${status}.`);
    } catch (error) { onNotify(error instanceof Error ? error.message : 'Erro ao atualizar status.', true); }
  }

  async function duplicateQuote(id: string) {
    try {
      const response = await fetch(`/api/quotes/${id}`, { method: 'POST' });
      if (!response.ok) throw new Error('Não foi possível duplicar o orçamento.');
      await loadData();
      onNotify('Nova cópia criada como rascunho.');
    } catch (error) { onNotify(error instanceof Error ? error.message : 'Erro ao duplicar.', true); }
  }

  async function deleteQuote(id: string) {
    if (!window.confirm('Excluir este orçamento? Esta ação removerá o registro da sua lista.')) return;
    try {
      const response = await fetch(`/api/quotes/${id}`, { method: 'DELETE' });
      if (!response.ok) throw new Error('Não foi possível excluir o orçamento.');
      setPreview(null);
      await loadData();
      onNotify('Orçamento excluído.');
    } catch (error) { onNotify(error instanceof Error ? error.message : 'Erro ao excluir.', true); }
  }

  function printQuote(quote: QuoteDetail) {
    const original = document.title;
    document.title = `ORCAMENTO-${String(quote.number).padStart(6, '0')}-${quote.client_name.replace(/[^a-zA-Z0-9À-ÿ]+/g, '-').replace(/^-|-$/g, '')}`;
    window.print();
    window.setTimeout(() => { document.title = original; }, 700);
  }

  return <section className="module-page quotes-module">
    <div className="module-toolbar"><div className="filter-tabs quote-filters"><button className={filter === 'Todos' ? 'active' : ''} onClick={() => setFilter('Todos')}>Todos <b>{quotes.length}</b></button>{statuses.map((status) => <button key={status} className={filter === status ? 'active' : ''} onClick={() => setFilter(status)}>{status} <b>{counts[status]}</b></button>)}</div><button className="module-primary" onClick={openNew}>＋ Novo orçamento</button></div>
    <div className="module-summary quote-summary"><article><span>Total orçado</span><strong>{formatMoney(quotes.reduce((sum, quote) => sum + Number(quote.total_cents), 0))}</strong><small>todos os registros</small></article><article><span>Aprovados</span><strong>{counts.Aprovado}</strong><small>{formatMoney(quotes.filter((quote) => quote.status === 'Aprovado').reduce((sum, quote) => sum + Number(quote.total_cents), 0))}</small></article><article><span>Aguardando retorno</span><strong>{counts.Enviado}</strong><small>orçamentos enviados</small></article><article><span>Rascunhos</span><strong>{counts.Rascunho}</strong><small>em preparação</small></article></div>
    <section className="panel quote-panel"><div className="panel-heading"><div><h2>Meus orçamentos</h2><p>Clientes e projetos da sua base pessoal</p></div><button onClick={openNew}>Criar orçamento</button></div><div className="quote-table"><div className="quote-row quote-head"><span>Número</span><span>Cliente</span><span>Projeto</span><span>Valor</span><span>Validade</span><span>Status</span><span>Ações</span></div>{loading && <div className="module-empty">Carregando orçamentos…</div>}{!loading && filtered.length === 0 && <div className="module-empty"><strong>Nenhum orçamento encontrado.</strong><span>Crie seu primeiro orçamento com cálculo automático e impressão em PDF.</span><button onClick={openNew}>Novo orçamento</button></div>}{filtered.map((quote) => <div className="quote-row" key={quote.id}><button className="quote-link" onClick={() => openPreview(quote.id)}><strong>{quoteNumber(quote.number)}</strong><small>{formatDate(quote.created_at)}</small></button><span><strong>{quote.client_name}</strong></span><span>{quote.project_name || 'Sem projeto'}</span><span><strong>{formatMoney(quote.total_cents)}</strong></span><span>{formatDate(quote.valid_until)}</span><span><select className={`quote-status status-${quote.status.toLowerCase()}`} value={quote.status} onChange={(event) => updateStatus(quote.id, event.target.value as QuoteStatus)}>{statuses.map((status) => <option key={status}>{status}</option>)}</select></span><span className="row-actions"><button title="Visualizar" onClick={() => openPreview(quote.id)}>Ver</button><button title="Editar" onClick={() => openEdit(quote.id)}>Editar</button><button title="Duplicar" onClick={() => duplicateQuote(quote.id)}>Duplicar</button><button className="danger-action" title="Excluir" onClick={() => deleteQuote(quote.id)}>Excluir</button></span></div>)}</div></section>

    {formOpen && <div className="overlay quote-form-overlay" onMouseDown={() => setFormOpen(false)}><section className="dialog quote-form-dialog" onMouseDown={(event) => event.stopPropagation()}><div className="dialog-head"><div><p>ORÇAMENTO PESSOAL</p><h2>{editingId ? 'Editar orçamento' : 'Novo orçamento'}</h2><span>Cálculos automáticos e dados salvos na sua base privada.</span></div><button onClick={() => setFormOpen(false)}>×</button></div><form onSubmit={saveQuote}>
      <div className="quote-form-section"><div className="form-section-title"><span>01</span><div><h3>Dados do orçamento</h3><p>Datas, projeto e controle do documento.</p></div></div><div className="form-grid four"><label>Emissão<input type="date" required value={draft.issueDate} onChange={(event) => setDraft({ ...draft, issueDate: event.target.value })} /></label><label>Validade<input type="date" required min={draft.issueDate} value={draft.validUntil} onChange={(event) => setDraft({ ...draft, validUntil: event.target.value })} /></label><label>Status<select value={draft.status} onChange={(event) => setDraft({ ...draft, status: event.target.value as QuoteStatus })}>{statuses.map((status) => <option key={status}>{status}</option>)}</select></label><label>Projeto<select value={draft.projectId} onChange={(event) => chooseProject(event.target.value)}><option value="">Sem projeto</option>{projects.map((project) => <option key={project.id} value={project.id}>{project.name}</option>)}</select></label></div></div>
      <div className="quote-form-section"><div className="form-section-title"><span>02</span><div><h3>Cliente</h3><p>Somente clientes cadastrados por você.</p></div></div><div className="form-grid three"><label>Cliente<select required value={draft.clientId} onChange={(event) => chooseClient(event.target.value)}><option value="">Selecione</option>{clients.map((client) => <option key={client.id} value={client.id}>{client.name}</option>)}</select></label><label>CPF ou CNPJ<input value={draft.clientDocument} readOnly /></label><label>Responsável<input value={draft.contactName} readOnly /></label><label>E-mail<input value={draft.clientEmail} readOnly /></label><label>Telefone<input value={draft.clientPhone} readOnly /></label><label>Endereço<input value={draft.clientAddress} readOnly /></label></div></div>
      <div className="quote-form-section"><div className="form-section-title"><span>03</span><div><h3>Itens</h3><p>Selecione seu catálogo ou informe um item avulso.</p></div><button type="button" className="add-line" onClick={() => setDraft({ ...draft, items: [...draft.items, newItem()] })}>＋ Adicionar item</button></div><div className="quote-items"><div className="quote-item quote-item-head"><span>Descrição</span><span>Qtd.</span><span>Unidade</span><span>Valor unit.</span><span>Desconto</span><span>Total</span><span /></div>{draft.items.map((item) => { const total = itemTotals(item); return <div className="quote-item" key={item.key}><span className="catalog-item-picker"><select defaultValue="" onChange={(event) => chooseCatalogItem(item.key, event.target.value)}><option value="">Catálogo / item avulso</option>{catalogItems.map((catalog) => <option key={catalog.id} value={catalog.id}>{catalog.name}</option>)}</select><input required placeholder="Produto ou serviço" value={item.description} onChange={(event) => updateItem(item.key, 'description', event.target.value)} /></span><input type="number" required min="0.01" step="0.01" value={item.quantity} onChange={(event) => updateItem(item.key, 'quantity', Math.max(0, Number(event.target.value)))} /><input value={item.unit} onChange={(event) => updateItem(item.key, 'unit', event.target.value)} /><input type="number" required min="0" step="0.01" value={item.unitPrice} onChange={(event) => updateItem(item.key, 'unitPrice', Math.max(0, Number(event.target.value)))} /><span className="discount-input"><input type="number" min="0" step="0.01" value={item.discountValue} onChange={(event) => updateItem(item.key, 'discountValue', Math.max(0, Number(event.target.value)))} /><select value={item.discountType} onChange={(event) => updateItem(item.key, 'discountType', event.target.value)}><option value="percent">%</option><option value="fixed">R$</option></select></span><strong>{formatMoney(total.total)}</strong><button type="button" aria-label="Remover item" disabled={draft.items.length === 1} onClick={() => setDraft({ ...draft, items: draft.items.filter((row) => row.key !== item.key) })}>×</button></div>})}</div></div>
      <div className="quote-form-columns"><div className="quote-form-section"><div className="form-section-title"><span>04</span><div><h3>Condições</h3><p>Pagamento, entrega e observações.</p></div></div><div className="form-grid two"><label>Forma de pagamento<select value={draft.paymentMethod} onChange={(event) => choosePayment(event.target.value)}>{paymentMethods.length ? paymentMethods.map((payment) => <option key={payment.id}>{payment.name}</option>) : <><option>Pix</option><option>Boleto</option><option>Transferência bancária</option><option>Cartão</option><option>A combinar</option></>}</select></label><label>Prazo de entrega<input value={draft.deliveryTerms} onChange={(event) => setDraft({ ...draft, deliveryTerms: event.target.value })} /></label></div><label>Condições de pagamento<textarea rows={2} value={draft.paymentTerms} onChange={(event) => setDraft({ ...draft, paymentTerms: event.target.value })} /></label><label>Observações internas<textarea rows={2} value={draft.internalNotes} onChange={(event) => setDraft({ ...draft, internalNotes: event.target.value })} /></label></div><aside className="quote-totals-card"><h3>Resumo financeiro</h3><div><span>Subtotal</span><strong>{formatMoney(totals.subtotal)}</strong></div><div><span>Descontos nos itens</span><strong>- {formatMoney(totals.itemDiscount)}</strong></div><label><span>Desconto geral</span><span>R$ <input type="number" min="0" step="0.01" value={draft.discount} onChange={(event) => setDraft({ ...draft, discount: Math.max(0, Number(event.target.value)) })} /></span></label><label><span>Acréscimos</span><span>R$ <input type="number" min="0" step="0.01" value={draft.surcharge} onChange={(event) => setDraft({ ...draft, surcharge: Math.max(0, Number(event.target.value)) })} /></span></label><label><span>Impostos</span><span>R$ <input type="number" min="0" step="0.01" value={draft.tax} onChange={(event) => setDraft({ ...draft, tax: Math.max(0, Number(event.target.value)) })} /></span></label><div className="grand-total"><span>Total</span><strong>{formatMoney(totals.total)}</strong></div></aside></div>
      <div className="dialog-actions sticky-actions"><button type="button" onClick={() => setFormOpen(false)}>Cancelar</button><button type="submit" disabled={saving}>{saving ? 'Salvando…' : editingId ? 'Salvar alterações' : 'Criar orçamento'}</button></div>
    </form></section></div>}

    {preview && <div className="overlay quote-preview-overlay" onMouseDown={() => setPreview(null)}><section className="quote-preview-dialog" onMouseDown={(event) => event.stopPropagation()}><div className="quote-preview-toolbar"><div><strong>{quoteNumber(preview.number)}</strong><span>Prévia pronta para impressão A4</span></div><div><button onClick={() => openEdit(preview.id)}>Editar</button><button onClick={() => duplicateQuote(preview.id)}>Duplicar</button><button className="pdf-button" onClick={() => printQuote(preview)}>⇩ Gerar PDF</button><button className="print-button" onClick={() => printQuote(preview)}>▣ Imprimir</button><button className="close-preview" onClick={() => setPreview(null)}>×</button></div></div><article className="quote-preview-sheet">
      <header className="pdf-header"><div className="pdf-company"><img src={company?.logo_url || '/cefas-logo-clean.png'} alt="Cefas" /><p><strong>{company?.company_name || 'Cefas'}</strong><small>{company?.document || ''}{company?.email ? ` · ${company.email}` : ''}<br />{company?.phone || company?.whatsapp || ''}</small></p></div><div><span>ORÇAMENTO</span><strong>{quoteNumber(preview.number)}</strong><small>Emitido em {formatDate(preview.issue_date)}</small></div></header>
      <section className="pdf-intro"><div><span>Preparado para</span><h2>{preview.client_name}</h2><p>{preview.client_document || 'Documento não informado'}<br />{preview.contact_name || ''}{preview.client_email ? ` · ${preview.client_email}` : ''}<br />{preview.client_phone || ''}<br />{preview.client_address || ''}</p></div><div className="pdf-dates"><p><span>Validade</span><strong>{formatDate(preview.valid_until)}</strong></p><p><span>Projeto</span><strong>{preview.project_name || 'Não vinculado'}</strong></p><p><span>Status</span><strong>{preview.status}</strong></p></div></section>
      <table className="pdf-items"><thead><tr><th>Descrição</th><th>Qtd.</th><th>Un.</th><th>Valor unitário</th><th>Desconto</th><th>Total</th></tr></thead><tbody>{preview.items.map((item) => <tr key={item.id ?? item.description}><td>{item.description}</td><td>{item.quantity}</td><td>{item.unit}</td><td>{formatMoney(item.unit_price_cents)}</td><td>{item.discount_type === 'percent' ? `${item.discount_value}%` : formatMoney(item.discount_value)}</td><td><strong>{formatMoney(item.total_cents)}</strong></td></tr>)}</tbody></table>
      <section className="pdf-bottom"><div className="pdf-conditions"><h3>Condições comerciais</h3><p><span>Forma de pagamento</span><strong>{preview.payment_method || 'A combinar'}</strong></p><p><span>Condições</span>{preview.payment_terms || 'Não informadas'}</p><p><span>Entrega ou execução</span>{preview.delivery_terms || 'A combinar'}</p>{preview.internal_notes && <p><span>Observações</span>{preview.internal_notes}</p>}</div><div className="pdf-totals"><p><span>Subtotal</span><strong>{formatMoney(preview.subtotal_cents)}</strong></p><p><span>Descontos nos itens</span><strong>- {formatMoney(preview.item_discount_cents)}</strong></p><p><span>Desconto geral</span><strong>- {formatMoney(preview.discount_cents)}</strong></p><p><span>Acréscimos</span><strong>{formatMoney(preview.surcharge_cents)}</strong></p><p><span>Impostos</span><strong>{formatMoney(preview.tax_cents)}</strong></p><p className="pdf-total"><span>VALOR TOTAL</span><strong>{formatMoney(preview.total_cents)}</strong></p></div></section>
      <footer className="pdf-footer"><div><span>De acordo:</span><i /><strong>{preview.client_name}</strong></div><p>{company?.footer_text || `Este orçamento é válido até ${formatDate(preview.valid_until)}.`}</p></footer>
    </article></section></div>}
  </section>;
}
