'use client';

import { FormEvent, useEffect, useMemo, useState } from 'react';
import { siteConfig } from '../../lib/site-config';

export type DemoKind = 'admin' | 'landing' | 'institutional' | 'app';

const demoConfig = {
  admin: { category: 'Sistemas administrativos', title: 'Central de gestão', description: 'Um ambiente para acompanhar indicadores, clientes, projetos e relatórios em um só lugar.', formType: 'Sistema administrativo', features: ['Dashboard personalizável', 'Cadastros e permissões', 'Busca, filtros e paginação', 'Relatórios e indicadores', 'Histórico de atividades'] },
  landing: { category: 'Landing pages', title: 'Página de conversão', description: 'Uma experiência focada em apresentar uma oferta com clareza e conduzir o visitante até o contato.', formType: 'Landing page', features: ['Hero e proposta de valor', 'Benefícios e processo', 'Perguntas frequentes', 'Formulário validado', 'Chamadas para ação'] },
  institutional: { category: 'Sites institucionais', title: 'Presença digital profissional', description: 'Uma apresentação completa para fortalecer a marca, explicar serviços e facilitar novos contatos.', formType: 'Site institucional', features: ['Navegação responsiva', 'Sobre e serviços', 'Diferenciais e equipe', 'Perguntas frequentes', 'Contato integrado'] },
  app: { category: 'Aplicativos', title: 'Gestão na palma da mão', description: 'Uma demonstração mobile com acesso, indicadores, tarefas, favoritos, notificações e perfil.', formType: 'Aplicativo', features: ['Fluxo de boas-vindas', 'Busca e filtros', 'Detalhes e favoritos', 'Notificações', 'Navegação inferior'] },
} as const;

function Notice({ message }: { message: string }) {
  return message ? <div className="demo-toast" role="status"><span>✓</span>{message}</div> : null;
}

type RecordItem = { id: number; name: string; type: string; status: 'Ativo' | 'Em análise' | 'Pausado'; value: string };
const initialRecords: RecordItem[] = [
  { id: 1, name: 'Projeto Aurora', type: 'Aplicativo', status: 'Ativo', value: 'R$ 8.400' },
  { id: 2, name: 'Portal Horizonte', type: 'Site', status: 'Em análise', value: 'R$ 5.200' },
  { id: 3, name: 'Painel Essencial', type: 'Sistema', status: 'Ativo', value: 'R$ 12.600' },
  { id: 4, name: 'Campanha Impulso', type: 'Landing page', status: 'Pausado', value: 'R$ 3.100' },
  { id: 5, name: 'Aplicativo Conecta', type: 'Aplicativo', status: 'Ativo', value: 'R$ 9.750' },
];

function AdminDemo() {
  const [module, setModule] = useState('Dashboard');
  const [records, setRecords] = useState(initialRecords);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('Todos');
  const [page, setPage] = useState(1);
  const [editing, setEditing] = useState<RecordItem | null | 'new'>(null);
  const [notice, setNotice] = useState('');
  const filtered = records.filter((item)=>item.name.toLowerCase().includes(search.toLowerCase())&&(status==='Todos'||item.status===status));
  const pages = Math.max(1, Math.ceil(filtered.length/3));
  const visible = filtered.slice((page-1)*3,page*3);
  useEffect(()=>setPage(1),[search,status]);
  useEffect(()=>{ if(!editing)return; const key=(event:KeyboardEvent)=>{if(event.key==='Escape')setEditing(null)}; document.addEventListener('keydown',key); return()=>document.removeEventListener('keydown',key)},[editing]);
  function save(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const next = { name: String(data.get('name')), type: String(data.get('type')), status: String(data.get('status')) as RecordItem['status'], value: String(data.get('value')) };
    if(editing==='new') setRecords((current)=>[...current,{...next,id:Date.now()}]);
    else if(editing) setRecords((current)=>current.map((item)=>item.id===editing.id?{...item,...next}:item));
    setEditing(null); setNotice(editing==='new'?'Registro criado na demonstração.':'Registro atualizado na demonstração.');
  }
  return <div className="admin-demo demo-surface">
    <aside className="admin-sidebar"><div className="demo-mini-logo">C</div><small>MODELO</small>{['Dashboard','Clientes','Projetos','Relatórios'].map((item)=><button key={item} className={module===item?'active':''} onClick={()=>setModule(item)}><span>{item.slice(0,2)}</span>{item}</button>)}</aside>
    <section className="admin-main"><header><div><small>MODELO CONCEITUAL</small><h2>{module}</h2></div><button className="demo-primary" onClick={()=>setEditing('new')}>+ Novo registro</button></header>
      {module==='Dashboard'&&<><div className="admin-metrics">{[['Clientes','128','+8 neste mês'],['Vendas','34','12 em andamento'],['Projetos','18','14 ativos'],['Faturamento','R$ 48,7 mil','valor ilustrativo']].map(([label,value,detail])=><article key={label}><span>{label}</span><strong>{value}</strong><small>{detail}</small></article>)}</div><div className="admin-chart-grid"><article><div><b>Evolução ilustrativa</b><span>Últimos 7 períodos</span></div><div className="admin-bars">{[38,54,46,68,60,82,76].map((height,index)=><i key={index} style={{height:`${height}%`}} />)}</div></article><article className="admin-donut"><div><b>Distribuição</b><span>Por categoria</span></div><i><strong>72%</strong><small>ativos</small></i></article></div></>}
      {module==='Relatórios'?<div className="admin-report"><span>RELATÓRIO ILUSTRATIVO</span><h3>Visão consolidada da operação</h3><div>{[72,48,86,64].map((value,index)=><p key={value}><b>{['Projetos','Atendimentos','Entregas','Solicitações'][index]}</b><i><span style={{width:`${value}%`}} /></i><em>{value}%</em></p>)}</div></div>:<div className="admin-table-card"><div className="admin-table-tools"><div><b>{module==='Dashboard'?'Registros recentes':module}</b><small>{filtered.length} resultado(s)</small></div><label><span>⌕</span><input value={search} onChange={(event)=>setSearch(event.target.value)} placeholder="Buscar registro" /></label><select value={status} onChange={(event)=>setStatus(event.target.value)} aria-label="Filtrar por status"><option>Todos</option><option>Ativo</option><option>Em análise</option><option>Pausado</option></select></div>{visible.length?<div className="demo-table-wrap"><table><thead><tr><th>Nome</th><th>Tipo</th><th>Status</th><th>Valor</th><th>Ações</th></tr></thead><tbody>{visible.map((item)=><tr key={item.id}><td><b>{item.name}</b><small>#{String(item.id).slice(-4)}</small></td><td>{item.type}</td><td><span className={`demo-status ${item.status.toLowerCase().replace(' ','-')}`}>{item.status}</span></td><td>{item.value}</td><td><button onClick={()=>setNotice(`Visualizando ${item.name}.`)}>Ver</button><button onClick={()=>setEditing(item)}>Editar</button></td></tr>)}</tbody></table></div>:<div className="demo-empty"><b>Nenhum registro encontrado</b><span>Ajuste a busca ou o filtro para continuar.</span></div>}<div className="admin-pagination"><span>Página {page} de {pages}</span><div><button disabled={page===1} onClick={()=>setPage((current)=>current-1)}>←</button><button disabled={page===pages} onClick={()=>setPage((current)=>current+1)}>→</button></div></div></div>}
    </section>
    {editing&&<div className="demo-modal-backdrop" onMouseDown={()=>setEditing(null)}><form className="demo-modal" onSubmit={save} onMouseDown={(event)=>event.stopPropagation()}><div><span>MODELO CONCEITUAL</span><h3>{editing==='new'?'Novo registro':'Editar registro'}</h3><button type="button" onClick={()=>setEditing(null)} aria-label="Fechar">×</button></div><label>Nome<input name="name" required defaultValue={editing==='new'?'':editing.name} /></label><label>Tipo<select name="type" defaultValue={editing==='new'?'Sistema':editing.type}><option>Sistema</option><option>Aplicativo</option><option>Site</option><option>Landing page</option></select></label><label>Status<select name="status" defaultValue={editing==='new'?'Em análise':editing.status}><option>Ativo</option><option>Em análise</option><option>Pausado</option></select></label><label>Valor ilustrativo<input name="value" required defaultValue={editing==='new'?'R$ 0,00':editing.value} /></label><footer><button type="button" onClick={()=>setEditing(null)}>Cancelar</button><button className="demo-primary" type="submit">Salvar registro</button></footer></form></div>}
    <Notice message={notice} />
  </div>;
}

function LandingDemo() {
  const [faq, setFaq] = useState<number | null>(0);
  const [sent, setSent] = useState(false);
  function submit(event: FormEvent<HTMLFormElement>){event.preventDefault();setSent(true);event.currentTarget.reset()}
  return <div className="landing-demo demo-surface">
    <header><b>IMPULSO</b><nav><a href="#landing-beneficios">Benefícios</a><a href="#landing-processo">Como funciona</a><a href="#landing-faq">Dúvidas</a></nav><a href="#landing-contato">Quero conversar</a></header>
    <section className="landing-hero"><div><span>CONSULTORIA DIGITAL CONCEITUAL</span><h2>Transforme uma boa ideia em uma experiência que gera oportunidades.</h2><p>Estratégia, mensagem e tecnologia organizadas em uma página clara, rápida e preparada para conversão.</p><div><a href="#landing-contato">Solicitar diagnóstico</a><a href="#landing-beneficios">Conhecer benefícios</a></div></div><aside><small>VISÃO DA CAMPANHA</small><strong>+ oportunidades</strong><div>{[62,76,68,90,82].map((height)=><i key={height} style={{height:`${height}%`}} />)}</div><span>Dados meramente ilustrativos</span></aside></section>
    <section className="landing-benefits" id="landing-beneficios"><span>POR QUE ESTE MODELO FUNCIONA</span><h3>Uma jornada simples para apresentar, convencer e converter.</h3><div>{[['01','Mensagem clara','O visitante entende rapidamente a proposta.'],['02','Conteúdo estratégico','Benefícios e objeções aparecem na ordem certa.'],['03','Contato fácil','Chamadas para ação conduzem ao próximo passo.']].map(([number,title,text])=><article key={number}><span>{number}</span><b>{title}</b><p>{text}</p></article>)}</div></section>
    <section className="landing-process" id="landing-processo"><div><span>COMO FUNCIONA</span><h3>Do primeiro contato à oportunidade.</h3><p>Uma estrutura conceitual que pode ser adaptada a produtos, serviços, eventos ou lançamentos.</p></div><ol>{['Descoberta da oferta','Organização da mensagem','Criação da experiência','Publicação e acompanhamento'].map((item,index)=><li key={item}><span>{index+1}</span>{item}</li>)}</ol></section>
    <section className="landing-testimonials"><span>EXEMPLOS ILUSTRATIVOS</span><div><blockquote>“A proposta ficou mais fácil de entender e o contato mais direto.”<cite>Depoimento ilustrativo • Perfil A</cite></blockquote><blockquote>“Uma estrutura clara ajuda o visitante a decidir o próximo passo.”<cite>Depoimento ilustrativo • Perfil B</cite></blockquote></div></section>
    <section className="landing-faq" id="landing-faq"><div><span>DÚVIDAS FREQUENTES</span><h3>Antes de começar.</h3></div><div>{[['O modelo pode usar minha identidade visual?','Sim. Cores, tipografia, textos e componentes podem ser adaptados à sua marca.'],['É possível integrar com WhatsApp?','Sim. A página pode direcionar contatos para WhatsApp, formulário ou outro canal.'],['O conteúdo será personalizado?','Sim. Este exemplo serve apenas para demonstrar a estrutura e as interações.']].map(([question,answer],index)=><article key={question}><button aria-expanded={faq===index} onClick={()=>setFaq(faq===index?null:index)}><b>{question}</b><span>{faq===index?'−':'+'}</span></button>{faq===index&&<p>{answer}</p>}</article>)}</div></section>
    <section className="landing-contact" id="landing-contato"><div><span>PRÓXIMO PASSO</span><h3>Conte o que você deseja apresentar.</h3><p>Este formulário funciona somente como demonstração e não envia dados para um servidor.</p></div><form onSubmit={submit}><label>Nome<input required placeholder="Seu nome" /></label><label>E-mail<input required type="email" placeholder="voce@empresa.com" /></label><label>Objetivo<select required defaultValue=""><option value="" disabled>Selecione</option><option>Gerar contatos</option><option>Apresentar serviço</option><option>Divulgar lançamento</option></select></label><button type="submit">Enviar demonstração</button>{sent&&<p role="status">✓ Formulário validado com sucesso.</p>}</form></section>
    <footer><b>IMPULSO</b><span>Modelo conceitual de landing page • CEFAS</span></footer>
  </div>;
}

function InstitutionalDemo() {
  const [menu, setMenu] = useState(false);
  const [sent, setSent] = useState(false);
  const [notice, setNotice] = useState('');
  function submit(event:FormEvent<HTMLFormElement>){event.preventDefault();event.currentTarget.reset();setSent(true)}
  return <div className="institutional-demo demo-surface">
    <header><b>NEXO</b><button className="institutional-menu" onClick={()=>setMenu((current)=>!current)} aria-expanded={menu}>☰</button><nav className={menu?'open':''}>{[['Início','inst-inicio'],['Sobre','inst-sobre'],['Serviços','inst-servicos'],['Equipe','inst-equipe'],['Contato','inst-contato']].map(([label,id])=><a key={id} href={`#${id}`} onClick={()=>setMenu(false)}>{label}</a>)}</nav><a href="#inst-contato">Fale conosco</a></header>
    <section className="institutional-hero" id="inst-inicio"><div><span>EMPRESA CONCEITUAL</span><h2>Soluções organizadas para negócios que desejam evoluir.</h2><p>Um site institucional demonstra propósito, serviços e diferenciais com clareza e credibilidade.</p><div><a href="#inst-servicos">Conhecer serviços</a><a href="#inst-contato">Solicitar contato</a></div></div><aside><div><span>Estratégia</span><b>Direção clara</b></div><div><span>Experiência</span><b>Comunicação simples</b></div><div><span>Tecnologia</span><b>Estrutura preparada</b></div></aside></section>
    <section className="institutional-about" id="inst-sobre"><div><span>SOBRE O MODELO</span><h3>Uma apresentação que organiza a história e fortalece a presença digital.</h3></div><p>A empresa Nexo é fictícia e existe somente para demonstrar como informações institucionais podem ser apresentadas. Todo conteúdo pode ser substituído pela identidade e realidade do cliente.</p></section>
    <section className="institutional-services" id="inst-servicos"><span>NOSSOS SERVIÇOS</span><h3>Frentes que podem ser apresentadas.</h3><div>{[['01','Planejamento','Estruturação de objetivos, prioridades e caminhos.'],['02','Operações','Organização de processos e acompanhamento.'],['03','Tecnologia','Soluções digitais alinhadas à estratégia.']].map(([number,title,text])=><article key={number}><span>{number}</span><b>{title}</b><p>{text}</p><button onClick={()=>setNotice(`${title}: conteúdo demonstrativo aberto.`)}>Saiba mais →</button></article>)}</div></section>
    <section className="institutional-differences"><div><span>DIFERENCIAIS</span><h3>Clareza em cada etapa.</h3></div><ul>{['Atendimento próximo','Processos organizados','Comunicação transparente','Evolução contínua'].map((item)=><li key={item}>✓ {item}</li>)}</ul></section>
    <section className="institutional-team" id="inst-equipe"><span>EQUIPE ILUSTRATIVA</span><h3>Pessoas por trás da experiência.</h3><div>{[['AN','Estratégia'],['BR','Operações'],['CL','Tecnologia']].map(([initials,area])=><article key={initials}><i>{initials}</i><b>Perfil conceitual</b><span>{area}</span></article>)}</div></section>
    <section className="institutional-faq"><span>DÚVIDAS FREQUENTES</span><details><summary>O site pode ter outras páginas?</summary><p>Sim. A estrutura pode crescer com páginas de serviços, projetos, conteúdo ou áreas restritas.</p></details><details><summary>É possível personalizar todo o visual?</summary><p>Sim. Este modelo é apenas uma referência de navegação, conteúdo e composição.</p></details></section>
    <section className="institutional-contact" id="inst-contato"><div><span>CONTATO</span><h3>Vamos conversar sobre a sua necessidade.</h3><p>Envie uma mensagem demonstrativa ou experimente o botão de WhatsApp.</p><button onClick={()=>setNotice('Botão de WhatsApp demonstrativo acionado.')}>WhatsApp demonstrativo</button></div><form onSubmit={submit}><label>Nome<input required /></label><label>E-mail<input type="email" required /></label><label>Mensagem<textarea required rows={4} /></label><button type="submit">Enviar mensagem</button>{sent&&<p role="status">✓ Mensagem validada no modelo.</p>}</form></section>
    <footer><div><b>NEXO</b><p>Empresa conceitual criada para demonstração.</p></div><nav><a href="#inst-inicio">Início</a><a href="#inst-servicos">Serviços</a><a href="#inst-contato">Contato</a></nav><span>Modelo conceitual • CEFAS</span></footer><Notice message={notice} />
  </div>;
}

type AppScreen = 'welcome'|'login'|'home'|'tasks'|'detail'|'favorites'|'notifications'|'profile';
const appTasks = [{id:1,title:'Revisar proposta',category:'Prioridade',done:false},{id:2,title:'Atualizar apresentação',category:'Conteúdo',done:false},{id:3,title:'Reunião de alinhamento',category:'Agenda',done:true}];
function AppDemo() {
  const [screen,setScreen]=useState<AppScreen>('welcome');
  const [search,setSearch]=useState('');
  const [filter,setFilter]=useState('Todas');
  const [favorite,setFavorite]=useState<number[]>([2]);
  const [selected,setSelected]=useState(1);
  const tasks=useMemo(()=>appTasks.filter((task)=>task.title.toLowerCase().includes(search.toLowerCase())&&(filter==='Todas'||task.category===filter)),[search,filter]);
  const goDetail=(id:number)=>{setSelected(id);setScreen('detail')};
  function login(event:FormEvent<HTMLFormElement>){event.preventDefault();setScreen('home')}
  const selectedTask=appTasks.find((task)=>task.id===selected)!;
  return <div className="app-demo demo-surface"><div className="app-presentation"><span>DEMONSTRAÇÃO INTERATIVA</span><h2>Experimente o fluxo dentro do celular.</h2><p>Navegue pelas telas, pesquise tarefas, aplique filtros e marque itens como favoritos. Nenhum dado é enviado ou armazenado.</p><ul><li>✓ Acesso demonstrativo</li><li>✓ Conteúdo adaptado ao celular</li><li>✓ Interações sem recarregar</li></ul></div><div className="app-device"><div className="app-speaker" /><div className="app-screen">
    {screen==='welcome'&&<section className="app-welcome"><span>CEFAS CONCEITO</span><i>✓</i><h3>Organize o seu dia de forma simples.</h3><p>Um aplicativo conceitual para acompanhar atividades e informações importantes.</p><button onClick={()=>setScreen('login')}>Começar</button></section>}
    {screen==='login'&&<form className="app-login" onSubmit={login}><button type="button" onClick={()=>setScreen('welcome')}>←</button><span>ACESSO DEMONSTRATIVO</span><h3>Que bom ter você aqui.</h3><p>Use apenas um apelido. Não informe dados sensíveis.</p><label>Apelido<input required placeholder="Como podemos chamar você?" /></label><label>Código demonstrativo<input required inputMode="numeric" defaultValue="1234" /></label><button type="submit">Entrar no modelo</button><small>Nenhuma autenticação real é realizada.</small></form>}
    {screen==='home'&&<section className="app-home"><header><div><small>OLÁ, VISITANTE</small><b>Visão geral</b></div><button onClick={()=>setScreen('notifications')}>●</button></header><div className="app-summary"><article><span>Tarefas</span><strong>03</strong></article><article><span>Concluídas</span><strong>01</strong></article></div><div className="app-progress"><span><b>Progresso do dia</b><em>64%</em></span><i><b /></i></div><div className="app-list-title"><b>Próximas atividades</b><button onClick={()=>setScreen('tasks')}>Ver todas</button></div>{appTasks.slice(0,2).map((task)=><button className="app-task" key={task.id} onClick={()=>goDetail(task.id)}><i>{task.done?'✓':'•'}</i><span><b>{task.title}</b><small>{task.category}</small></span><em>›</em></button>)}</section>}
    {screen==='tasks'&&<section className="app-tasks"><header><b>Tarefas</b><button onClick={()=>setScreen('notifications')}>●</button></header><label className="app-search">⌕<input value={search} onChange={(event)=>setSearch(event.target.value)} placeholder="Buscar tarefa" /></label><div className="app-filters">{['Todas','Prioridade','Conteúdo','Agenda'].map((item)=><button className={filter===item?'active':''} key={item} onClick={()=>setFilter(item)}>{item}</button>)}</div>{tasks.length?tasks.map((task)=><button className="app-task" key={task.id} onClick={()=>goDetail(task.id)}><i>{task.done?'✓':'•'}</i><span><b>{task.title}</b><small>{task.category}</small></span><em>›</em></button>):<div className="app-empty"><b>Nada encontrado</b><span>Tente outro termo ou filtro.</span></div>}</section>}
    {screen==='detail'&&<section className="app-detail"><header><button onClick={()=>setScreen('tasks')}>←</button><b>Detalhes</b><button onClick={()=>setFavorite((current)=>current.includes(selected)?current.filter((id)=>id!==selected):[...current,selected])}>{favorite.includes(selected)?'★':'☆'}</button></header><span>{selectedTask.category}</span><h3>{selectedTask.title}</h3><p>Esta tela mostra como detalhes, informações complementares e ações podem ser organizados no aplicativo.</p><div><small>STATUS</small><b>{selectedTask.done?'Concluída':'Em andamento'}</b></div><div><small>LEMBRETE</small><b>Hoje, 16:30</b></div><button onClick={()=>setScreen('tasks')}>Marcar como acompanhada</button></section>}
    {screen==='favorites'&&<section className="app-tasks"><header><b>Favoritos</b><span>★</span></header>{appTasks.filter((task)=>favorite.includes(task.id)).map((task)=><button className="app-task" key={task.id} onClick={()=>goDetail(task.id)}><i>★</i><span><b>{task.title}</b><small>{task.category}</small></span><em>›</em></button>)}{favorite.length===0&&<div className="app-empty"><b>Sem favoritos</b><span>Marque uma tarefa para vê-la aqui.</span></div>}</section>}
    {screen==='notifications'&&<section className="app-notifications"><header><button onClick={()=>setScreen('home')}>←</button><b>Notificações</b><span /></header>{[['Agora','Seu painel conceitual está pronto para explorar.'],['Hoje','Uma atividade recebeu uma atualização ilustrativa.'],['Ontem','Seu resumo semanal foi preparado.']].map(([time,text])=><article key={time}><i /><div><small>{time}</small><p>{text}</p></div></article>)}</section>}
    {screen==='profile'&&<section className="app-profile"><i>CV</i><h3>Conta demonstrativa</h3><span>Perfil conceitual</span><div><button>Preferências <em>›</em></button><button>Privacidade <em>›</em></button><button>Ajuda <em>›</em></button></div><button onClick={()=>setScreen('welcome')}>Sair da demonstração</button></section>}
    {!['welcome','login'].includes(screen)&&<nav className="app-bottom-nav"><button className={screen==='home'?'active':''} onClick={()=>setScreen('home')}><i>⌂</i>Início</button><button className={screen==='tasks'||screen==='detail'?'active':''} onClick={()=>setScreen('tasks')}><i>☷</i>Tarefas</button><button className={screen==='favorites'?'active':''} onClick={()=>setScreen('favorites')}><i>☆</i>Favoritos</button><button className={screen==='profile'?'active':''} onClick={()=>setScreen('profile')}><i>○</i>Perfil</button></nav>}
  </div></div></div>;
}

export default function ProjectDemoPage({ kind }: { kind: DemoKind }) {
  const config = demoConfig[kind];
  const contactUrl = `/?projeto=${encodeURIComponent(config.formType)}#contato`;
  return <main className="project-demo-page"><div className="site-background" aria-hidden="true" />
    <header className="demo-site-header"><a className="demo-brand" href="/#inicio"><img src="/cefas-logo-clean.png" alt="CEFAS" /></a><nav><a href="/#projetos">← Voltar para projetos</a><a href={contactUrl}>Solicitar orçamento</a></nav></header>
    <section className="demo-page-intro"><div><span>MODELO CONCEITUAL • {config.category}</span><h1>{config.title}</h1><p>{config.description}</p></div><aside><i>INTERATIVO</i><b>Experimente os controles abaixo</b><span>Todos os dados e conteúdos são ilustrativos.</span></aside></section>
    <section className="demo-interactive-stage">{kind==='admin'?<AdminDemo/>:kind==='landing'?<LandingDemo/>:kind==='institutional'?<InstitutionalDemo/>:<AppDemo/>}</section>
    <section className="demo-page-details"><div><span>FUNCIONALIDADES POSSÍVEIS</span><h2>Uma base para construir algo do seu jeito.</h2><p>Este é um modelo ilustrativo e pode ser totalmente personalizado.</p></div><ul>{config.features.map((feature)=><li key={feature}><span>✓</span>{feature}</li>)}</ul></section>
    <section className="demo-page-cta"><div><span>GOSTOU DESTE MODELO?</span><h2>Vamos adaptar esta experiência ao seu negócio.</h2><p>Conte suas necessidades e receba uma orientação para transformar este conceito em um projeto real.</p></div><div><a className="button" href={contactUrl}>Solicitar projeto semelhante <b>→</b></a>{siteConfig.whatsappUrl&&<a className="button button-ghost" href={siteConfig.whatsappUrl} target="_blank" rel="noreferrer">Falar pelo WhatsApp</a>}</div></section>
    <footer className="demo-site-footer"><a className="demo-brand" href="/#inicio"><img src="/cefas-logo-clean.png" alt="CEFAS" /></a><span>Modelo conceitual para demonstração • {new Date().getFullYear()}</span><a href="/#projetos">Ver outros projetos</a></footer>
  </main>;
}
