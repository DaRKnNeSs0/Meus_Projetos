import { getChatGPTUser } from '../../chatgpt-auth';
import { ensurePersonalSchema } from '../../../lib/personal-data';
import { bindings, json, uid } from '../../../lib/platform';

const clean = (value: unknown, max = 1500) => String(value ?? '').trim().slice(0, max);

export async function GET() {
  const user = await getChatGPTUser();
  if (!user) return json({ error: 'authentication_required' }, 401);
  await ensurePersonalSchema();
  const profile = await bindings.DB.prepare('SELECT * FROM company_profiles WHERE owner_id = ?').bind(user.userId).first();
  return json({ data: profile ?? null });
}

export async function PUT(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return json({ error: 'authentication_required' }, 401);
  await ensurePersonalSchema();
  const body = await request.json() as Record<string, unknown>;
  await bindings.DB.batch([
    bindings.DB.prepare(`INSERT INTO company_profiles (owner_id, company_name, document, phone, whatsapp, email, site, address, footer_text, commercial_notes, signature_text, logo_url, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP) ON CONFLICT(owner_id) DO UPDATE SET company_name = excluded.company_name, document = excluded.document, phone = excluded.phone, whatsapp = excluded.whatsapp, email = excluded.email, site = excluded.site, address = excluded.address, footer_text = excluded.footer_text, commercial_notes = excluded.commercial_notes, signature_text = excluded.signature_text, logo_url = excluded.logo_url, updated_at = CURRENT_TIMESTAMP`).bind(user.userId, clean(body.companyName, 180) || null, clean(body.document, 40) || null, clean(body.phone, 40) || null, clean(body.whatsapp, 40) || null, clean(body.email, 180) || null, clean(body.site, 180) || null, clean(body.address, 500) || null, clean(body.footerText) || null, clean(body.commercialNotes) || null, clean(body.signatureText, 300) || null, clean(body.logoUrl, 300) || '/cefas-logo-clean.png'),
    bindings.DB.prepare(`INSERT INTO catalog_history (id, owner_id, entity_type, entity_id, action, details) VALUES (?, ?, 'company', ?, 'updated', 'Dados da empresa atualizados')`).bind(uid('his'), user.userId, user.userId),
  ]);
  return json({ data: { saved: true } });
}
