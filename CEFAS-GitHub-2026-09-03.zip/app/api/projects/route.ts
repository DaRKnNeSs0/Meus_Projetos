import { getChatGPTUser } from '../../chatgpt-auth';
import { bindings, ensureCoreSchema, json, sanitize, sha256, uid } from '../../../lib/platform';

export async function GET(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return json({ error: 'authentication_required' }, 401);
  await ensureCoreSchema();
  const tenantId = new URL(request.url).searchParams.get('tenant_id');
  if (!tenantId) return json({ error: 'tenant_id_required' }, 400);
  const rows = await bindings.DB.prepare(`SELECT p.*, (SELECT COUNT(*) FROM tickets t WHERE t.project_id = p.id AND t.status NOT IN ('resolved','finished','cancelled')) AS open_tickets, (SELECT MAX(received_at) FROM heartbeats h WHERE h.project_id = p.id) AS last_heartbeat_at FROM projects p WHERE p.tenant_id = ? AND p.deleted_at IS NULL ORDER BY p.name`).bind(tenantId).all();
  return json({ data: rows.results });
}

export async function POST(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return json({ error: 'authentication_required' }, 401);
  await ensureCoreSchema();
  const body = sanitize(await request.json()) as Record<string, string>;
  if (!body.tenantId || !body.name || !body.code || !body.type) return json({ error: 'validation_error' }, 422);
  const id = uid('prj');
  const rawKey = `cfs_${crypto.randomUUID().replaceAll('-', '')}`;
  const keyHash = await sha256(rawKey);
  await bindings.DB.batch([
    bindings.DB.prepare(`INSERT INTO projects (id, tenant_id, client_id, code, name, type, description, url, api_url, technology, framework, current_version, technical_owner, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'unknown')`).bind(id, body.tenantId, body.clientId ?? null, body.code, body.name, body.type, body.description ?? null, body.url ?? null, body.apiUrl ?? null, body.technology ?? null, body.framework ?? null, body.currentVersion ?? null, body.technicalOwner ?? null),
    bindings.DB.prepare(`INSERT INTO api_keys (id, project_id, name, key_prefix, key_hash) VALUES (?, ?, 'Chave inicial', ?, ?)`).bind(uid('key'), id, rawKey.slice(0, 8), keyHash),
  ]);
  return json({ data: { id, projectId: id, projectKey: rawKey, warning: 'A chave é exibida somente nesta resposta. Armazene-a no backend do projeto.' } }, 201);
}
