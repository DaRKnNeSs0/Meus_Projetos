import { bindings, integrationProject, json, sanitize, uid } from '../../../lib/platform';

export async function POST(request: Request) {
  const project = await integrationProject(request);
  if (!project) return json({ error: 'invalid_project_credentials' }, 401);
  const body = sanitize(await request.json()) as Record<string, unknown>;
  const environment = String(body.environment ?? 'production');
  const now = new Date().toISOString();
  await bindings.DB.batch([
    bindings.DB.prepare(`INSERT INTO heartbeats (id, project_id, environment, version, status, payload, received_at) VALUES (?, ?, ?, ?, ?, ?, ?)`).bind(uid('hb'), project.id, environment, body.version ?? null, body.status ?? 'online', JSON.stringify(body), now),
    bindings.DB.prepare(`UPDATE projects SET status = ?, current_version = COALESCE(?, current_version), updated_at = ? WHERE id = ?`).bind(body.status ?? 'online', body.version ?? null, now, project.id),
  ]);
  return json({ accepted: true, receivedAt: now }, 202);
}
