import { getChatGPTUser } from '../../chatgpt-auth';
import { bindings, ensureCoreSchema, json, nextNumber, sanitize, uid } from '../../../lib/platform';

export async function GET(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return json({ error: 'authentication_required' }, 401);
  await ensureCoreSchema();
  const tenantId = new URL(request.url).searchParams.get('tenant_id');
  if (!tenantId) return json({ error: 'tenant_id_required' }, 400);
  const rows = await bindings.DB.prepare(`SELECT i.*, p.name AS project_name FROM incidents i JOIN projects p ON p.id = i.project_id WHERE i.tenant_id = ? AND i.deleted_at IS NULL ORDER BY i.started_at DESC LIMIT 100`).bind(tenantId).all();
  return json({ data: rows.results });
}

export async function POST(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return json({ error: 'authentication_required' }, 401);
  await ensureCoreSchema();
  const body = sanitize(await request.json()) as Record<string, string>;
  if (!body.tenantId || !body.projectId || !body.title || !body.severity) return json({ error: 'validation_error' }, 422);
  const id = uid('inc');
  const number = await nextNumber(body.tenantId, 'incident');
  await bindings.DB.prepare(`INSERT INTO incidents (id, tenant_id, project_id, ticket_id, number, title, severity, status, started_at, fingerprint) VALUES (?, ?, ?, ?, ?, ?, ?, 'open', ?, ?)`).bind(id, body.tenantId, body.projectId, body.ticketId ?? null, number, body.title, body.severity, new Date().toISOString(), body.fingerprint ?? null).run();
  return json({ data: { id, number, status: 'open' } }, 201);
}
