import { getChatGPTUser } from '../../chatgpt-auth';
import { ensurePersonalSchema } from '../../../lib/personal-data';
import { bindings, json } from '../../../lib/platform';

export async function GET() {
  const user = await getChatGPTUser();
  if (!user) return json({ error: 'authentication_required' }, 401);
  await ensurePersonalSchema();
  const rows = await bindings.DB.prepare('SELECT * FROM catalog_history WHERE owner_id = ? ORDER BY created_at DESC LIMIT 20').bind(user.userId).all();
  return json({ data: rows.results });
}
