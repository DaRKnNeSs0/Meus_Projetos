import { getChatGPTUser } from '../../../chatgpt-auth';
import { ensurePersonalSchema } from '../../../../lib/personal-data';
import { bindings, json, uid } from '../../../../lib/platform';

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getChatGPTUser();
  if (!user) return json({ error: 'authentication_required' }, 401);
  await ensurePersonalSchema();
  const { id } = await context.params;
  const current = await bindings.DB.prepare('SELECT id FROM personal_clients WHERE id = ? AND owner_id = ? AND deleted_at IS NULL').bind(id, user.userId).first();
  if (!current) return json({ error: 'not_found' }, 404);
  const body = await request.json() as Record<string, unknown>;
  const name = String(body.name ?? '').trim().slice(0, 180);
  if (!name) return json({ error: 'validation_error', fields: ['name'] }, 422);
  const document = String(body.document ?? '').replace(/\D/g, '') || null;
  if (document) {
    const duplicate = await bindings.DB.prepare('SELECT id FROM personal_clients WHERE owner_id = ? AND document = ? AND id != ? AND deleted_at IS NULL').bind(user.userId, document, id).first();
    if (duplicate) return json({ error: 'duplicate_document' }, 409);
  }
  await bindings.DB.batch([
    bindings.DB.prepare(`UPDATE personal_clients SET code = COALESCE(?, code), person_type = ?, name = ?, trade_name = ?, document = ?, state_registration = ?, contact_name = ?, email = ?, phone = ?, whatsapp = ?, postal_code = ?, address = ?, address_number = ?, address_complement = ?, neighborhood = ?, city = ?, state = ?, notes = ?, status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND owner_id = ?`).bind(body.code || null, body.personType || 'Pessoa jurídica', name, body.tradeName || null, document, body.stateRegistration || null, body.contactName || null, body.email || null, body.phone || null, body.whatsapp || null, body.postalCode || null, body.address || null, body.addressNumber || null, body.addressComplement || null, body.neighborhood || null, body.city || null, body.state || null, body.notes || null, body.status || 'Ativo', id, user.userId),
    bindings.DB.prepare(`INSERT INTO catalog_history (id, owner_id, entity_type, entity_id, action, details) VALUES (?, ?, 'client', ?, 'updated', ?)`).bind(uid('his'), user.userId, id, `Cliente ${name} atualizado`),
  ]);
  return json({ data: { id, name } });
}

export async function DELETE(_: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getChatGPTUser();
  if (!user) return json({ error: 'authentication_required' }, 401);
  await ensurePersonalSchema();
  const { id } = await context.params;
  const current = await bindings.DB.prepare('SELECT name FROM personal_clients WHERE id = ? AND owner_id = ? AND deleted_at IS NULL').bind(id, user.userId).first<{ name: string }>();
  if (!current) return json({ error: 'not_found' }, 404);
  await bindings.DB.batch([
    bindings.DB.prepare(`UPDATE personal_clients SET status = 'Inativo', updated_at = CURRENT_TIMESTAMP WHERE id = ? AND owner_id = ?`).bind(id, user.userId),
    bindings.DB.prepare(`INSERT INTO catalog_history (id, owner_id, entity_type, entity_id, action, details) VALUES (?, ?, 'client', ?, 'deactivated', ?)`).bind(uid('his'), user.userId, id, `Cliente ${current.name} inativado`),
  ]);
  return json({ data: { id, status: 'Inativo' } });
}
