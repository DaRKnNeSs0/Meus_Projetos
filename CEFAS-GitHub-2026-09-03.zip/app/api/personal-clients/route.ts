import { getChatGPTUser } from '../../chatgpt-auth';
import { ensurePersonalSchema } from '../../../lib/personal-data';
import { bindings, ensureCoreSchema, json, nextNumber, uid } from '../../../lib/platform';

export async function GET() {
  const user = await getChatGPTUser();
  if (!user) return json({ error: 'authentication_required' }, 401);
  await ensurePersonalSchema();
  const rows = await bindings.DB.prepare(`SELECT c.*, (SELECT COUNT(*) FROM personal_projects p WHERE p.client_id = c.id AND p.deleted_at IS NULL) AS project_count, (SELECT COUNT(*) FROM quotes q WHERE q.client_id = c.id AND q.deleted_at IS NULL) AS quote_count FROM personal_clients c WHERE c.owner_id = ? AND c.deleted_at IS NULL ORDER BY c.name`).bind(user.userId).all();
  return json({ data: rows.results });
}

export async function POST(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return json({ error: 'authentication_required' }, 401);
  await ensureCoreSchema();
  await ensurePersonalSchema();
  const body = await request.json() as Record<string, unknown>;
  const name = String(body.name ?? '').trim().slice(0, 180);
  if (!name) return json({ error: 'validation_error', fields: ['name'] }, 422);
  const document = String(body.document ?? '').replace(/\D/g, '') || null;
  if (document) {
    const duplicate = await bindings.DB.prepare('SELECT id FROM personal_clients WHERE owner_id = ? AND document = ? AND deleted_at IS NULL').bind(user.userId, document).first();
    if (duplicate) return json({ error: 'duplicate_document' }, 409);
  }
  const id = uid('cli');
  const number = await nextNumber(user.userId, 'client');
  const code = String(body.code ?? '').trim().toUpperCase() || `CLI-${String(number).padStart(4, '0')}`;
  await bindings.DB.batch([
    bindings.DB.prepare(`INSERT INTO personal_clients (id, owner_id, code, person_type, name, trade_name, document, state_registration, contact_name, email, phone, whatsapp, postal_code, address, address_number, address_complement, neighborhood, city, state, notes, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).bind(id, user.userId, code, body.personType || 'Pessoa jurídica', name, body.tradeName || null, document, body.stateRegistration || null, body.contactName || null, body.email || null, body.phone || null, body.whatsapp || null, body.postalCode || null, body.address || null, body.addressNumber || null, body.addressComplement || null, body.neighborhood || null, body.city || null, body.state || null, body.notes || null, body.status || 'Ativo'),
    bindings.DB.prepare(`INSERT INTO catalog_history (id, owner_id, entity_type, entity_id, action, details) VALUES (?, ?, 'client', ?, 'created', ?)`).bind(uid('his'), user.userId, id, `Cliente ${name} cadastrado`),
  ]);
  return json({ data: { id, code, name } }, 201);
}
