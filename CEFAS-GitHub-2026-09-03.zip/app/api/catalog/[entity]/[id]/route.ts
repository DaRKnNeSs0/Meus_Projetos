import { getChatGPTUser } from '../../../../chatgpt-auth';
import { ensurePersonalSchema } from '../../../../../lib/personal-data';
import { bindings, json, uid } from '../../../../../lib/platform';

const tables: Record<string, string> = { items: 'catalog_items', categories: 'catalog_categories', units: 'catalog_units', payments: 'catalog_payment_methods' };
const clean = (value: unknown, max = 500) => String(value ?? '').trim().slice(0, max);
const money = (value: unknown) => Math.max(0, Math.round(Number(value) || 0));

async function owned(entity: string, id: string, ownerId: string) {
  const table = tables[entity];
  if (!table) return null;
  return bindings.DB.prepare(`SELECT * FROM ${table} WHERE id = ? AND owner_id = ? AND deleted_at IS NULL`).bind(id, ownerId).first<Record<string, unknown>>();
}

export async function PATCH(request: Request, context: { params: Promise<{ entity: string; id: string }> }) {
  const user = await getChatGPTUser();
  if (!user) return json({ error: 'authentication_required' }, 401);
  await ensurePersonalSchema();
  const { entity, id } = await context.params;
  if (!tables[entity] || !(await owned(entity, id, user.userId))) return json({ error: 'not_found' }, 404);
  const body = await request.json() as Record<string, unknown>;
  const name = clean(body.name, 180);
  if (!name) return json({ error: 'validation_error', fields: ['name'] }, 422);
  try {
    if (entity === 'items') {
      await bindings.DB.prepare(`UPDATE catalog_items SET code = ?, item_type = ?, name = ?, description = ?, category_id = ?, unit_id = ?, sale_price_cents = ?, cost_cents = ?, tax_percent = ?, max_discount_percent = ?, delivery_terms = ?, notes = ?, status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND owner_id = ?`).bind(clean(body.code, 60).toUpperCase(), body.itemType || 'Serviço', name, clean(body.description, 3000) || null, body.categoryId || null, body.unitId || null, money(body.salePriceCents), body.costCents == null ? null : money(body.costCents), Math.max(0, Number(body.taxPercent) || 0), Math.max(0, Number(body.maxDiscountPercent) || 0), clean(body.deliveryTerms, 500) || null, clean(body.notes, 2000) || null, body.status || 'Ativo', id, user.userId).run();
    } else if (entity === 'categories') {
      await bindings.DB.prepare(`UPDATE catalog_categories SET name = ?, entity_type = ?, description = ?, color = ?, status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND owner_id = ?`).bind(name, body.entityType || 'Produto ou serviço', clean(body.description, 1000) || null, body.color || '#287cec', body.status || 'Ativo', id, user.userId).run();
    } else if (entity === 'units') {
      await bindings.DB.prepare(`UPDATE catalog_units SET name = ?, abbreviation = ?, allows_decimal = ?, status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND owner_id = ?`).bind(name, clean(body.abbreviation, 20), body.allowsDecimal ? 1 : 0, body.status || 'Ativo', id, user.userId).run();
    } else {
      await bindings.DB.prepare(`UPDATE catalog_payment_methods SET name = ?, type = ?, installments = ?, interval_days = ?, default_terms = ?, notes = ?, status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND owner_id = ?`).bind(name, body.type || 'À vista', Math.max(1, Number(body.installments) || 1), Math.max(0, Number(body.intervalDays) || 0), clean(body.defaultTerms, 1000) || null, clean(body.notes, 1000) || null, body.status || 'Ativo', id, user.userId).run();
    }
    await bindings.DB.prepare(`INSERT INTO catalog_history (id, owner_id, entity_type, entity_id, action, details) VALUES (?, ?, ?, ?, 'updated', ?)`).bind(uid('his'), user.userId, entity, id, `${name} atualizado`).run();
    return json({ data: { id, name } });
  } catch (error) {
    const message = error instanceof Error ? error.message : '';
    return json({ error: message.includes('UNIQUE') ? 'duplicate_record' : 'save_failed' }, message.includes('UNIQUE') ? 409 : 500);
  }
}

export async function POST(_: Request, context: { params: Promise<{ entity: string; id: string }> }) {
  const user = await getChatGPTUser();
  if (!user) return json({ error: 'authentication_required' }, 401);
  await ensurePersonalSchema();
  const { entity, id } = await context.params;
  if (entity !== 'items') return json({ error: 'not_supported' }, 405);
  const item = await owned(entity, id, user.userId);
  if (!item) return json({ error: 'not_found' }, 404);
  const copyId = uid('ite');
  const suffix = Math.random().toString(36).slice(2, 6).toUpperCase();
  const code = `${String(item.code)}-COPIA-${suffix}`.slice(0, 60);
  const name = `${String(item.name)} (cópia)`;
  await bindings.DB.batch([
    bindings.DB.prepare(`INSERT INTO catalog_items (id, owner_id, code, item_type, name, description, category_id, unit_id, sale_price_cents, cost_cents, tax_percent, max_discount_percent, delivery_terms, notes, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Ativo')`).bind(copyId, user.userId, code, item.item_type, name, item.description, item.category_id, item.unit_id, item.sale_price_cents, item.cost_cents, item.tax_percent, item.max_discount_percent, item.delivery_terms, item.notes),
    bindings.DB.prepare(`INSERT INTO catalog_history (id, owner_id, entity_type, entity_id, action, details) VALUES (?, ?, 'items', ?, 'duplicated', ?)`).bind(uid('his'), user.userId, copyId, `Duplicado de ${String(item.name)}`),
  ]);
  return json({ data: { id: copyId, name, code } }, 201);
}

export async function DELETE(_: Request, context: { params: Promise<{ entity: string; id: string }> }) {
  const user = await getChatGPTUser();
  if (!user) return json({ error: 'authentication_required' }, 401);
  await ensurePersonalSchema();
  const { entity, id } = await context.params;
  const item = await owned(entity, id, user.userId);
  if (!item || !tables[entity]) return json({ error: 'not_found' }, 404);
  await bindings.DB.batch([
    bindings.DB.prepare(`UPDATE ${tables[entity]} SET status = 'Inativo', updated_at = CURRENT_TIMESTAMP WHERE id = ? AND owner_id = ?`).bind(id, user.userId),
    bindings.DB.prepare(`INSERT INTO catalog_history (id, owner_id, entity_type, entity_id, action, details) VALUES (?, ?, ?, ?, 'deactivated', ?)`).bind(uid('his'), user.userId, entity, id, `${String(item.name)} inativado`),
  ]);
  return json({ data: { id, status: 'Inativo' } });
}
