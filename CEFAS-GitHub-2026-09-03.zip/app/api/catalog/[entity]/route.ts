import { getChatGPTUser } from '../../../chatgpt-auth';
import { ensurePersonalSchema } from '../../../../lib/personal-data';
import { bindings, json, uid } from '../../../../lib/platform';

const entities = ['items', 'categories', 'units', 'payments'] as const;
type Entity = typeof entities[number];
const isEntity = (value: string): value is Entity => entities.includes(value as Entity);
const clean = (value: unknown, max = 500) => String(value ?? '').trim().slice(0, max);
const money = (value: unknown) => Math.max(0, Math.round(Number(value) || 0));

export async function GET(_: Request, context: { params: Promise<{ entity: string }> }) {
  const user = await getChatGPTUser();
  if (!user) return json({ error: 'authentication_required' }, 401);
  await ensurePersonalSchema();
  const { entity } = await context.params;
  if (!isEntity(entity)) return json({ error: 'not_found' }, 404);
  const query = entity === 'items'
    ? `SELECT i.*, c.name AS category_name, u.name AS unit_name, u.abbreviation AS unit_abbreviation FROM catalog_items i LEFT JOIN catalog_categories c ON c.id = i.category_id LEFT JOIN catalog_units u ON u.id = i.unit_id WHERE i.owner_id = ? AND i.deleted_at IS NULL ORDER BY i.updated_at DESC`
    : entity === 'categories'
      ? `SELECT * FROM catalog_categories WHERE owner_id = ? AND deleted_at IS NULL ORDER BY name`
      : entity === 'units'
        ? `SELECT * FROM catalog_units WHERE owner_id = ? AND deleted_at IS NULL ORDER BY name`
        : `SELECT * FROM catalog_payment_methods WHERE owner_id = ? AND deleted_at IS NULL ORDER BY name`;
  const rows = await bindings.DB.prepare(query).bind(user.userId).all();
  return json({ data: rows.results });
}

export async function POST(request: Request, context: { params: Promise<{ entity: string }> }) {
  const user = await getChatGPTUser();
  if (!user) return json({ error: 'authentication_required' }, 401);
  await ensurePersonalSchema();
  const { entity } = await context.params;
  if (!isEntity(entity)) return json({ error: 'not_found' }, 404);
  const body = await request.json() as Record<string, unknown>;
  const id = uid(entity.slice(0, 3));
  const name = clean(body.name, 180);
  if (!name) return json({ error: 'validation_error', fields: ['name'] }, 422);
  try {
    if (entity === 'items') {
      const code = clean(body.code, 60).toUpperCase();
      if (!code) return json({ error: 'validation_error', fields: ['code'] }, 422);
      await bindings.DB.prepare(`INSERT INTO catalog_items (id, owner_id, code, item_type, name, description, category_id, unit_id, sale_price_cents, cost_cents, tax_percent, max_discount_percent, delivery_terms, notes, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).bind(id, user.userId, code, body.itemType || 'Serviço', name, clean(body.description, 3000) || null, body.categoryId || null, body.unitId || null, money(body.salePriceCents), body.costCents == null ? null : money(body.costCents), Math.max(0, Number(body.taxPercent) || 0), Math.max(0, Number(body.maxDiscountPercent) || 0), clean(body.deliveryTerms, 500) || null, clean(body.notes, 2000) || null, body.status || 'Ativo').run();
    } else if (entity === 'categories') {
      await bindings.DB.prepare(`INSERT INTO catalog_categories (id, owner_id, name, entity_type, description, color, status) VALUES (?, ?, ?, ?, ?, ?, ?)`).bind(id, user.userId, name, body.entityType || 'Produto ou serviço', clean(body.description, 1000) || null, body.color || '#287cec', body.status || 'Ativo').run();
    } else if (entity === 'units') {
      const abbreviation = clean(body.abbreviation, 20);
      if (!abbreviation) return json({ error: 'validation_error', fields: ['abbreviation'] }, 422);
      await bindings.DB.prepare(`INSERT INTO catalog_units (id, owner_id, name, abbreviation, allows_decimal, status) VALUES (?, ?, ?, ?, ?, ?)`).bind(id, user.userId, name, abbreviation, body.allowsDecimal ? 1 : 0, body.status || 'Ativo').run();
    } else {
      await bindings.DB.prepare(`INSERT INTO catalog_payment_methods (id, owner_id, name, type, installments, interval_days, default_terms, notes, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`).bind(id, user.userId, name, body.type || 'À vista', Math.max(1, Number(body.installments) || 1), Math.max(0, Number(body.intervalDays) || 0), clean(body.defaultTerms, 1000) || null, clean(body.notes, 1000) || null, body.status || 'Ativo').run();
    }
    await bindings.DB.prepare(`INSERT INTO catalog_history (id, owner_id, entity_type, entity_id, action, details) VALUES (?, ?, ?, ?, 'created', ?)`).bind(uid('his'), user.userId, entity, id, `${name} cadastrado`).run();
    return json({ data: { id, name } }, 201);
  } catch (error) {
    const message = error instanceof Error ? error.message : '';
    return json({ error: message.includes('UNIQUE') ? 'duplicate_record' : 'save_failed' }, message.includes('UNIQUE') ? 409 : 500);
  }
}
