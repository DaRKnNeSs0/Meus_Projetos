import { getChatGPTUser } from '../../../../chatgpt-auth';
import { bindings, ensureCoreSchema, json, sanitize, uid } from '../../../../../lib/platform';

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getChatGPTUser();
  if (!user) return json({ error: 'authentication_required' }, 401);
  await ensureCoreSchema();
  const { id: ticketId } = await context.params;
  const body = sanitize(await request.json()) as Record<string, unknown>;
  if (!body.body) return json({ error: 'comment_required' }, 422);
  const id = uid('cmt');
  await bindings.DB.batch([
    bindings.DB.prepare(`INSERT INTO ticket_comments (id, ticket_id, author_id, author_type, body, internal) VALUES (?, ?, ?, 'support', ?, ?)`).bind(id, ticketId, user.userId, String(body.body), body.internal ? 1 : 0),
    bindings.DB.prepare(`UPDATE tickets SET updated_at = CURRENT_TIMESTAMP WHERE id = ?`).bind(ticketId),
  ]);
  return json({ data: { id, ticketId } }, 201);
}
