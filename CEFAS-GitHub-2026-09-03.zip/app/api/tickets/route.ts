import { getChatGPTUser } from '../../chatgpt-auth';
import { bindings, ensureCoreSchema, json, nextNumber, sanitize, uid } from '../../../lib/platform';

export async function GET(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return json({ error: 'authentication_required' }, 401);
  await ensureCoreSchema();
  const url = new URL(request.url);
  const tenantId = url.searchParams.get('tenant_id');
  if (!tenantId) return json({ error: 'tenant_id_required' }, 400);
  const status = url.searchParams.get('status');
  const projectId = url.searchParams.get('project_id');
  const priority = url.searchParams.get('priority');
  const clauses = ['t.tenant_id = ?', 't.deleted_at IS NULL'];
  const values: string[] = [tenantId];
  if (status) { clauses.push('t.status = ?'); values.push(status); }
  if (projectId) { clauses.push('t.project_id = ?'); values.push(projectId); }
  if (priority) { clauses.push('t.priority = ?'); values.push(priority); }
  const rows = await bindings.DB.prepare(`SELECT t.*, p.name AS project_name FROM tickets t JOIN projects p ON p.id = t.project_id WHERE ${clauses.join(' AND ')} ORDER BY t.updated_at DESC LIMIT 100`).bind(...values).all();
  return json({ data: rows.results });
}

export async function POST(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return json({ error: 'authentication_required' }, 401);
  await ensureCoreSchema();
  const body = sanitize(await request.json()) as Record<string, string>;
  const required = ['tenantId', 'projectId', 'title', 'description', 'category', 'environment'];
  const missing = required.filter((field) => !body[field]);
  if (missing.length) return json({ error: 'validation_error', fields: missing }, 422);
  const number = await nextNumber(body.tenantId, 'ticket');
  const id = uid('tkt');
  const now = new Date().toISOString();
  await bindings.DB.batch([
    bindings.DB.prepare(`INSERT INTO tickets (id, tenant_id, number, project_id, client_id, requester_id, title, description, category, priority, status, source, environment, affected_version, module, route, browser, os, device, first_occurrence_at, last_occurrence_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'new', 'user', ?, ?, ?, ?, ?, ?, ?, ?, ?)`).bind(id, body.tenantId, number, body.projectId, body.clientId ?? null, user.userId, body.title, body.description, body.category, body.priority ?? 'medium', body.environment, body.version ?? null, body.module ?? null, body.route ?? null, body.browser ?? null, body.os ?? null, body.device ?? null, now, now),
    bindings.DB.prepare(`INSERT INTO ticket_status_history (id, ticket_id, actor_id, from_status, to_status, note) VALUES (?, ?, ?, NULL, 'new', 'Ticket aberto pelo módulo de suporte')`).bind(uid('hist'), id, user.userId),
  ]);
  return json({ data: { id, number, status: 'new' } }, 201);
}
