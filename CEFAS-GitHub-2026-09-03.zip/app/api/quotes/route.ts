import { getChatGPTUser } from '../../chatgpt-auth';
import { ensureCoreSchema, bindings, json } from '../../../lib/platform';
import { ensurePersonalSchema } from '../../../lib/personal-data';
import { parseQuotePayload } from '../../../lib/quotes';
import { createQuote } from '../../../lib/quote-store';

export async function GET(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return json({ error: 'authentication_required' }, 401);
  await ensurePersonalSchema();
  const url = new URL(request.url);
  const status = url.searchParams.get('status');
  const search = url.searchParams.get('q')?.trim().toLowerCase();
  const clauses = ['owner_id = ?', 'deleted_at IS NULL'];
  const values: unknown[] = [user.userId];
  if (status && status !== 'Todos') { clauses.push('status = ?'); values.push(status); }
  if (search) { clauses.push(`(LOWER(client_name) LIKE ? OR LOWER(COALESCE(project_name, '')) LIKE ? OR CAST(number AS TEXT) LIKE ? OR EXISTS (SELECT 1 FROM quote_items qi WHERE qi.quote_id = quotes.id AND LOWER(qi.description) LIKE ?))`); const needle = `%${search}%`; values.push(needle, needle, needle, needle); }
  const rows = await bindings.DB.prepare(`SELECT * FROM quotes WHERE ${clauses.join(' AND ')} ORDER BY updated_at DESC LIMIT 200`).bind(...values).all();
  return json({ data: rows.results });
}

export async function POST(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return json({ error: 'authentication_required' }, 401);
  await ensureCoreSchema();
  await ensurePersonalSchema();
  try {
    const payload = parseQuotePayload(await request.json());
    const quote = await createQuote(user.userId, user.userId, payload);
    return json({ data: quote }, 201);
  } catch (error) {
    const code = error instanceof Error ? error.message : 'validation_error';
    return json({ error: code }, code.startsWith('invalid_') || code === 'validation_error' ? 422 : 500);
  }
}
