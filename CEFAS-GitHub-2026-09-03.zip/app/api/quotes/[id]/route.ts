import { getChatGPTUser } from '../../../chatgpt-auth';
import { ensureCoreSchema, bindings, json, uid } from '../../../../lib/platform';
import { ensurePersonalSchema } from '../../../../lib/personal-data';
import { calculateQuote, parseQuotePayload, QuotePayload } from '../../../../lib/quotes';
import { createQuote, getOwnedQuote, getQuoteItems, validateQuoteReferences } from '../../../../lib/quote-store';

const allowedStatuses = ['Rascunho', 'Enviado', 'Aprovado', 'Recusado', 'Vencido'];

export async function GET(_: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getChatGPTUser();
  if (!user) return json({ error: 'authentication_required' }, 401);
  await ensurePersonalSchema();
  const { id } = await context.params;
  const quote = await getOwnedQuote(user.userId, id);
  if (!quote) return json({ error: 'not_found' }, 404);
  const [items, history] = await Promise.all([
    getQuoteItems(id),
    bindings.DB.prepare('SELECT * FROM quote_history WHERE quote_id = ? ORDER BY created_at DESC').bind(id).all(),
  ]);
  return json({ data: { ...quote, items, history: history.results } });
}

export async function POST(_: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getChatGPTUser();
  if (!user) return json({ error: 'authentication_required' }, 401);
  await ensureCoreSchema();
  await ensurePersonalSchema();
  const { id } = await context.params;
  const quote = await getOwnedQuote(user.userId, id);
  if (!quote) return json({ error: 'not_found' }, 404);
  const items = await getQuoteItems(id) as Record<string, unknown>[];
  const payload: QuotePayload = {
    status: 'Rascunho', issueDate: new Date().toISOString().slice(0, 10), validUntil: String(quote.valid_until), projectId: quote.project_id ? String(quote.project_id) : undefined, projectName: quote.project_name ? String(quote.project_name) : undefined, internalNotes: quote.internal_notes ? String(quote.internal_notes) : undefined, clientId: quote.client_id ? String(quote.client_id) : undefined, clientName: String(quote.client_name), clientDocument: quote.client_document ? String(quote.client_document) : undefined, clientPhone: quote.client_phone ? String(quote.client_phone) : undefined, clientEmail: quote.client_email ? String(quote.client_email) : undefined, clientAddress: quote.client_address ? String(quote.client_address) : undefined, contactName: quote.contact_name ? String(quote.contact_name) : undefined, discountCents: Number(quote.discount_cents), surchargeCents: Number(quote.surcharge_cents), taxCents: Number(quote.tax_cents), paymentMethod: quote.payment_method ? String(quote.payment_method) : undefined, paymentTerms: quote.payment_terms ? String(quote.payment_terms) : undefined, deliveryTerms: quote.delivery_terms ? String(quote.delivery_terms) : undefined,
    items: items.map((item) => ({ description: String(item.description), quantity: Number(item.quantity), unit: String(item.unit), unitPriceCents: Number(item.unit_price_cents), discountType: item.discount_type === 'fixed' ? 'fixed' : 'percent', discountValue: Number(item.discount_value) })),
  };
  const copy = await createQuote(user.userId, user.userId, payload, `Duplicado do orçamento #${String(quote.number).padStart(6, '0')}`);
  return json({ data: copy }, 201);
}

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getChatGPTUser();
  if (!user) return json({ error: 'authentication_required' }, 401);
  await ensurePersonalSchema();
  const { id } = await context.params;
  const current = await getOwnedQuote(user.userId, id);
  if (!current) return json({ error: 'not_found' }, 404);
  const raw = await request.json() as Record<string, unknown>;
  if (raw.status && !raw.items) {
    const status = String(raw.status);
    if (!allowedStatuses.includes(status)) return json({ error: 'invalid_status' }, 422);
    await bindings.DB.batch([
      bindings.DB.prepare('UPDATE quotes SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND owner_id = ?').bind(status, id, user.userId),
      bindings.DB.prepare(`INSERT INTO quote_history (id, quote_id, actor_id, action, from_status, to_status, details) VALUES (?, ?, ?, 'status_changed', ?, ?, 'Status atualizado individualmente')`).bind(uid('orh'), id, user.userId, current.status, status),
    ]);
    return json({ data: { id, status } });
  }
  try {
    const payload = parseQuotePayload(raw);
    await validateQuoteReferences(user.userId, payload);
    const totals = calculateQuote(payload);
    const statements = [
      bindings.DB.prepare(`UPDATE quotes SET status = ?, issue_date = ?, valid_until = ?, project_id = ?, project_name = ?, internal_notes = ?, client_id = ?, client_name = ?, client_document = ?, client_phone = ?, client_email = ?, client_address = ?, contact_name = ?, subtotal_cents = ?, item_discount_cents = ?, discount_cents = ?, surcharge_cents = ?, tax_cents = ?, total_cents = ?, payment_method = ?, payment_terms = ?, delivery_terms = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND owner_id = ?`).bind(payload.status, payload.issueDate, payload.validUntil, payload.projectId ?? null, payload.projectName ?? null, payload.internalNotes ?? null, payload.clientId ?? null, payload.clientName, payload.clientDocument ?? null, payload.clientPhone ?? null, payload.clientEmail ?? null, payload.clientAddress ?? null, payload.contactName ?? null, totals.subtotalCents, totals.itemDiscountCents, totals.discountCents, payload.surchargeCents, payload.taxCents, totals.totalCents, payload.paymentMethod ?? null, payload.paymentTerms ?? null, payload.deliveryTerms ?? null, id, user.userId),
      bindings.DB.prepare('DELETE FROM quote_items WHERE quote_id = ?').bind(id),
      ...totals.items.map((item) => bindings.DB.prepare(`INSERT INTO quote_items (id, quote_id, description, quantity, unit, unit_price_cents, discount_type, discount_value, total_cents, position) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).bind(uid('ori'), id, item.description, item.quantity, item.unit, item.unitPriceCents, item.discountType, item.discountValue, item.totalCents, item.position)),
      bindings.DB.prepare(`INSERT INTO quote_history (id, quote_id, actor_id, action, from_status, to_status, details) VALUES (?, ?, ?, 'updated', ?, ?, 'Dados e valores atualizados')`).bind(uid('orh'), id, user.userId, current.status, payload.status),
    ];
    await bindings.DB.batch(statements);
    return json({ data: { id, status: payload.status, totalCents: totals.totalCents } });
  } catch (error) {
    const code = error instanceof Error ? error.message : 'validation_error';
    return json({ error: code }, 422);
  }
}

export async function DELETE(_: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getChatGPTUser();
  if (!user) return json({ error: 'authentication_required' }, 401);
  await ensurePersonalSchema();
  const { id } = await context.params;
  const current = await getOwnedQuote(user.userId, id);
  if (!current) return json({ error: 'not_found' }, 404);
  await bindings.DB.batch([
    bindings.DB.prepare('UPDATE quotes SET deleted_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND owner_id = ?').bind(id, user.userId),
    bindings.DB.prepare(`INSERT INTO quote_history (id, quote_id, actor_id, action, from_status, to_status, details) VALUES (?, ?, ?, 'deleted', ?, ?, 'Orçamento removido')`).bind(uid('orh'), id, user.userId, current.status, current.status),
  ]);
  return json({ data: { id, deleted: true } });
}
