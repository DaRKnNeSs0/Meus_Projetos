import { getChatGPTUser } from '../../chatgpt-auth';
import { ensurePersonalSchema } from '../../../lib/personal-data';
import { bindings, json, uid } from '../../../lib/platform';

export async function GET() {
  const user = await getChatGPTUser();
  if (!user) return json({ error: 'authentication_required' }, 401);
  await ensurePersonalSchema();
  const rows = await bindings.DB.prepare(`SELECT p.*, c.name AS client_name, (SELECT COUNT(*) FROM quotes q WHERE q.project_id = p.id AND q.deleted_at IS NULL) AS quote_count FROM personal_projects p LEFT JOIN personal_clients c ON c.id = p.client_id WHERE p.owner_id = ? AND p.deleted_at IS NULL ORDER BY p.updated_at DESC`).bind(user.userId).all();
  return json({ data: rows.results });
}

export async function POST(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return json({ error: 'authentication_required' }, 401);
  await ensurePersonalSchema();
  const body = await request.json() as Record<string, unknown>;
  const name = String(body.name ?? '').trim().slice(0, 180);
  const code = String(body.code ?? '').trim().slice(0, 40);
  if (!name || !code) return json({ error: 'validation_error', fields: ['name', 'code'] }, 422);
  if (body.clientId) {
    const client = await bindings.DB.prepare('SELECT id FROM personal_clients WHERE id = ? AND owner_id = ? AND deleted_at IS NULL').bind(body.clientId, user.userId).first();
    if (!client) return json({ error: 'invalid_client' }, 422);
  }
  const id = uid('prj');
  await bindings.DB.batch([
    bindings.DB.prepare(`INSERT INTO personal_projects (id, owner_id, client_id, code, name, type, description, environment, version, start_date, due_date, progress, status, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).bind(id, user.userId, body.clientId || null, code, name, body.type || 'Sistema', body.description || null, body.environment || 'Desenvolvimento', body.version || '1.0.0', body.startDate || null, body.dueDate || null, Math.min(100, Math.max(0, Number(body.progress) || 0)), body.status || 'Em desenvolvimento', body.notes || null),
    bindings.DB.prepare(`INSERT INTO catalog_history (id, owner_id, entity_type, entity_id, action, details) VALUES (?, ?, 'project', ?, 'created', ?)`).bind(uid('his'), user.userId, id, `Projeto ${name} cadastrado`),
  ]);
  return json({ data: { id, name, responsible: 'Administrador Master' } }, 201);
}
