import { getChatGPTUser } from '../../../chatgpt-auth';
import { ensurePersonalSchema } from '../../../../lib/personal-data';
import { bindings, json, uid } from '../../../../lib/platform';

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getChatGPTUser();
  if (!user) return json({ error: 'authentication_required' }, 401);
  await ensurePersonalSchema();
  const { id } = await context.params;
  const current = await bindings.DB.prepare('SELECT id FROM personal_projects WHERE id = ? AND owner_id = ? AND deleted_at IS NULL').bind(id, user.userId).first();
  if (!current) return json({ error: 'not_found' }, 404);
  const body = await request.json() as Record<string, unknown>;
  const name = String(body.name ?? '').trim().slice(0, 180);
  const code = String(body.code ?? '').trim().slice(0, 40);
  if (!name || !code) return json({ error: 'validation_error', fields: ['name', 'code'] }, 422);
  if (body.clientId) {
    const client = await bindings.DB.prepare('SELECT id FROM personal_clients WHERE id = ? AND owner_id = ? AND deleted_at IS NULL').bind(body.clientId, user.userId).first();
    if (!client) return json({ error: 'invalid_client' }, 422);
  }
  await bindings.DB.batch([
    bindings.DB.prepare(`UPDATE personal_projects SET client_id = ?, code = ?, name = ?, type = ?, description = ?, environment = ?, version = ?, start_date = ?, due_date = ?, progress = ?, status = ?, notes = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND owner_id = ?`).bind(body.clientId || null, code, name, body.type || 'Sistema', body.description || null, body.environment || 'Desenvolvimento', body.version || '1.0.0', body.startDate || null, body.dueDate || null, Math.min(100, Math.max(0, Number(body.progress) || 0)), body.status || 'Em desenvolvimento', body.notes || null, id, user.userId),
    bindings.DB.prepare(`INSERT INTO catalog_history (id, owner_id, entity_type, entity_id, action, details) VALUES (?, ?, 'project', ?, 'updated', ?)`).bind(uid('his'), user.userId, id, `Projeto ${name} atualizado`),
  ]);
  return json({ data: { id, name, responsible: 'Administrador Master' } });
}

export async function DELETE(_: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getChatGPTUser();
  if (!user) return json({ error: 'authentication_required' }, 401);
  await ensurePersonalSchema();
  const { id } = await context.params;
  const current = await bindings.DB.prepare('SELECT name FROM personal_projects WHERE id = ? AND owner_id = ? AND deleted_at IS NULL').bind(id, user.userId).first<{ name: string }>();
  if (!current) return json({ error: 'not_found' }, 404);
  await bindings.DB.batch([
    bindings.DB.prepare(`UPDATE personal_projects SET status = 'Pausado', updated_at = CURRENT_TIMESTAMP WHERE id = ? AND owner_id = ?`).bind(id, user.userId),
    bindings.DB.prepare(`INSERT INTO catalog_history (id, owner_id, entity_type, entity_id, action, details) VALUES (?, ?, 'project', ?, 'deactivated', ?)`).bind(uid('his'), user.userId, id, `Projeto ${current.name} pausado`),
  ]);
  return json({ data: { id, status: 'Pausado' } });
}
