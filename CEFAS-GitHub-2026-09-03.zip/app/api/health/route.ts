import { bindings, integrationProject, json, sanitize, uid } from '../../../lib/platform';

export async function POST(request: Request) {
  const project = await integrationProject(request);
  if (!project) return json({ error: 'invalid_project_credentials' }, 401);
  const body = sanitize(await request.json()) as Record<string, unknown>;
  const now = new Date().toISOString();
  await bindings.DB.prepare(`INSERT INTO health_checks (id, project_id, environment, status, response_time_ms, database_status, cpu_percent, memory_percent, disk_percent, checked_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).bind(uid('hc'), project.id, body.environment ?? 'production', body.status ?? 'healthy', body.responseTimeMs ?? null, body.databaseStatus ?? null, body.cpuPercent ?? null, body.memoryPercent ?? null, body.diskPercent ?? null, now).run();
  return json({ accepted: true, checkedAt: now }, 202);
}
