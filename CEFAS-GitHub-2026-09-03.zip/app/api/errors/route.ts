import { bindings, ensureCoreSchema, fingerprint, integrationProject, json, nextNumber, sanitize, uid } from '../../../lib/platform';

export async function POST(request: Request) {
  const project = await integrationProject(request);
  if (!project) return json({ error: 'invalid_project_credentials' }, 401);
  await ensureCoreSchema();
  const body = sanitize(await request.json()) as Record<string, unknown>;
  const environment = String(body.environment ?? 'production');
  const errorFingerprint = await fingerprint([project.id, body.endpoint, body.message, body.stack, body.route, body.httpStatus, body.version, environment]);
  const existing = await bindings.DB.prepare(`SELECT id, number, occurrence_count FROM tickets WHERE project_id = ? AND fingerprint = ? AND status NOT IN ('resolved','finished','cancelled') AND deleted_at IS NULL LIMIT 1`).bind(project.id, errorFingerprint).first<{ id: string; number: number; occurrence_count: number }>();
  const now = new Date().toISOString();
  if (existing) {
    await bindings.DB.batch([
      bindings.DB.prepare(`UPDATE tickets SET occurrence_count = occurrence_count + 1, last_occurrence_at = ?, updated_at = ? WHERE id = ?`).bind(now, now, existing.id),
      bindings.DB.prepare(`INSERT INTO ticket_occurrences (id, ticket_id, user_id, session_id, version, environment, metadata, occurred_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`).bind(uid('occ'), existing.id, body.userId ?? null, body.sessionId ?? null, body.version ?? null, environment, JSON.stringify(body), now),
    ]);
    return json({ data: { ticketId: existing.id, ticketNumber: existing.number, deduplicated: true, occurrences: existing.occurrence_count + 1 } }, 202);
  }
  const number = await nextNumber(project.tenant_id, 'ticket');
  const id = uid('tkt');
  const priority = Number(body.httpStatus) >= 500 ? 'high' : 'medium';
  await bindings.DB.batch([
    bindings.DB.prepare(`INSERT INTO tickets (id, tenant_id, number, project_id, title, description, category, priority, status, source, environment, affected_version, module, route, fingerprint, first_occurrence_at, last_occurrence_at) VALUES (?, ?, ?, ?, ?, ?, 'error', ?, 'triage', 'system', ?, ?, ?, ?, ?, ?, ?)`).bind(id, project.tenant_id, number, project.id, String(body.message ?? 'Erro capturado automaticamente'), String(body.stack ?? body.message ?? 'Sem stack trace'), priority, environment, body.version ?? null, body.module ?? null, body.route ?? null, errorFingerprint, now, now),
    bindings.DB.prepare(`INSERT INTO ticket_occurrences (id, ticket_id, user_id, session_id, version, environment, metadata, occurred_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`).bind(uid('occ'), id, body.userId ?? null, body.sessionId ?? null, body.version ?? null, environment, JSON.stringify(body), now),
    bindings.DB.prepare(`INSERT INTO monitoring_events (id, project_id, type, severity, fingerprint, message, sanitized_payload, occurred_at) VALUES (?, ?, 'error', ?, ?, ?, ?, ?)`).bind(uid('evt'), project.id, priority, errorFingerprint, String(body.message ?? 'Erro capturado'), JSON.stringify(body), now),
  ]);
  return json({ data: { ticketId: id, ticketNumber: number, deduplicated: false, fingerprint: errorFingerprint } }, 201);
}
