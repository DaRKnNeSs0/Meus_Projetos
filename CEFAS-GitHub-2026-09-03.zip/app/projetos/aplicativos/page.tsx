import type { Metadata } from 'next';
import ProjectDemoPage from '../../components/project-demo-page';

export const metadata: Metadata = { title: 'Modelo de Aplicativo | CEFAS', description: 'Demonstração conceitual e interativa de um aplicativo.' };

export default function Page() { return <ProjectDemoPage kind="app" />; }
