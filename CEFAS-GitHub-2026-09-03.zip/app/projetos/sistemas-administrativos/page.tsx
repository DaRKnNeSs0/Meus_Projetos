import type { Metadata } from 'next';
import ProjectDemoPage from '../../components/project-demo-page';

export const metadata: Metadata = { title: 'Modelo de Sistema Administrativo | CEFAS', description: 'Demonstração conceitual e interativa de um sistema administrativo.' };

export default function Page() { return <ProjectDemoPage kind="admin" />; }
