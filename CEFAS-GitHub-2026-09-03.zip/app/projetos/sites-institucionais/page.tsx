import type { Metadata } from 'next';
import ProjectDemoPage from '../../components/project-demo-page';

export const metadata: Metadata = { title: 'Modelo de Site Institucional | CEFAS', description: 'Demonstração conceitual e interativa de um site institucional.' };

export default function Page() { return <ProjectDemoPage kind="institutional" />; }
