'use client';

import { FormEvent, useEffect, useState } from 'react';
import { siteConfig } from '../lib/site-config';

const services = [
  { icon: 'AP', title: 'Desenvolvimento de aplicativos', text: 'Aplicativos modernos, intuitivos e preparados para crescer com o seu negócio.', tags: ['Android', 'iOS', 'Multiplataforma'], tone: 'blue' },
  { icon: 'SI', title: 'Sites institucionais', text: 'Presença digital profissional para apresentar sua marca, gerar confiança e conquistar novos contatos.', tags: ['Institucional', 'Landing pages', 'SEO'], tone: 'violet' },
  { icon: 'EC', title: 'E-commerces', text: 'Lojas virtuais rápidas, seguras e pensadas para transformar visitas em vendas.', tags: ['Catálogo', 'Pagamentos', 'Vendas'], tone: 'pink' },
  { icon: 'SW', title: 'Sistemas web', text: 'Plataformas, painéis administrativos e sistemas personalizados para centralizar sua operação.', tags: ['Painéis', 'Portais', 'Gestão'], tone: 'cyan' },
  { icon: 'API', title: 'Integrações e APIs', text: 'Conectamos sistemas, serviços e dados para eliminar tarefas repetitivas e melhorar seus processos.', tags: ['APIs', 'Automação', 'Dados'], tone: 'green' },
  { icon: 'ME', title: 'Manutenção e evolução', text: 'Correções, melhorias, novas funcionalidades e acompanhamento contínuo após a publicação.', tags: ['Melhorias', 'Versões', 'Performance'], tone: 'orange' },
  { icon: 'MS', title: 'Monitoramento e suporte', text: 'Acompanhamento de disponibilidade, erros, incidentes e chamados para manter sua solução funcionando.', tags: ['Uptime', 'Chamados', 'Suporte'], tone: 'pink' },
];

const processSteps = [
  ['01', 'Descoberta', 'Entendemos o negócio, os usuários e os objetivos do projeto.'],
  ['02', 'Planejamento', 'Definimos funcionalidades, arquitetura, prazos e prioridades.'],
  ['03', 'Design', 'Criamos uma experiência clara, moderna e alinhada à sua marca.'],
  ['04', 'Desenvolvimento', 'Construímos com tecnologias atuais, segurança e qualidade.'],
  ['05', 'Publicação e evolução', 'Publicamos, monitoramos e continuamos aprimorando o produto.'],
];

const projectTypes = [
  { slug: 'sistemas-administrativos', category: 'Sistemas administrativos', title: 'Central de gestão', description: 'Explore um painel completo para acompanhar clientes, projetos, indicadores e relatórios.', features: ['Dashboard e indicadores', 'Cadastros e filtros', 'Relatórios gerenciais'], preview: 'system', formType: 'Sistema administrativo' },
  { slug: 'landing-pages', category: 'Landing pages', title: 'Página de conversão', description: 'Veja uma página focada em apresentar uma oferta e transformar visitantes em oportunidades.', features: ['Seções de benefícios', 'Perguntas frequentes', 'Formulário com validação'], preview: 'landing', formType: 'Landing page' },
  { slug: 'sites-institucionais', category: 'Sites institucionais', title: 'Presença digital profissional', description: 'Navegue por uma apresentação completa de empresa, serviços, diferenciais e contato.', features: ['Navegação responsiva', 'Serviços e diferenciais', 'Contato integrado'], preview: 'site', formType: 'Site institucional' },
  { slug: 'aplicativos', category: 'Aplicativos', title: 'Gestão na palma da mão', description: 'Experimente telas de acesso, tarefas, indicadores, favoritos, notificações e perfil.', features: ['Telas interativas', 'Busca e filtros', 'Navegação inferior'], preview: 'app', formType: 'Aplicativo' },
];
const values = ['Transparência', 'Qualidade técnica', 'Compromisso com a entrega', 'Segurança', 'Evolução contínua'];
const heroWords = ['resultados.', 'experiências.', 'crescimento.'];

function Brand() {
  return <a className="brand" href="#inicio" aria-label="CEFAS — página inicial"><img src="/cefas-logo-clean.png" alt="CEFAS" /></a>;
}

function DashboardVisual({ compact = false }: { compact?: boolean }) {
  return (
    <div className={compact ? 'dashboard-window feature-dashboard' : 'dashboard-window'}>
      <div className="window-top"><div className="mini-brand"><b>CEFAS</b><span>Central</span></div><div className="window-dots"><i /><i /><i /></div></div>
      <div className="dashboard-body">
        <aside><span className="active" /><span /><span /><span /><span /></aside>
        <div className="dashboard-content">
          <div className="dashboard-title"><div><small>VISÃO GERAL</small><strong>{compact ? 'Saúde da operação' : 'Seus projetos'}</strong></div><em><i /> Operação estável</em></div>
          <div className="metric-grid"><article><span>Projetos ativos</span><strong>08</strong><small>Em acompanhamento</small></article><article><span>Disponibilidade</span><strong>99,9%</strong><small className="positive">Tudo funcionando</small></article><article><span>Em evolução</span><strong>05</strong><small>Novas entregas</small></article></div>
          <div className="project-panel">
            <div className="panel-head"><strong>Acompanhamento</strong><span>Tempo real</span></div>
            <div className="project-line"><i className="project-icon">AP</i><span><b>Aplicativo mobile</b><small>Publicação e monitoramento</small></span><em>Online</em></div>
            <div className="project-line"><i className="project-icon violet">SW</i><span><b>Sistema web</b><small>Desenvolvimento</small></span><em className="progress">Em evolução</em></div>
            <div className="chart-bars">{[45,65,52,78,70,88,75,92,86,96,90,100].map((height,index)=><i key={index} style={{height:`${height}%`}} />)}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ProjectPreview({ type }: { type: string }) {
  if (type === 'app') return <div className="functional-preview app-preview"><div className="preview-phone"><span>9:41</span><b>Olá, visitante</b><div className="preview-stat"><i /><i /><i /></div><div className="preview-rows"><i /><i /><i /></div><nav><i /><i /><i /><i /></nav></div></div>;
  if (type === 'system') return <div className="functional-preview system-preview"><div className="preview-window"><aside><b>C</b><i /><i /><i /><i /></aside><section><span>VISÃO GERAL</span><div className="preview-metrics"><i /><i /><i /></div><div className="preview-chart">{[35,58,46,76,64,88,72].map((height)=><i key={height} style={{height:`${height}%`}} />)}</div></section></div></div>;
  return <div className={`functional-preview ${type}-preview`}><div className="preview-browser"><nav><b>{type === 'landing' ? 'OFERTA' : 'EMPRESA'}</b><span>Início&nbsp;&nbsp; Serviços&nbsp;&nbsp; Contato</span></nav><section><small>{type === 'landing' ? 'SOLUÇÃO PARA O SEU NEGÓCIO' : 'PRESENÇA DIGITAL'}</small><strong>{type === 'landing' ? 'Transforme visitas em oportunidades.' : 'Sua empresa bem apresentada.'}</strong><i /><div><span /><span /><span /></div></section></div></div>;
}

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [sent, setSent] = useState(false);
  const [projectType, setProjectType] = useState('');
  const [heroWord, setHeroWord] = useState(0);
  const [scrolled, setScrolled] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [activeSection, setActiveSection] = useState('inicio');
  const currentYear = new Date().getFullYear();

  useEffect(()=>{
    const requested = new URLSearchParams(window.location.search).get('projeto');
    if (requested && ['Aplicativo','Site institucional','Landing page','Sistema administrativo','Ainda não sei'].includes(requested)) setProjectType(requested);
  }, []);

  useEffect(()=>{
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const timer = window.setInterval(()=>setHeroWord((current)=>(current+1)%heroWords.length), 2800);
    return ()=>window.clearInterval(timer);
  }, []);

  useEffect(()=>{
    const sectionIds = ['inicio', 'servicos', 'processo', 'projetos', 'sobre', 'contato'];
    const onScroll = () => {
      const scrollable = document.documentElement.scrollHeight-window.innerHeight;
      setScrollProgress(scrollable>0?Math.min(100,(window.scrollY/scrollable)*100):0);
      setScrolled(window.scrollY>18);
      let current = 'inicio';
      sectionIds.forEach((id)=>{ const section=document.getElementById(id); if(section&&section.getBoundingClientRect().top<=170) current=id; });
      setActiveSection(current);
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return ()=>window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(()=>{
    const targets = document.querySelectorAll<HTMLElement>('.section-heading, .service-card, .feature-copy, .feature-visual, .process-line article, .project-types-heading, .functional-project-card, .about-mark, .about-copy, .cta-section > div, .contact-intro, .contact-form');
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    targets.forEach((target,index)=>{ target.classList.add('reveal-item'); target.style.setProperty('--reveal-delay', `${(index%3)*70}ms`); });
    if (reduced) { targets.forEach((target)=>target.classList.add('is-visible')); return; }
    const observer = new IntersectionObserver((entries)=>entries.forEach((entry)=>{ if(entry.isIntersecting){ entry.target.classList.add('is-visible'); observer.unobserve(entry.target); } }), { threshold: .12, rootMargin: '0px 0px -45px' });
    targets.forEach((target)=>observer.observe(target));
    return ()=>observer.disconnect();
  }, []);

  function submitContact(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    event.currentTarget.reset();
    setSent(true);
  }

  function requestProject(type: string) {
    setProjectType(type);
    setSent(false);
    window.requestAnimationFrame(()=>document.querySelector('#contato')?.scrollIntoView({ behavior: 'smooth' }));
  }

  return (
    <main>
      <div className="site-background" aria-hidden="true" />
      <div className="scroll-progress" aria-hidden="true"><i style={{width:`${scrollProgress}%`}} /></div>
      <header className={scrolled?'site-header scrolled':'site-header'}>
        <Brand />
        <button className="menu-toggle" type="button" aria-label={menuOpen?'Fechar menu':'Abrir menu'} aria-expanded={menuOpen} onClick={()=>setMenuOpen((current)=>!current)}><span /><span /><span /></button>
        <nav className={menuOpen?'site-nav open':'site-nav'} aria-label="Navegação principal">
          {[['Início','inicio'],['Serviços','servicos'],['Processo','processo'],['Projetos','projetos'],['Sobre','sobre'],['Contato','contato']].map(([item,id])=><a key={item} className={activeSection===id?'active':''} href={`#${id}`} onClick={()=>setMenuOpen(false)}>{item}</a>)}
        </nav>
        <a className="button button-small header-cta" href="#contato">Solicitar orçamento</a>
      </header>

      <section className="hero" id="inicio">
        <div className="hero-glow hero-glow-one" /><div className="hero-glow hero-glow-two" />
        <div className="hero-copy">
          <div className="eyebrow"><i /> Desenvolvimento digital sob medida</div>
          <h1>Aplicativos e sites que transformam <span>ideias em <b key={heroWords[heroWord]} className="word-swap">{heroWords[heroWord]}</b></span></h1>
          <p>Desenvolvemos soluções digitais modernas, rápidas e sob medida para o seu negócio — do planejamento à publicação, com suporte e evolução contínua.</p>
          <div className="hero-actions"><a className="button" href="#contato">Solicitar orçamento <span>→</span></a><a className="button button-ghost" href="#servicos">Conhecer serviços</a></div>
          <ul className="hero-benefits" aria-label="Diferenciais da CEFAS"><li><span>✓</span> Desenvolvimento sob medida</li><li><span>✓</span> Design responsivo</li><li><span>✓</span> Suporte contínuo</li></ul>
        </div>
        <div className="hero-visual" aria-label="Representação do painel de acompanhamento CEFAS">
          <DashboardVisual />
          <div className="phone-card"><div className="phone-speaker" /><span className="phone-label">PROJETO</span><strong>Seu app,<br />sempre perto.</strong><div className="phone-orbit"><i>✓</i></div><div className="phone-status"><i /><span><b>Online</b><small>Monitorado pela CEFAS</small></span></div></div>
          <div className="floating-card"><span>✓</span><div><strong>Entrega acompanhada</strong><small>Suporte em cada etapa</small></div></div>
        </div>
      </section>

      <section className="trust-strip" aria-label="Competências da CEFAS"><span>Estratégia</span><i /><span>Design</span><i /><span>Desenvolvimento</span><i /><span>Publicação</span><i /><span>Suporte contínuo</span></section>

      <section className="section services-section" id="servicos">
        <div className="section-heading centered"><p className="section-kicker">SOLUÇÕES CEFAS</p><h2>Tecnologia pensada para fazer<br />o seu negócio avançar.</h2><p>Da primeira ideia à evolução contínua, reunimos tudo o que seu produto digital precisa.</p></div>
        <div className="services-grid">{services.map((service)=><article className="service-card" key={service.title}><div className={`service-icon ${service.tone}`}>{service.icon}</div><h3>{service.title}</h3><p>{service.text}</p><div>{service.tags.map((tag)=><span key={tag}>{tag}</span>)}</div><a href="#contato" aria-label={`Saiba mais sobre ${service.title}`}>Saiba mais <b>→</b></a></article>)}</div>
      </section>

      <section className="feature-section">
        <div className="feature-copy"><p className="section-kicker">DIFERENCIAL CEFAS</p><h2>Mais do que desenvolver,<br /><span>nós acompanhamos.</span></h2><p>A entrega é apenas o começo. Cada projeto pode ser acompanhado por uma estrutura centralizada de suporte, versões e monitoramento.</p>
          <ul>{['Gestão organizada de projetos e versões','Monitoramento de disponibilidade e desempenho','Centralização de chamados e incidentes','Histórico de melhorias e atualizações','Proteção de dados sensíveis','Comunicação clara durante todo o projeto'].map((item)=><li key={item}><span>✓</span>{item}</li>)}</ul>
          <a className="text-link" href="#contato">Converse sobre o seu projeto <span>→</span></a>
        </div>
        <div className="feature-visual"><div className="feature-glow" /><DashboardVisual compact /><div className="feature-badge badge-one"><b>99,9%</b><span>Disponibilidade</span></div><div className="feature-badge badge-two"><i>✓</i><span><b>Projeto acompanhado</b><small>Da ideia à evolução</small></span></div></div>
      </section>

      <section className="section process-section" id="processo">
        <div className="section-heading"><p className="section-kicker">COMO TRABALHAMOS</p><h2>Da ideia à solução publicada.</h2><p>Um processo claro, colaborativo e orientado ao resultado.</p></div>
        <div className="process-line">{processSteps.map(([number,title,text],index)=><article key={number}><div className="step-number">{number}</div>{index<processSteps.length-1&&<i />}<h3>{title}</h3><p>{text}</p></article>)}</div>
      </section>

      <section className="project-types" id="projetos">
        <div className="project-types-inner"><div className="project-types-heading"><p className="section-kicker">MODELOS FUNCIONAIS</p><h2>Experimente antes de imaginar o seu projeto.</h2><p>Conheça quatro soluções interativas e veja como cada experiência pode funcionar no dia a dia do seu negócio.</p></div><div className="functional-project-grid">{projectTypes.map((project)=><article className={`functional-project-card ${project.preview}`} key={project.slug}><div className="functional-project-art"><span className="concept-pill">Modelo conceitual</span><ProjectPreview type={project.preview} /></div><div className="functional-project-copy"><span className="model-category">{project.category}</span><h3>{project.title}</h3><p>{project.description}</p><ul>{project.features.map((feature)=><li key={feature}>✓ {feature}</li>)}</ul><div><a href={`/projetos/${project.slug}`}>Visualizar modelo funcional</a><button type="button" onClick={()=>requestProject(project.formType)}>Quero um projeto assim <b>→</b></button></div></div></article>)}</div></div>
      </section>

      <section className="about-section" id="sobre">
        <div className="about-mark"><span>C</span><i /><b>Construímos<br />para evoluir.</b></div>
        <div className="about-copy"><p className="section-kicker">SOBRE A CEFAS</p><h2>Tecnologia construída<br />com propósito.</h2><p>A CEFAS transforma necessidades de negócio em produtos digitais funcionais, seguros e fáceis de usar. Unimos estratégia, design e desenvolvimento para criar soluções que resolvem problemas reais e podem evoluir junto com cada cliente.</p><div className="values-list">{values.map((value,index)=><span key={value}><i>{String(index+1).padStart(2,'0')}</i>{value}</span>)}</div></div>
      </section>

      <section className="cta-section"><div><p>VAMOS CONSTRUIR JUNTOS</p><h2>Tem uma ideia ou um<br />projeto em mente?</h2><span>Conte o que você precisa. A CEFAS ajuda a transformar sua ideia em uma solução digital clara, moderna e preparada para crescer.</span></div><div className="cta-actions"><a className="button light-button" href="#contato">Solicitar orçamento <b>→</b></a>{siteConfig.whatsappUrl?<a className="button whatsapp-button" href={siteConfig.whatsappUrl} target="_blank" rel="noreferrer">Conversar pelo WhatsApp</a>:<a className="button whatsapp-button" href="#contato">Conversar pelo WhatsApp</a>}</div></section>

      <section className="contact-section" id="contato">
        <div className="contact-intro"><p className="section-kicker">CONTATO</p><h2>Conte sobre o<br />seu próximo projeto.</h2><p>Preencha os dados e descreva sua ideia. Essas informações ajudam a CEFAS a preparar uma conversa mais objetiva para você.</p><div className="contact-note"><span>01</span><p><b>Envie sua ideia</b><small>Mesmo que ela ainda esteja no começo.</small></p></div><div className="contact-note"><span>02</span><p><b>Organizamos o cenário</b><small>Entendemos objetivos, necessidades e prioridades.</small></p></div><div className="contact-note"><span>03</span><p><b>Definimos o próximo passo</b><small>Você recebe uma orientação clara para avançar.</small></p></div></div>
        <form className="contact-form" onSubmit={submitContact}>
          <div className="form-grid"><label>Nome<input name="nome" required placeholder="Como podemos chamar você?" /></label><label>Empresa<input name="empresa" placeholder="Nome da empresa" /></label><label>E-mail<input name="email" type="email" required placeholder="voce@empresa.com" /></label><label>WhatsApp<input name="whatsapp" type="tel" required placeholder="(00) 00000-0000" /></label><label>Tipo de projeto<select name="tipo" required value={projectType} onChange={(event)=>setProjectType(event.target.value)}><option value="" disabled>Selecione uma opção</option><option>Aplicativo</option><option>Site institucional</option><option>Landing page</option><option>Sistema administrativo</option><option>Ainda não sei</option></select></label><label>Faixa de orçamento <small>Opcional</small><select name="orcamento" defaultValue=""><option value="">Prefiro conversar</option><option>Até R$ 5 mil</option><option>R$ 5 mil a R$ 15 mil</option><option>R$ 15 mil a R$ 30 mil</option><option>Acima de R$ 30 mil</option></select></label></div>
          <label>Descrição do projeto<textarea name="descricao" required rows={5} placeholder="Conte brevemente o que você quer criar, melhorar ou automatizar..." /></label>
          <label className="privacy-check"><input type="checkbox" required /><span>Concordo que meus dados sejam utilizados para responder a esta solicitação, conforme a Política de Privacidade.</span></label>
          <button className="button form-submit" type="submit">Enviar solicitação <span>→</span></button>
          {sent&&<div className="form-success" role="status"><span>✓</span><div><b>Solicitação preparada com sucesso.</b><small>Conecte este formulário ao canal de atendimento da CEFAS para receber os envios.</small></div></div>}
        </form>
      </section>

      <footer><div className="footer-top"><div className="footer-brand"><Brand /><p>Aplicativos, sites e sistemas sob medida — da ideia à evolução contínua.</p></div><div><b>Navegação</b><a href="#inicio">Início</a><a href="#servicos">Serviços</a><a href="#processo">Processo</a><a href="#projetos">Projetos</a></div><div><b>Serviços</b><a href="#servicos">Aplicativos</a><a href="#servicos">Sites</a><a href="#servicos">Sistemas web</a><a href="#servicos">Integrações</a></div><div><b>Contato</b><a href="#contato">Solicitar orçamento</a>{siteConfig.email&&<a href={`mailto:${siteConfig.email}`}>{siteConfig.email}</a>}{siteConfig.whatsappUrl&&<a href={siteConfig.whatsappUrl}>WhatsApp</a>}</div></div><div className="footer-bottom"><span>© {currentYear} CEFAS. Todos os direitos reservados.</span><div><a href="#contato">Política de Privacidade</a><a href="#contato">Termos de Uso</a></div></div></footer>
    </main>
  );
}
